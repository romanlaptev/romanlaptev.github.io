/*
Usage:

init -
	var zlist = ZList( xml );
	
1.build list table 
	var answer_mode = "answer-mode-answer";//"answer-mode-view", "print"
	//zlist.build({target: "#zlist", show_log: 1, mode: answer_mode});
	zlist.build({target: "#zlist", show_log: 1, mode: "answer-mode-answer", reload: 1});
	
2.build block table
	var build_params = {
		block_id: "#" + div.xblock_id,
		xbr_id: "#" + div.xbr_id,
		target: $(div),
		expand: ((mode=="standard")?0:1),
		show_log: 1,
		reload: reload
	};
	zlist.build_detail_block( build_params );
	
3.toggle block table
	zlist.toggle_block( target, expand=0 );

4.view record in a table list
	zlist.show_selected_record( target );
5.
	zlist.show_all_record( target );
*/
(function(){
	var ZList = ZList || function( xml ){

		//обязательный элемент здесь будет автоматически хранится версия
		// из version control
		var _repositoryRevision = "$Rev: 197 $"; 
		//var _xml = xml; 

		// private variables and functions
		var _init = function(xml){
			return ZListLoader(xml);
		};
		
		//let's start
		var z_obj = _init(xml);
		if ( typeof z_obj  == "undefined")
		{
console.log( "error, z_obj, table_data[xml_info] is empty ");
			return;
		}
		//------------------- html templates
		//var table_tpl ="<table class='list-content table table-bordered' cellSpacing='1' cellPadding='0'>#thead<tbody>#records</tbody>#list_footer</table>";
		var table_tpl ="<table class='list-content table table-bordered' cellSpacing='1' cellPadding='0'>#thead#tbody#list_footer</table>";
		var thead_tpl = "<thead style='display: table-header-group'><tr class='list-header info'>#thead</tr>";
		var thead_column_tpl = "<th>#column_name</th>";
		
		var tbody_tpl = "<tbody class='table-list-group'>#records</tbody>";
		var record_tpl = "<tr>#columns</tr>";
		
		var cell_tpl = "<td class='list-body' valign='top' rowspan='#rowspan' colspan='#colspan'>#value</td>";
		var cell_number_tpl = "<td class='list-body' valign='top' rowspan='#rowspan' colspan='#colspan'>#value</td>";
		var cell_checkbox_tpl = "<td class='list-body' valign='top' rowspan='#rowspan'><input value='#value' type='checkbox' name='records_list_check2'></td>";
		
		var value_tpl = "<a class='list-body-link' href='javascript:goRecord(#record_number)'>#value</a>";
		var message_tpl = "#value";
		var css = "<style>.limit-message{color:red;font-weight:bold;}</style>";

		var block_table_tpl = "<table class='list-content table table-bordered' cellSpacing='1' cellPadding='0' width='100%' tab-rows='1'>";
		block_table_tpl += "<thead>";
		block_table_tpl += "<tr>#title</tr>";
		
		block_table_tpl += "<tr class='#header_class'>#thead</tr>";
		var block_header_class = "block-list-header";
		var block_expandable_header_class = "block-list-header-exp";
		
		block_table_tpl += "</thead>";
		block_table_tpl += "#tbody</table>";
		
		var block_table_title_tpl = "<th colspan='#colspan' class='block-title' style='text-align: left;'>#title-text#pform#btn&nbsp;&nbsp;#title-link</th>";
		var block_table_tbody_tpl = "<tbody class='list-body'>#records</tbody>";
		var block_first_column_tpl = "<td>#value.</td>";
		var block_cell_tpl = "<td rowspan='#rowspan' colspan='#colspan'>#value</td>";
		var block_cell_field_value_tpl = "<td rowspan='#rowspan' colspan='#colspan'><span class='field-value'>#value</span></td>";
		var block_bottom_link_tpl = "<tr><td class='c-td-t list-body' valign='top' align='center' colspan='#colspan'>#block_title <a title='next pages' class='form-link' href=\"javascript:BlockPager(#xbr_id, #block_id,'#block_title')\">[...]</a></td></tr>";
		
		var block_table_expandable_title_tpl = "<th colspan='#colspan' class='block-title-exp' style='text-align: left;'>#title-text&nbsp;&nbsp;#icon#pform#btn#title-link</th>";
		var block_table_expandable_icon_tpl = "<img id='img_#block_id_#first_xbr_id' onclick='toggle_expandable_block(this,\"#block_id\",\"#first_xbr_id\")' style='cursor:hand;vertical-align:top;' src='#icon-src' state='#state' data-target='#target'>";

		var block_table_expandable_icon_up_src_tpl = "iis_z_content.get?iname=up-b-s.png";
		var block_table_expandable_icon_down_src_tpl = "iis_z_content.get?iname=down-b-s.png";
if( location.host == '172.16.1.194')
{
		block_table_expandable_icon_up_src_tpl = "img/up-b-s.png";
		block_table_expandable_icon_down_src_tpl = "img/down-b-s.png";
}
		var block_table_expandable_icon_up_state_tpl = "up";
		var block_table_expandable_icon_down_state_tpl = "down";
		var block_table_pform_select_tpl = "<select id='prn_#block_id_#xbr_id' style='margin-left: 5px;' class='doc-select'>#options</select>";
		var block_table_pform_option_tpl = "<option pformid='#pform_id' cond_f='#pform_cond_f' cond_v='#pform_cond_v'>#pform_title</option>";
		var block_table_pform_button_tpl = "<input onclick='print_block(#block_id, #xbr_id)' id='b_prn_#block_id_#xbr_id' class='doc-button' type='button' value='$res:ctrl.print.show$'>&nbsp;&nbsp;";
if( location.host == '172.16.1.194')
{
		block_table_pform_button_tpl = "<input onclick='print_block(#block_id, #xbr_id)' id='b_prn_#block_id_#xbr_id' class='doc-button' type='button' value='Izdruka'>&nbsp;&nbsp;";
}
		var block_table_title_link_tpl = "<a class='goref-s' href='#url' target='_blank'>#text</a>&nbsp;&nbsp;";

		var block_table_active_row_tbody_tpl = "<tbody onclick='Digiman.Display(#ch_xbr_id)' onmouseover='list_block_highlight(this,true)' onmouseout='list_block_highlight(this,false)' class='list-body' style='cursor: hand;'>#records</tbody>";
		var block_table_ref_tbody_tpl = "<tbody onclick='goRef(\"#ref_name\", #ch_xbr_id, \"#ref_name_text\");' onmouseover='list_block_highlight(this,true)' onmouseout='list_block_highlight(this,false)' class='list-body' style='cursor: hand;'>#records</tbody>";
		var analytic_column_tpl = "<span onclick='analytic_add(\"#analytic_value\", #xbr_id)'><div class='a-form-icon add' onmouseover='$(this).removeClass(\"add\").addClass(\"add-h\");' onmouseout='$(this).removeClass(\"add-h\").addClass(\"add\");'></div></span>";
		
		var list_footer_tpl = "<tFoot><tr><td colspan='#colspan'><table class='list-footer' cellspacing='0' cellpadding='0' width='100%'><tbody><tr><td align='left'>$res:form.list.presets$#select</td><td align='right'>#button</td></tr></tbody></table></td></tr></tFoot>";
		var list_footer_select_tpl = "<select onchange='changePreset2()' class='list-footer-select' name='preset_list2'>#options</select>";
		var list_footer_select_option_tpl = "<option selected='#selected' presetid='#id' preset_type='#type'>#preset_name</option>";
		var list_footer_button_tpl = "<input onclick='showAll2(\"#target_name\")' class='list-footer-button' style='display: none' type='button' value='$res:form.list.show_all$' name='bShowAll2'><input onclick='showSelected2(\"#target_name\")' class='list-footer-button' type='button' align='right' value='$res:form.list.show_selected$' name='bShowSelected2'>";

if( location.host == '172.16.1.194')
{
		var list_footer_tpl = "<tFoot><tr><td colspan='#colspan'><table class='list-footer' cellspacing='0' cellpadding='0' width='100%'><tbody><tr><td align='left'>saraksta veids#select</td><td align='right'>#button</td></tr></tbody></table></td></tr></tFoot>";
		var list_footer_button_tpl = "<input onclick='showAll2(\"#target_name\")' class='list-footer-button' style='display: none' type='button' value='Parādīt visu' name='bShowAll2'><input onclick='showSelected2(\"#target_name\")' class='list-footer-button' type='button' align='right' value='parādīt atlasītos' name='bShowSelected2'>";
}
		
		var _build = function( params ){
			var target = params["target"];
			var show_log = params["show_log"];
			var mode = params["mode"];
			
			var html = css;
			var exec_start = new Date();

if( typeof params["reload"] !== "undefined"
		&& params["reload"] === 1 )
{
	var test = $(xml).find("xlist2").find("column").length;
	z_obj.table_data.log.push("Update xml xlist, " + test + " columns");
	//z_obj.get_table_data( zlist.xml );
	z_obj.get_table_data( xml );
}
else
	z_obj.get_table_data();
	
//fix
//delete z_obj.table_data["xml_records"]["__proto__"]["item"];
//delete z_obj.table_data["xml_records"].constructor.prototype.item;
console.log( z_obj.table_data );

if( z_obj.table_data["columns"].length === 0 )
{
console.log("no data for build table ....");
	return;
}

			var exec_start = new Date();
//draw_table_old( z_obj.table_data["xml_records"] );
//draw_table_test( z_obj.table_data["xml_records"]["test"] );
			draw_table( z_obj.table_data["xml_records"] );
			
			var exec_end = new Date();
			var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
			z_obj.table_data.log.push("function draw_table(): " + runtime_s + " sec");
			if (show_log == 1)
			{
				var num_record = z_obj.table_data.xml_obj.length;
				z_obj.table_data.log.push("Summary runtime (zlist.build): " + runtime_s + " sec, num records: " + num_record);
				var log_html = "";
				log_html += "<ul id='log'>";
				for(var n1 = 0; n1 < z_obj.table_data["log"].length; n1++)
				{
					if(n1 > 0)
					{
						log_html += "<br>";//"&nbsp;&nbsp;";
					}
					log_html += z_obj.table_data["log"][n1];
				}
				log_html += "</ul>";
				$(target).append( log_html );
				z_obj.table_data.log = [];
			}
/*
			function draw_table_old( xml_records )
			{
				html = table_tpl;
				
				//form THEAD
				var html_thead = "";
				var html_thead_column = "";
				if( xml_records.length > 2 )
				{
					html_thead_column += thead_column_tpl.replace("#column_name", "" );
				}	
				html_thead_column += thead_column_tpl.replace("#column_name", "#" );
				
				for( var column in z_obj.table_data["columns"] )
				{
if( typeof z_obj.table_data["columns"][column] === "function")
{
continue;
}//fix							
					var title = z_obj.table_data["columns"][column]["title"];
					html_thead_column += thead_column_tpl.replace("#column_name", title );
				}
				html_thead = thead_tpl.replace("#thead", html_thead_column );
				html = html.replace("#thead", html_thead );

				
				//form TBODY
				//get field values
				var table = [];
				for(var num_rec = 0; num_rec < xml_records.length; num_rec++)
				{
					var max_length = 0;
					for( var num_col in xml_records[num_rec] )
					{
						if( max_length < xml_records[num_rec][num_col].length )
						{
							max_length = xml_records[num_rec][num_col].length;
						}
					}

//------------------------ test					
//for( var fid in xml_records[0][3][0])
//{
//console.log(fid, xml_records[0][3][0][fid]);
//}
//------------------------ test					
					
					//add line for calc rowspan
					var row = [];
					for( var num_row = 0; num_row < max_length; num_row++ )
					{
						for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
						{
						
							var field = {};
							if( typeof xml_records[num_rec][num_col][num_row] !== "undefined")
							{
								var fvalue = "";
								for( var fid in xml_records[num_rec][num_col][num_row])
								{
if( typeof xml_records[num_rec][num_col][num_row][fid] === "function")
{
continue;
}//fix							
									if( fvalue !== "")
									{
										fvalue += "&nbsp;";
									}
									fvalue += xml_records[num_rec][num_col][num_row][fid];
//if( num_rec ===0 && num_row === 0 & num_col === 3)
//{									
//console.log(num_rec, num_row, num_col, fid, xml_records[num_rec][num_col][num_row][fid]);
//}
								}
								field["value"] = fvalue;
							}
							else
							{
								field["value"] = "#rowspan";
if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
{
	field["value"] = "&nbsp;";
}
							}

							if( typeof row[num_row] == "undefined")
							{
								row[num_row] = [];
							}
							row[num_row].push( field );						

						}//next col
					}//next num_row
					
					//table.push( row );
					table[num_rec] = row;
					table[num_rec]["max_length"] = max_length;
					
				}//next rec

				//add rowspan info
//				for(var num_rec = 0; num_rec < table.length; num_rec++)
//				{
//					for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
//					{
//if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
//{
//continue;
//}

//						var num_rowspan = 1;
//						var num_calc_rowspan = 1;
//						for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
//						{
//							if( table[num_rec][num_row][num_col]["value"] === "#rowspan")
//							{
//								num_rowspan++;
//							}
//						}//next row
						
//						if( num_rowspan > 1)
//						{
//							var num_row = xml_records[num_rec][num_col].length - 1;
//							if( num_row < 0)
//							{
//								num_row = 0;
//							}//fix
//							table[num_rec][num_row][num_col]["rowspan"] = num_rowspan;
//						}
						
//					}//next col
//				}//next rec

				//calc rowspan info (uniform alignment values column)
				calc_rowspan_info();

				//move values if calc_rowspan > 0, change
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						var column = [];
						for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col].value.indexOf("#rowspan") === -1 )
							{
								column.push( table[num_rec][num_row][num_col] );
								if( typeof table[num_rec][num_row][num_col]["calc_rowspan"] !== "undefined")
								{
									for(var index = 1; index < table[num_rec][num_row][num_col]["calc_rowspan"]; index++)
									{
										var obj = {value:"#rowspan"};
										column.push(obj);
									}//next
									delete table[num_rec][num_row][num_col]["calc_rowspan"];
								}
							}
						}//next row
						
						if( column.length > 0)
						{
							for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
							{
								table[num_rec][num_row][num_col] = column[num_row];
							}//next row
						}						

					}//next col
				}//next rec

				//recalc rowspan
				calc_rowspan_info();
				
				//group limit-message by id
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var message_id = "";
					for( num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("limit-message") !== -1 )
							{
//filter, remove #colspan and &nbsp;							
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col]["value"].replace(/#colspan/g,"");
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col]["value"].replace(/&nbsp;/g,"");
//console.log(num_rec, num_col, num_row, message_id);
								if( message_id === $( table[num_rec][num_row][num_col]["value"] ).attr("data-id") )
								{
									table[num_rec][num_row][num_col]["value"] = "#colspan";
								}
								else
								{
									message_id = $( table[num_rec][num_row][num_col]["value"] ).attr("data-id");
								}
							}
						}//next row
					}//next col
				}//next rec



				//add colspan info
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var num_colspan = 1;
					var colspan_pos = 0;
					var colspan_info = [];
					for( num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("#colspan") !== -1)
							{
								if( num_colspan == 1)
								{
									var colspan_start_pos = num_col-1;
									if( colspan_start_pos < 0)
									{
										colspan_start_pos = 0;
									}
									var colspan_pos = {
									"record" : num_rec,
									"row" : num_row,
									"column" : colspan_start_pos
									};
									colspan_info.push( colspan_pos );
								}
								num_colspan++;
//console.log(num_rec, num_col, num_row, num_colspan);								
							}
							
						}//next row
					}//next col
					
					if( num_colspan > 1 )
					{
						if( typeof colspan_pos == "object" )
						{
							colspan_pos["colspan"] = num_colspan;
						}
						num_colspan = 1;
						colspan_pos = 0;
					}
					
					if( colspan_info.length > 0 )
					{
						for(var n = 0; n < colspan_info.length; n++)
						{
							var n1 = colspan_info[n]["record"];
							var n2 = colspan_info[n]["row"];
							var n3 = colspan_info[n]["column"];
							var n4 = colspan_info[n]["colspan"];
							table[n1][n2][n3]["colspan"] = n4;
						}
					}

				}//next rec
//console.log( table);
				
				var html_tbody = "";
				var fvalue = "";
				
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				//for(var num_rec = 2; num_rec < 3; num_rec++)
				{
					var html_records = "";
					for( num_row = 0; num_row < table[num_rec].length; num_row++ )
					//for( num_row = 0; num_row < 2; num_row++ )
					{
						var html_columns = "";
						
						var number = num_rec+1;
						if( num_row == 0 )
						{
							if( xml_records.length > 2 )
							{
								html_columns += cell_checkbox_tpl
								.replace("#value", number )
								.replace("#rowspan", table[num_rec].length)
								.replace("colspan='#colspan'", "");
							}	
							html_columns += cell_number_tpl
							.replace("#value", number )
							.replace("#rowspan", table[num_rec].length)
							.replace("colspan='#colspan'", "");
						}
						
						for( num_col = 0; num_col < table[num_rec][num_row].length; num_col++ )
						{
							var fvalue = table[num_rec][num_row][num_col]["value"];
							var num_rowspan = 1;
							//if( typeof table[num_rec][num_row][num_col]["rowspan"] !== "undefined" &&
								//table[num_rec][num_row][num_col]["rowspan"] > 1)
							//{
								//num_rowspan = table[num_rec][num_row][num_col]["rowspan"];
							//}

							if( typeof table[num_rec][num_row][num_col]["calc_rowspan"] !== "undefined" &&
								table[num_rec][num_row][num_col]["calc_rowspan"] > 1)

							{
								num_rowspan = table[num_rec][num_row][num_col]["calc_rowspan"];
							}

							if( fvalue == "#rowspan")
							{
								fvalue = "";
							}

							var num_colspan = 1;
							if( fvalue.indexOf("#colspan") !== -1)
							{
								fvalue = "";
							}
							if( typeof table[num_rec][num_row][num_col]["colspan"] !== "undefined" &&
								table[num_rec][num_row][num_col]["colspan"] > 1)
							{
								num_colspan = table[num_rec][num_row][num_col]["colspan"];
							}
							if( fvalue.length > 0 )
							{
								fvalue = value_tpl
								.replace("#record_number", number)
								.replace("#value", fvalue);							
								
								html_columns += cell_tpl
								.replace("#value", fvalue )
								.replace("#rowspan", num_rowspan )
								.replace("#colspan", num_colspan );
							}
							
							html_columns = html_columns
							.replace("rowspan='#rowspan'", "")
							.replace("rowspan='1'", "")
							.replace("colspan='1'", "")
							.replace("colspan='#colspan'", "");
						
						}//next col
						
						//print table record					
						html_records += record_tpl.replace("#columns", html_columns);
					}//next row
					
					html_tbody += tbody_tpl.replace("#records", html_records );
				}//next rec
				
				//html = html.replace("#records", html_records );
				html = html.replace("#tbody", html_tbody );
				
				if( mode !== "answer-mode-view" && 
						mode !== "print")
				{
					var html_list_footer = form_list_footer();
					html = html.replace("#list_footer", html_list_footer );
				}
				else
				{
					html = html.replace("#list_footer", "");
				}
				$(target).append( html );
				
				
				function calc_rowspan( params )
				{
					var num_field_elements = params.num_field_elements;
					var max_rowspan = params.max_rowspan;
					var num_row = params.num_row;
					
					var num_rowspan = 1;
					k = max_rowspan / num_field_elements;
					var index1 = Math.floor(k);
					var index2 = Math.ceil(k);

					var k_shot = k - index1;
					if (k_shot < 0.5  )
					{
						num_rowspan = index1;
						num_last_rowspan = index2;
					}
					else
					{
						num_rowspan = index2;
						num_last_rowspan = index1;
					}

					//last rowspan
					if ( (num_row / num_rowspan ) +1 == num_field_elements)
					{
						num_rowspan = num_last_rowspan;
					}
					
					return num_rowspan;
				}//end calc_rowspan()

				function calc_rowspan_info()
				{
					for(var num_rec = 0; num_rec < table.length; num_rec++)
					{
						for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
						{
if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
{
	continue;
}
							var num_calc_rowspan = 1;
							for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
							{
//if( num_rec === 6)
//{
//console.log( table[num_rec][num_row][num_col], num_row );	
//}
								if( table[num_rec][num_row][num_col].value.indexOf("#rowspan") === -1 )
								{
									var params = {
										num_field_elements: xml_records[num_rec][num_col].length,
										max_rowspan: table[num_rec]["max_length"],
										num_row: num_row
									};							
									num_calc_rowspan = calc_rowspan( params );
	//if( num_calc_rowspan === Infinity)

									if( num_calc_rowspan > 1 )
									{
										table[num_rec][num_row][num_col]["calc_rowspan"] = num_calc_rowspan;
									}
								}
								
							}//next row
						}//next col
					}//next rec
				}//end calc_rowspan_info()
				
				function form_list_footer( presetlist )
				{
					if( typeof z_obj.table_data["presetlist"] === "undefined" ||
							z_obj.table_data["presetlist"].length < 1)
					{
console.log("error, no data for form presetlist");
						z_obj.table_data.log.push("error, no data for form presetlist...");
						return "";
					}
					
					//form select
					var html_options = "";
					for( var n = 0; n < z_obj.table_data["presetlist"].length; n++)
					{
						var preset = z_obj.table_data["presetlist"][n];
						if( typeof preset["selected"] !== "undefined")
						{
							var selected = preset["selected"];
						}
						else
						{
							var selected = 0;
						}
						html_options += list_footer_select_option_tpl
						.replace("#selected", ((selected == 1)? selected:""))
						.replace("#id", preset["presetid"])
						.replace("#type", preset["preset_type"])
						.replace("#preset_name", preset["preset_name"]);
					}//next preset
					html_options = html_options.replace(/selected=''/g, "");
					var list_footer_select = list_footer_select_tpl.replace("#options", html_options);
					
					if( xml_records.length > 2 )
					{
						//var list_footer_button = list_footer_button_tpl;
						var list_footer_button = list_footer_button_tpl.replace(/#target_name/g, target);
					}
					else
					{
						var list_footer_button = "";
					}
					
					var colspan = z_obj.table_data["columns"].length + 2;
					var html = list_footer_tpl
					.replace("#colspan", colspan)
					.replace("#select", list_footer_select)
					.replace("#button", list_footer_button);
					
					return html;
				}//end form_list_footer
				
			}//end draw_table_old()
	*/	
	
/*	
			function draw_table_test( xml_records )
			{
				html = table_tpl;
				
				//form THEAD
				var html_thead = "";
				var html_thead_column = "";
				if( xml_records.length > 2 )
				{
					html_thead_column += thead_column_tpl.replace("#column_name", "" );
				}	
				html_thead_column += thead_column_tpl.replace("#column_name", "#" );
				
				for( var column in z_obj.table_data["columns"] )
				{
if( typeof z_obj.table_data["columns"][column] === "function")
{
continue;
}//fix							
					var title = z_obj.table_data["columns"][column]["title"];
					html_thead_column += thead_column_tpl.replace("#column_name", title );
				}
				html_thead = thead_tpl.replace("#thead", html_thead_column );
				html = html.replace("#thead", html_thead );

				
				//form TBODY
				//get field values
				var table = [];
				for(var num_rec = 0; num_rec < xml_records.length; num_rec++)
				{
					var max_length = 0;
					for( var num_col in xml_records[num_rec] )
					{
						if( max_length < xml_records[num_rec][num_col].length )
						{
							max_length = xml_records[num_rec][num_col].length;
						}
					}

					var tbody = [];
					for( var num_row = 0; num_row < max_length; num_row++ )
					{
						var table_row = [];
						for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
						{
							var field = {};
							var table_cells = [];
							if( typeof xml_records[num_rec][num_col][num_row] !== "undefined")
							{

//inserted block process						
//console.log(num_rec, num_row, num_col, num_cell, xml_records[num_rec][num_col][num_row].length);
if( xml_records[num_rec][num_col][num_row].length > 1)
{
	for( var num_cell_value = 0; num_cell_value < xml_records[num_rec][num_col][num_row].length; num_cell_value++)
	{
		var fvalue = "";
		for( var fid in xml_records[num_rec][num_col][num_row][num_cell_value])
		{
if( typeof xml_records[num_rec][num_col][num_row][num_cell_value][fid] === "function")
{
continue;
}//fix
			fvalue += xml_records[num_rec][num_col][num_row][num_cell_value][fid];
//console.log(num_rec, num_row, num_col, num_cell, xml_records[num_rec][num_col][num_row][num_cell_value], num_cell_value);
		}//next fid
		var field = {};
		field["value"] = fvalue;
		table_cells.push( field );
		
	}//next cell_value
}
else
{

								for( var num_cell = 0; num_cell < xml_records[num_rec][num_col].length; num_cell++ )
								{
									if( typeof xml_records[num_rec][num_col][num_row][num_cell] !== "undefined")
									{
										var fvalue = "";
										for( var fid in xml_records[num_rec][num_col][num_row][num_cell])
										{
//console.log(num_rec, num_row, num_col, num_cell, xml_records[num_rec][num_col][num_row][num_cell][fid]);
if( typeof xml_records[num_rec][num_col][num_row][num_cell][fid] === "function")
{
continue;
}//fix							
											if( fvalue !== "")
											{
												fvalue += "&nbsp;";
											}
											fvalue += xml_records[num_rec][num_col][num_row][num_cell][fid];
										}//next fid
										field["value"] = fvalue;
										table_cells.push( field );
									}
									else
									{
									}
								}//next cell
}
							}
							else
							{
								field["value"] = "#rowspan_aligment";
								//field["value"] = "&nbsp;";
								table_cells.push( field );
//if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
//{
	//field["value"] = "&nbsp;";
//}
							}
							table_row.push( table_cells );
							
						}//next col
						
						//row aligment
						var max_size_row = 0;
						for( var num_cell = 0; num_cell < table_row.length; num_cell++)
						{
							if( max_size_row < table_row[num_cell].length )
							{
								max_size_row = table_row[num_cell].length;
							}
						}//next cell
				
						//add row
						if( max_size_row > 1 )
						{
							var extended_row = [];
							for( var num_table_row = 0; num_table_row < max_size_row; num_table_row++)
							{
								extended_row[num_table_row] = [];
								for( var num_table_col = 0; num_table_col < table_row.length; num_table_col++)
								{
									var field = [];
									if( typeof table_row[num_table_col][num_table_row] === "undefined")
									{
										field.push( {"value":"#rowspan"} );
										extended_row[num_table_row].push( field );
									}	
									else
									{
										field.push( table_row[num_table_col][num_table_row] );
										extended_row[num_table_row].push( field );
									}
								}//next table_col
							}//next table_row
							
							for( var num_table_col = 0; num_table_col < table_row.length; num_table_col++)
							{
								var num_last_extended_row = max_size_row-1;
								extended_row[num_last_extended_row][num_table_col][0]["last_extended_row"] = 1;
							}
							tbody = extended_row ;
						}
						else
							tbody.push( table_row );
							
						
					}//next num_row
					table[num_rec] = tbody;
					table[num_rec]["max_length"] = max_length;
					
				}//next rec
				
				//add rowspan info
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						var num_rowspan = 1;
						var num_calc_rowspan = 1;
						var start_pos = 0;
						for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							for( var num_cell = 0; num_cell < table[num_rec][num_row][num_col].length; num_cell++)
							{
								if( table[num_rec][num_row][num_col][num_cell]["value"] === "#rowspan")
								{
									num_rowspan++;
								}
								else
								{
//console.log(num_rec, num_col, num_row, num_cell, table[num_rec][num_row][num_col][num_cell]["value"], num_rowspan, start_pos);
									start_pos = num_row;
									num_rowspan = 1;
								}
								
								if( num_rowspan > 1)
								{
									table[num_rec][start_pos][num_col][0]["rowspan"] = num_rowspan;
								}
							}//next cell

						}//next row
					}//next col
				}//next rec

				
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						var num_rowspan = 1;
						var num_calc_rowspan = 1;
						var start_pos = 0;
						for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
//if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
//{
//continue;
//}
							for( var num_cell = 0; num_cell < table[num_rec][num_row][num_col].length; num_cell++)
							{
								if( table[num_rec][num_row][num_col][num_cell]["value"] === "#rowspan_aligment")
								{
									if(table[num_rec][start_pos][num_col][0]["last_extended_row"] !== 1)
									{
										num_rowspan++;
									}
									else
									{
										table[num_rec][num_row][num_col][num_cell]["value"] = "&nbsp;";//fix
									}
								}
								else
								{
									start_pos = num_row;
									num_rowspan = 1;
								}
								
								if( num_rowspan > 1)
								{
									table[num_rec][start_pos][num_col][0]["rowspan"] = num_rowspan;
								}
							}//next cell

						}//next row
					}//next col
				}//next rec
				
				//calc rowspan info (uniform alignment values column)
				//calc_rowspan_info();

				//move values if calc_rowspan > 0, change
//				for(var num_rec = 0; num_rec < table.length; num_rec++)
//				{
//					for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
//					{
//						var column = [];
//						for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
//						{
//							if( table[num_rec][num_row][num_col].value.indexOf("#rowspan") === -1 )
//							{
//								column.push( table[num_rec][num_row][num_col] );
//								if( typeof table[num_rec][num_row][num_col]["calc_rowspan"] !== "undefined")
//								{
//									for(var index = 1; index < table[num_rec][num_row][num_col]["calc_rowspan"]; index++)
//									{
//										var obj = {value:"#rowspan"};
//										column.push(obj);
//									}//next
//									delete table[num_rec][num_row][num_col]["calc_rowspan"];
//								}
//							}
//						}//next row
						
//						if( column.length > 0)
//						{
//							for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
//							{
//								table[num_rec][num_row][num_col] = column[num_row];
//							}//next row
//						}						

//					}//next col
//				}//next rec

				//recalc rowspan
				//calc_rowspan_info();


				//group limit-message by id
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var message_id = "";
					for( num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							for( var num_cell = 0; num_cell < table[num_rec][num_row][num_col].length; num_cell++)
							{
								if( table[num_rec][num_row][num_col][num_cell]["value"].indexOf("limit-message") !== -1 )
								{
//filter, remove #colspan and &nbsp;							
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col][num_cell]["value"].replace(/#colspan/g,"");
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col][num_cell]["value"].replace(/&nbsp;/g,"");
//console.log(num_rec, num_col, num_row, message_id);
									if( message_id === $( table[num_rec][num_row][num_col][num_cell]["value"] ).attr("data-id") )
									{
										table[num_rec][num_row][num_col][num_cell]["value"] = "#colspan";
									}
									else
									{
										message_id = $( table[num_rec][num_row][num_col][num_cell]["value"] ).attr("data-id");
									}
								}
							}//next cell
						}//next row
					}//next col
				}//next rec


				//add colspan info
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var num_colspan = 1;
					var colspan_pos = 0;
					var colspan_info = [];
					for( num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
					{
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							for( var num_cell = 0; num_cell < table[num_rec][num_row][num_col].length; num_cell++)
							{
								if( table[num_rec][num_row][num_col][num_cell]["value"].indexOf("#colspan") !== -1)
								{
									if( num_colspan == 1)
									{
										var colspan_start_pos = num_col-1;
										if( colspan_start_pos < 0)
										{
											colspan_start_pos = 0;
										}
										var colspan_pos = {
										"record" : num_rec,
										"row" : num_row,
										"column" : colspan_start_pos,
										"cell" : num_cell
										};
										colspan_info.push( colspan_pos );
									}
									num_colspan++;
								}
							}//next cell
						}//next row
					}//next col

					if( num_colspan > 1 )
					{
						if( typeof colspan_pos == "object" )
						{
							colspan_pos["colspan"] = num_colspan;
						}
						num_colspan = 1;
						colspan_pos = 0;
					}

					if( colspan_info.length > 0 )
					{
						for(var n = 0; n < colspan_info.length; n++)
						{
							var n1 = colspan_info[n]["record"];
							var n2 = colspan_info[n]["row"];
							var n3 = colspan_info[n]["column"];
							var n4 = colspan_info[n]["colspan"];
							var n5 = colspan_info[n]["cell"];
							table[n1][n2][n3][n5]["colspan"] = n4;
						}
					}

				}//next rec
//console.log( table);
				
				var html_tbody = "";
				var fvalue = "";
				
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var html_records = "";
					for( num_row = 0; num_row < table[num_rec].length; num_row++ )
					{
						var html_columns = "";
						
						var number = num_rec+1;
						if( num_row == 0 )
						{
							if( xml_records.length > 2 )
							{
								html_columns += cell_checkbox_tpl
								.replace("#value", number )
								.replace("#rowspan", table[num_rec].length)
								.replace("colspan='#colspan'", "");
							}	
							html_columns += cell_number_tpl
							.replace("#value", number )
							.replace("#rowspan", table[num_rec].length)
							.replace("colspan='#colspan'", "");
						}
						
						for( num_col = 0; num_col < table[num_rec][num_row].length; num_col++ )
						{
							var fvalue = table[num_rec][num_row][num_col][0]["value"];
							
							var num_rowspan = 1;
							if( typeof table[num_rec][num_row][num_col][0]["rowspan"] !== "undefined" &&
								table[num_rec][num_row][num_col][0]["rowspan"] > 1)
							{
								num_rowspan = table[num_rec][num_row][num_col][0]["rowspan"];
							}
							//if( typeof table[num_rec][num_row][num_col]["calc_rowspan"] !== "undefined" &&
								//table[num_rec][num_row][num_col]["calc_rowspan"] > 1)

							//{
								//num_rowspan = table[num_rec][num_row][num_col]["calc_rowspan"];
							//}

							if( fvalue == "#rowspan")
							{
								fvalue = "";
							}
							if( fvalue == "#rowspan_aligment")
							{
								fvalue = "";
							}

							var num_colspan = 1;
							if( fvalue.indexOf("#colspan") !== -1)
							{
								fvalue = "";
							}
							if( typeof table[num_rec][num_row][num_col][0]["colspan"] !== "undefined" &&
								table[num_rec][num_row][num_col][0]["colspan"] > 1)
							{
								num_colspan = table[num_rec][num_row][num_col][0]["colspan"];
							}
							if( fvalue.length > 0 )
							{
								fvalue = value_tpl
								.replace("#record_number", number)
								.replace("#value", fvalue);							
								
								html_columns += cell_tpl
								.replace("#value", fvalue )
								.replace("#rowspan", num_rowspan )
								.replace("#colspan", num_colspan );
							}
							
							html_columns = html_columns
							.replace("rowspan='#rowspan'", "")
							.replace("rowspan='1'", "")
							.replace("colspan='1'", "")
							.replace("colspan='#colspan'", "");
						}//next col
						
						//print table record					
						html_records += record_tpl.replace("#columns", html_columns);
					}//next row
					
					html_tbody += tbody_tpl.replace("#records", html_records );
				}//next rec
				
				//html = html.replace("#records", html_records );
				html = html.replace("#tbody", html_tbody );
				
				if( mode !== "answer-mode-view" && 
						mode !== "print")
				{
					var html_list_footer = form_list_footer();
					html = html.replace("#list_footer", html_list_footer );
				}
				else
				{
					html = html.replace("#list_footer", "");
				}
				$(target).append( html );
				
				
				function calc_rowspan( params )
				{
					var num_field_elements = params.num_field_elements;
					var max_rowspan = params.max_rowspan;
					var num_row = params.num_row;
					
					var num_rowspan = 1;
					k = max_rowspan / num_field_elements;
					var index1 = Math.floor(k);
					var index2 = Math.ceil(k);

					var k_shot = k - index1;
					if (k_shot < 0.5  )
					{
						num_rowspan = index1;
						num_last_rowspan = index2;
					}
					else
					{
						num_rowspan = index2;
						num_last_rowspan = index1;
					}

					//last rowspan
					if ( (num_row / num_rowspan ) +1 == num_field_elements)
					{
						num_rowspan = num_last_rowspan;
					}
					
					return num_rowspan;
				}//end calc_rowspan()

				function calc_rowspan_info()
				{
					for(var num_rec = 0; num_rec < table.length; num_rec++)
					{
						for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
						{
//if(z_obj.table_data.columns[num_col]["cancel_rowspan"] === 1)
//{
	//continue;
//}
							var num_calc_rowspan = 1;
							for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
							{
									if( table[num_rec][num_row][num_col][0].value.indexOf("#rowspan_aligment") === -1 )
									{
										var params = {
											num_field_elements: xml_records[num_rec][num_col].length,
											max_rowspan: table[num_rec]["max_length"],
											num_row: num_row
										};							
										
										num_calc_rowspan = calc_rowspan( params );
//console.log(num_rec, num_col, num_row, params, num_calc_rowspan);
	//if( num_calc_rowspan === Infinity)
										if( num_calc_rowspan > 1 )
										{
											table[num_rec][num_row][num_col][0]["calc_rowspan"] = num_calc_rowspan;
										}
									}
							}//next row
						}//next col
					}//next rec
				}//end calc_rowspan_info()
				
				function form_list_footer( presetlist )
				{
					if( typeof z_obj.table_data["presetlist"] === "undefined" ||
							z_obj.table_data["presetlist"].length < 1)
					{
console.log("error, no data for form presetlist");
						z_obj.table_data.log.push("error, no data for form presetlist...");
						return "";
					}
					
					//form select
					var html_options = "";
					for( var n = 0; n < z_obj.table_data["presetlist"].length; n++)
					{
						var preset = z_obj.table_data["presetlist"][n];
						if( typeof preset["selected"] !== "undefined")
						{
							var selected = preset["selected"];
						}
						else
						{
							var selected = 0;
						}
						html_options += list_footer_select_option_tpl
						.replace("#selected", ((selected == 1)? selected:""))
						.replace("#id", preset["presetid"])
						.replace("#type", preset["preset_type"])
						.replace("#preset_name", preset["preset_name"]);
					}//next preset
					html_options = html_options.replace(/selected=''/g, "");
					var list_footer_select = list_footer_select_tpl.replace("#options", html_options);
					
					if( xml_records.length > 2 )
					{
						//var list_footer_button = list_footer_button_tpl;
						var list_footer_button = list_footer_button_tpl.replace(/#target_name/g, target);
					}
					else
					{
						var list_footer_button = "";
					}
					
					var colspan = z_obj.table_data["columns"].length + 2;
					var html = list_footer_tpl
					.replace("#colspan", colspan)
					.replace("#select", list_footer_select)
					.replace("#button", list_footer_button);
					
					return html;
				}//end form_list_footer
				
			}//end draw_table_test()
	
*/		

			function draw_table( xml_records )
			{
				html = table_tpl;
				
				//form THEAD
				var html_thead = "";
				var html_thead_column = "";
				
				if( xml_records.length > 1 )
				{
					html_thead_column += thead_column_tpl.replace("#column_name", "" );
				}	
				html_thead_column += thead_column_tpl.replace("#column_name", "#" );
				
				for( var column in z_obj.table_data["columns"] )
				{
if( typeof z_obj.table_data["columns"][column] === "function")
{
continue;
}//fix							
					var title = z_obj.table_data["columns"][column]["title"];
					html_thead_column += thead_column_tpl.replace("#column_name", title );
				}
				html_thead = thead_tpl.replace("#thead", html_thead_column );
				html = html.replace("#thead", html_thead );
				
				//form TBODY

				//align (replace undefined cols)
				for(var num_rec = 0; num_rec < xml_records.length; num_rec++)
				{
					for( var num_row = 0; num_row < xml_records[num_rec].length; num_row++ )
					{
						for( var num_col = 0; num_col < xml_records[num_rec][num_row].length; num_col++ )
						{
if( typeof xml_records[num_rec][num_row][num_col] === "undefined")
{
//console.log( num_rec, num_row, num_col, xml_records[num_rec][num_row][num_col], typeof xml_records[num_rec][num_row][num_col] );
	xml_records[num_rec][num_row][num_col] = [["#rowspan1"]];
}
						}//next col
					}//next num_row
				}//next rec

				//align (replace undefined cells)
				for(var num_rec = 0; num_rec < xml_records.length; num_rec++)
				{
					for( var num_row = 0; num_row < xml_records[num_rec].length; num_row++ )
					{
						for( var num_col = 0; num_col < xml_records[num_rec][num_row].length; num_col++ )
						{
							for( var num_cell = 0; num_cell < xml_records[num_rec][num_row]["max_size"]; num_cell++ )
							{
if( typeof xml_records[num_rec][num_row][num_col][num_cell] === "undefined")
{
//console.log( num_rec, num_row, num_col, num_cell, xml_records[num_rec][num_row][num_col][num_cell] );
	xml_records[num_rec][num_row][num_col][num_cell] = ["#rowspan3"];
}
							}//next cell
						}//next col
					}//next num_row
				}//next rec
				

				//rebuild xml_records (form column)
				xml_records["rebuild"] = [];
				for(var num_rec = 0; num_rec < xml_records.length; num_rec++)
				{
					xml_records["rebuild"][num_rec] = [];
					for( var num_col = 0; num_col < z_obj.table_data["columns"].length; num_col++ )
					{
						var column = [];
						for( var num_row = 0; num_row < xml_records[num_rec].length; num_row++ )
						{
if( typeof xml_records[num_rec][num_row][num_col] === "undefined")
{
//console.log( num_rec, num_row, num_col, xml_records[num_rec][num_row][num_col] );
	xml_records[num_rec][num_row][num_col] = [["#rowspan4"]];
}
							for( var num_cell = 0; num_cell < xml_records[num_rec][num_row]["max_size"]; num_cell++ )
							{
//console.log( num_rec, num_row, num_col, num_cell, xml_records[num_rec][num_row][num_col][num_cell], xml_records[num_rec][num_row]["max_size"] );
if( typeof xml_records[num_rec][num_row][num_col][num_cell] === "undefined")
{
	xml_records[num_rec][num_row][num_col][num_cell] = ["#rowspan5"];
}
								column.push( xml_records[num_rec][num_row][num_col][num_cell] );
							}//next cell
						}//next num_row
//console.log( num_rec, num_row, num_col, column );
						xml_records["rebuild"][num_rec].push(column);
					}//next col
				}//next rec
				
				//get field values
				var table = [];
				for(var num_rec = 0; num_rec < xml_records["rebuild"].length; num_rec++)
				{
					var max_length = 0;
					for( var num_col in xml_records["rebuild"][num_rec] )
					{
						if( max_length < xml_records["rebuild"][num_rec][num_col].length )
						{
							max_length = xml_records["rebuild"][num_rec][num_col].length;
						}
					}
				
					var row = [];
					for( var num_row = 0; num_row < max_length; num_row++ )
					{
						for( var num_col = 0; num_col < z_obj.table_data.columns.length; num_col++ )
						{
							var field = {};
							var fvalue = "";
							for( var fid in xml_records["rebuild"][num_rec][num_col][num_row])
							{
if( typeof xml_records["rebuild"][num_rec][num_col][num_row][fid] === "function")
{
continue;
}//fix							
								if( fvalue !== "")
								{
									fvalue += "&nbsp;";
								}
								fvalue += xml_records["rebuild"][num_rec][num_col][num_row][fid];
							}//next
							field["value"] = fvalue;
				
							if( typeof row[num_row] == "undefined")
							{
								row[num_row] = [];
							}
							row[num_row].push( field );
						}//next col
					}//next num_row
					
					//table.push( row );
					table[num_rec] = row;
					table[num_rec]["max_length"] = max_length;
				}//next rec
				

				//add rowspan info
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					for( num_col = 0; num_col < z_obj.table_data["columns"].length; num_col++ )
					{
						var num_rowspan = 1;
						var rowspan_info = [];
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
//console.log(num_rec, num_row, num_col, table[num_rec][num_row][num_col]["value"]);
							if( table[num_rec][num_row][num_col]["value"].indexOf("#rowspan") !== -1 )
							{
								if( num_row === 0 )
								{
									table[num_rec][num_row][num_col]["value"] = "#cancel";
								}
								
								num_rowspan++;
if( num_rowspan > 1 && 
	rowspan_info.length > 0)
{
	var index = rowspan_info.length - 1;
	rowspan_info[index]["rowspan"] = num_rowspan;
}
							}

							if( table[num_rec][num_row][num_col]["value"].indexOf("#rowspan") === -1 )
							{
								var rowspan_pos = {
								"record" : num_rec,
								"row" : num_row,
								"column" : num_col
								};
								rowspan_info.push( rowspan_pos );
								num_rowspan = 1;
							}
							
						}//next row
//console.log(rowspan_info);
						
						if( rowspan_info.length > 0 )
						{
for( var n = 0; n < rowspan_info.length; n++ )
{
	if( typeof rowspan_info[n]["rowspan"] !== "undefined" &&
		rowspan_info[n]["rowspan"]	> 1)
	{
		var rec = rowspan_info[n]["record"];
		var row = rowspan_info[n]["row"];
		var col = rowspan_info[n]["column"];
		var rowspan = rowspan_info[n]["rowspan"];
		table[rec][row][col]["rowspan"] = rowspan;
	}
}						
						}
						
					}//next col
				}//next rec

				//calc rowspan info (uniform alignment values column)
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					process_aligment_rowspan( num_rec );
				}//next rec
				
				//group limit-message by id
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var message_id = "";
					for( num_col = 0; num_col < z_obj.table_data["columns"].length; num_col++ )
					{
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("limit-message") !== -1 )
							{
//filter, remove #colspan and &nbsp;							
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col]["value"].replace(/#colspan/g,"");
table[num_rec][num_row][num_col]["value"] = table[num_rec][num_row][num_col]["value"].replace(/&nbsp;/g,"");
//console.log(num_rec, num_row, num_col, message_id);
								if( message_id === $( table[num_rec][num_row][num_col]["value"] ).attr("data-id") )
								{
									table[num_rec][num_row][num_col]["value"] = "#colspan";
								}
								else
								{
									message_id = $( table[num_rec][num_row][num_col]["value"] ).attr("data-id");
								}
							}
						
						}//next row
					}//next col
				}//next rec



				//add colspan info
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var num_colspan = 1;
					var colspan_pos = 0;
					var colspan_info = [];
					for( num_row = 0; num_row < table[num_rec].length; num_row++ )
					{
						for( num_col = 0; num_col < z_obj.table_data["columns"].length; num_col++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("#colspan") !== -1)
							{
								if( num_colspan == 1)
								{
									var colspan_start_pos = num_col-1;
									if( colspan_start_pos < 0)
									{
										colspan_start_pos = 0;
									}
									var colspan_pos = {
									"num_record" : num_rec,
									"num_row" : num_row,
									"num_column" : colspan_start_pos
									};
									colspan_info.push( colspan_pos );
								}
								num_colspan++;
//console.log(num_rec, num_row, num_col, num_colspan);
							}
						
						}//next col
					}//next row
					
					if( num_colspan > 1 )
					{
						if( typeof colspan_pos == "object" )
						{
							colspan_pos["num_colspan"] = num_colspan;
						}
						num_colspan = 1;
						colspan_pos = 0;
					}
					if( colspan_info.length > 0 )
					{
						for(var n = 0; n < colspan_info.length; n++)
						{
							var n1 = colspan_info[n]["num_record"];
							var n2 = colspan_info[n]["num_row"];
							var n3 = colspan_info[n]["num_column"];
							var n5 = colspan_info[n]["num_colspan"];
							table[n1][n2][n3]["colspan"] = n5;
						}
					}
				}//next rec

//console.log(table);
				
				var html_tbody = "";
				for(var num_rec = 0; num_rec < table.length; num_rec++)
				{
					var html_records = "";
					for( num_row = 0; num_row < table[num_rec].length; num_row++ )
					{
						var html_columns = "";
						var number = num_rec+1;
						if( num_row == 0 )
						{
							if( xml_records.length > 1 )
							{
								html_columns += cell_checkbox_tpl
								.replace("#value", number )
								.replace("#rowspan", table[num_rec].length)
								.replace("colspan='#colspan'", "");
							}	
							html_columns += cell_tpl
							.replace("#value", number )
							.replace("#rowspan", table[num_rec].length)
							.replace("colspan='#colspan'", "");
						}
						for( num_col = 0; num_col < table[num_rec][num_row].length; num_col++ )
						{
							var fvalue = table[num_rec][num_row][num_col]["value"];
							var num_rowspan = 1;
							if( typeof table[num_rec][num_row][num_col]["rowspan"] !== "undefined" &&
								table[num_rec][num_row][num_col]["rowspan"] > 1)
							{
								num_rowspan = table[num_rec][num_row][num_col]["rowspan"];
							}
							if( typeof table[num_rec][num_row][num_col]["calc_rowspan"] !== "undefined" &&
								table[num_rec][num_row][num_col]["calc_rowspan"] > 1)
							{
								num_rowspan = table[num_rec][num_row][num_col]["calc_rowspan"];
							}
							
							
							if( fvalue.indexOf("#rowspan") !== -1 )
							{
								fvalue = "";
							}
							if( fvalue === "#cancel")
							{
								fvalue = "&nbsp;";
							}
							if( fvalue.indexOf("#fix") !== -1 )
							{
								fvalue = "&nbsp;";
							}

							var num_colspan = 1;
							if( typeof table[num_rec][num_row][num_col]["colspan"] !== "undefined" &&
								table[num_rec][num_row][num_col]["colspan"] > 1)
							{
								num_colspan = table[num_rec][num_row][num_col]["colspan"];
							}
							if( fvalue.indexOf("#colspan") !== -1)
							{
								fvalue = "";
							}
							
							if( fvalue.length > 0 )
							{
								fvalue = value_tpl
								.replace("#record_number", number)
								.replace("#value", fvalue);							
								
								html_columns += cell_tpl
								.replace("#value", fvalue )
								.replace("#rowspan", num_rowspan )
								.replace("#colspan", num_colspan );
							}
							
							html_columns = html_columns
							.replace("rowspan='#rowspan'", "")
							.replace("rowspan='1'", "")
							.replace("colspan='1'", "")
							.replace("colspan='#colspan'", "");
						
						}//next col
						html_records += record_tpl.replace("#columns", html_columns);
					}//next row

					html_tbody += tbody_tpl.replace("#records", html_records );
					
				}//next rec
				html = html.replace("#tbody", html_tbody );
				
				if( mode !== "answer-mode-view" && 
						mode !== "print")
				{
					var html_list_footer = form_list_footer();
					html = html.replace("#list_footer", html_list_footer );
				}
				else
				{
					html = html.replace("#list_footer", "");
				}
		
				$(target).append( html );

				function form_list_footer( presetlist )
				{
					if( typeof z_obj.table_data["presetlist"] === "undefined" ||
							z_obj.table_data["presetlist"].length < 1)
					{
console.log("error, no data for form presetlist");
						z_obj.table_data.log.push("error, no data for form presetlist...");
						return "";
					}
					
					//form select
					var html_options = "";
					for( var n = 0; n < z_obj.table_data["presetlist"].length; n++)
					{
						var preset = z_obj.table_data["presetlist"][n];
						if( typeof preset["selected"] !== "undefined")
						{
							var selected = preset["selected"];
						}
						else
						{
							var selected = 0;
						}
						html_options += list_footer_select_option_tpl
						.replace("#selected", ((selected == 1)? selected:""))
						.replace("#id", preset["presetid"])
						.replace("#type", preset["preset_type"])
						.replace("#preset_name", preset["preset_name"]);
					}//next preset
					html_options = html_options.replace(/selected=''/g, "");
					var list_footer_select = list_footer_select_tpl.replace("#options", html_options);
					
					if( xml_records.length > 2 )
					{
						var list_footer_button = list_footer_button_tpl.replace(/#target_name/g, target);
					}
					else
					{
						var list_footer_button = "";
					}
					
					var colspan = z_obj.table_data["columns"].length + 2;
					var html = list_footer_tpl
					.replace("#colspan", colspan)
					.replace("#select", list_footer_select)
					.replace("#button", list_footer_button);
					
					return html;
				}//end form_list_footer

				function process_aligment_rowspan( num_rec )
				{
					//detect related columns
					for( var num_col = 0; num_col < z_obj.table_data["columns"].length; num_col++)
					{
						if( num_col < (z_obj.table_data["columns"].length - 1) )
						{
							var num1 = num_col;
							var num2 = num_col + 1;
//console.log(num1, z_obj.table_data["columns"][num_col]["title"] + " related "+ num2, z_obj.table_data["columns"][num_col+1]["title"]+ " ?");

							for( var num_block_columns = 0; num_block_columns < z_obj.table_data["columns_info"].length; num_block_columns++ )
							{
								var related = res1 = res2 = false;
								var block_columns = z_obj.table_data["columns_info"][num_block_columns];
								for( var n1 = 0; n1 < block_columns["columns"].length; n1++ )
								{
									if( num1 === block_columns["columns"][n1]["index"])
									{
										res1 = true;
									}
									if( num2 === block_columns["columns"][n1]["index"])
									{
										res2 = true;
									}
								}//next column
								
								if( res1 && res2)
								{
									related = true;
//console.log(n1, related, res1, res2);
									break;
								}
//console.log(n1, related, res1, res2);
							}//next block_columns
							
//console.log(num_rec, num_col, z_obj.table_data["columns"][num_col]["title"] + " related " +  z_obj.table_data["columns"][num_col+1]["title"]+ " ?", related);
							//calc and apply rowspan for column
							if( !related )
							{
								alignment_rowspan( num_rec, num_col );
							}
						}
						else
						{
							alignment_rowspan( num_rec, num_col );
						}
						
					}//next column

					function calculate_rowspan( params )
					{
						var num_field_elements = params.num_field_elements;
						var max_rowspan = params.max_rowspan;
						k = max_rowspan / num_field_elements;
						var rowspan_info = {
							"num_rowspan": Math.floor(k),
							"num_last_rowspan": Math.ceil(k)
						};
						return rowspan_info;
					}//end calc_rowspan()

					function alignment_rowspan( num_rec, num_col )
					{
						var num_values = 0;
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("#rowspan") === -1 )
							{
//console.log(num_rec, num_row, num_col, table[num_rec][num_row][num_col]  );
								num_values++;
							}
						}
//console.log( num_values  );

						//calc rowspan
						var rowspan_info = [];
						var params = {
							num_field_elements: num_values,
							max_rowspan: table[num_rec]["max_length"]
						};							
						var rowspan_info = calculate_rowspan( params );
//console.log( params, rowspan_info  );
						
						//move values
						var column = [];
						var count_values = 0;
						for( num_row = 0; num_row < table[num_rec].length; num_row++ )
						{
							if( table[num_rec][num_row][num_col]["value"].indexOf("#rowspan") === -1 )
							{
								count_values++;
								
								var obj = {};
								obj["value"] = table[num_rec][num_row][num_col]["value"];
								obj["calc_rowspan"] = rowspan_info["num_rowspan"];
								if( count_values === num_values )
								{
									obj["calc_rowspan"] = rowspan_info["num_last_rowspan"];
									
									//fix, limit message in last cell !!! cancel rowspan
									if( obj["value"].indexOf("limit-message") !== -1 )
									{
										var num_repeat = table[num_rec]["max_length"] - num_values;
										//for(var index = 0; index < (obj["calc_rowspan"]-1); index++)
										for(var index = 0; index < num_repeat; index++)
										{
											var rowspan_obj = {value:"#fix " + num_repeat};
											column.push( rowspan_obj );
										}
										obj["calc_rowspan"] = 0;
									}
									
								}
								column.push( obj );
								
								for(var index = 0; index < (obj["calc_rowspan"] - 1); index++)
								{
									var rowspan_obj = {value:"#rowspan6"};
									column.push( rowspan_obj );
								}
								
							}
						}//next row
						
						if( column.length > 0)
						{
							//fix (remove empty cells)
							if( column.length < table[num_rec]["max_length"] )
							{
								var num_add_cells = table[num_rec]["max_length"] - column.length;
								var cell_value = "#rowspan7";
								
								for( var n = 0; n < num_add_cells; n++)
								{
									var rowspan_obj = {value: cell_value };
									column.push( rowspan_obj );
								}
								
								var n_values = 0;
								for( var n = 0; n < column.length; n++)
								{
									if( column[n]["value"].indexOf("#rowspan") === -1 )
									{
										n_values++;
										if( n_values === num_values )//detect last values
										{
											column[n]["calc_rowspan"] = column[n]["calc_rowspan"] + num_add_cells;
										}
									}
								}
							}
							
							//replace column values
							for( var num_row = 0; num_row < table[num_rec].length; num_row++ )
							{
//console.log(num_rec, num_row, num_col, table[num_rec][num_row][num_col], column[num_row], table[num_rec].length  );
								table[num_rec][num_row][num_col] = column[num_row];
							}
						}						
//console.log( column );
					}//end alignment_rowspan()				
				
				}//end process_aligment_rowspan()				
				
			}//end draw_table()

		};//end _build()
		
		
		
		var _build_detail_block = function( build_params ){
			var block_id = build_params["block_id"];
			var xbr_id = build_params["xbr_id"];
			var target = build_params["target"];
			var expand = build_params["expand"];
			var show_log = build_params["show_log"];
			var reload = build_params["reload"];
			var mode = build_params["mode"];
		
			if( typeof block_id !== "string" ||
				typeof xbr_id !== "string" )
			{
console.log("build_detail_block, error in params", arguments);				
				return;
			}
			
			//test, need # in block_id
			if( block_id.indexOf("#") == -1)
			{
				block_id = "#" + block_id;
			}
			if( xbr_id.indexOf("#") == -1)
			{
				xbr_id = "#" + xbr_id;
			}
			
			if( typeof expand === "undefined" )
			{
				var expand = 0;
			}
		
			var exec_start = new Date();

			z_obj.get_detail_block( block_id, xbr_id, reload );
			if ( z_obj.table_data["detail_blocks"][block_id]["columns"].length == 0)
			{
console.log( "error, table_data[detail_blocks] is empty ");
				return;
			}
console.log( z_obj.table_data );

			if( typeof mode === "undefined")
			{
				z_obj.table_data["detail_blocks"][block_id]["block_info"]["mode"] = "";
			}
			if( typeof mode === "string")
			{
				//if( mode.indexOf("print") !== -1 ||
					//mode.indexOf("answer-mode-view") !== -1)				
				//{
					//expand = 1;
				//}
				z_obj.table_data["detail_blocks"][block_id]["block_info"]["mode"] = mode;
			}
			
			var html = css;
			html += draw_block( z_obj.table_data["detail_blocks"][block_id], block_id, xbr_id );
			$(target).html( html );
			
			if( z_obj.table_data["detail_blocks"][block_id]["block_info"]["ea"] == 1 )
			{
				if(expand === 0)
				{
					//$(target).find(".block-list-header-exp").hide();
					//$(target).find("tbody").hide();
					$(target).find(".block-title-exp .doc-select").hide();
					$(target).find(".block-title-exp .doc-button").hide();
				}
			}
			
			var exec_end = new Date();
			var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
			if (show_log == 1)
			{
				z_obj.table_data.log.push("Summary runtime (zlist.build_detail_block): " + runtime_s + " sec");
				var log_html = "";
				log_html += "<ul id='log'>";
				for(var n1 = 0; n1 < z_obj.table_data["log"].length; n1++)
				{
					if(n1 > 0)
					{
						log_html += "<br>";//"&nbsp;&nbsp;";
					}
					log_html += z_obj.table_data["log"][n1];
				}
				log_html += "</ul>";
				$(target).append( log_html );
				z_obj.table_data.log = [];
			}

			function draw_block( block, block_id, xbr_id )
			{
				//analytic process
				var add_analytic = 0;
				var	analytic_column = "";
				if( typeof block["block_info"]["analytic"] !== "undefined")
				{
					if( typeof block["block_info"]["xb_attributes"] !== "undefined" )
					{
						if( typeof block["block_info"]["xb_attributes"]["plugin_generated"] === "undefined")
						{
							add_analytic = 1;
						}
					}
					else
					{
						add_analytic = 1;
					}
				}
				if( add_analytic === 1 )
				{
					analytic_column = analytic_column_tpl.replace("#analytic_value", block["block_info"]["analytic"]);
				}

				//process block title link (xhref)
				var add_title_link = 0;
				if( typeof block["block_info"]["xhref"] !== "undefined")
				{
					add_title_link = 1;
				}
				
				if( typeof block["block_info"]["mode"] !== "undefined" )
				{
					if( block["block_info"]["mode"].indexOf("print") !== -1 ||
						block["block_info"]["mode"].indexOf("answer-mode-view") !== -1)				
					{
						//if( typeof block["block_info"]["expandable"] !== "undefined" )
						if( typeof block["block_info"]["ea"] !== "undefined" )
						{
							//delete block["block_info"]["expandable"];
							//delete block["block_info"]["ea"];
							block["block_info"]["ea"] = 0;
						}
					
						if( typeof block["block_info"]["pform"] !== "undefined" )
						{
							delete block["block_info"]["pform"];
						}
						
						if( typeof block["block_info"]["xhref"] !== "undefined" )
						{
							delete block["block_info"]["xhref"];
						}
						
						if( typeof block["block_info"]["xref"] !== "undefined" )
						{
							delete block["block_info"]["xref"];
						}
						
						if( typeof block["block_info"]["ref"] !== "undefined" )
						{
							delete block["block_info"]["ref"];
						}
						
						if( typeof block["block_info"]["active_row"] !== "undefined" )
						{
							delete block["block_info"]["active_row"];
						}
						
						add_analytic = 0;
						add_title_link = 0;
					}
				}
				
				//form block title
				var block_html = "";
				var title_tpl = block_table_title_tpl;
				var icon=pform=button="";
				var header_class = block_header_class;
				
				//if( typeof block["block_info"]["expandable"] !== "undefined" )
				//{
					if( block["block_info"]["ea"] == 1 )
					{
						var title_tpl = block_table_expandable_title_tpl;
						header_class = block_expandable_header_class;
						var icon_src=icon_state="";
						
						if( expand === 0 )//down state
						{
							icon_src = block_table_expandable_icon_down_src_tpl;
							icon_state = block_table_expandable_icon_down_state_tpl;
						}
						
						if( expand === 1 )//up state
						{
							icon_src = block_table_expandable_icon_up_src_tpl;
							icon_state = block_table_expandable_icon_up_state_tpl;
						}
						
						icon = block_table_expandable_icon_tpl
						.replace(/#block_id/g, block_id.replace("#","") )
						.replace(/#first_xbr_id/g, block["records"]["ch_xbr_id"][0])
						.replace("#icon-src", icon_src)
						.replace("#state", icon_state)
						.replace("#target", target.id );
					}
				//}				
				
				if( typeof block["block_info"]["pform"] !== "undefined" )
				{
					var html_options = "";
					for(var pform_id in block["block_info"]["pform"])
					{
if( typeof block["block_info"]["pform"][pform_id] !== "object")
{
continue;
}//fix							
						var print_form_id = block["block_info"]["pform"][pform_id]["id"];
						var pform_title = block["block_info"]["pform"][pform_id]["title"];
						
						var pform_cond_f = pform_cond_v = "";
						if( typeof block["block_info"]["pform"][pform_id]["cond_f"] !== "undefined")
						{
							pform_cond_f = block["block_info"]["pform"][pform_id]["cond_f"];
						}
						if( typeof block["block_info"]["pform"][pform_id]["cond_v"] !== "undefined")
						{
							pform_cond_v = block["block_info"]["pform"][pform_id]["cond_v"];
						}
						
						html_options += block_table_pform_option_tpl
						.replace("#pform_id", print_form_id)
						.replace("#pform_cond_f", pform_cond_f)
						.replace("#pform_cond_v", pform_cond_v)
						.replace("cond_f=''", "")
						.replace("cond_v=''", "")
						.replace("#pform_title", pform_title);
						
					}//next pform

					pform = block_table_pform_select_tpl
						.replace("#block_id", block_id.replace("#","") )
						.replace("#xbr_id", xbr_id.replace("#",""))
						.replace("#options", html_options);
						
					button = block_table_pform_button_tpl
						.replace(/#block_id/g, block_id.replace("#","") )
						.replace(/#xbr_id/g, xbr_id.replace("#",""));
				}
						
				if( block["block_info"]["numbered"] == 1)
				{	
					//html_thead += thead_column_tpl.replace("#column_name", "" );
					column = {"title":""};
					block["columns"].unshift( column );
				}				
				if( add_analytic == 1)
				{	
					//html_thead += thead_column_tpl.replace("#column_name", "analytic" );
					column = {"title":""};
					block["columns"].unshift( column );
				}				

				var title_link = "";
				if( add_title_link == 1)
				{	
					var xform_name = z_obj.table_data["xml_info"]["xform_name"];
					var xblock_name = block["block_info"]["name"];
					for(var item in block["block_info"]["xhref"])
					{
						if( block["block_info"]["xhref"][item]["scope"] ===  "answer" ||
								block["block_info"]["xhref"][item]["scope"] ===  "both")
						{
							var url = block["block_info"]["xhref"][item]["url"];
							url = url
							.replace(":formname", xform_name)
							.replace(":blockname", xblock_name)
							.replace(":mode", "answer")
							.replace("&amp;", "&");							
							
							var text = block["block_info"]["xhref"][item]["text"];
							title_link += block_table_title_link_tpl
							.replace("#url", url)
							.replace("#text", text);
						}
					}
				}				
				
				var title = title_tpl
				.replace("#colspan", block["columns"].length + 1)
				.replace("#icon", icon)
				.replace("#pform", pform )
				.replace("#btn", button )
				.replace("#title-link", title_link )
				.replace("#title-text", block["title"] );

				block_html += block_table_tpl.replace("#title", title );

				//if( block["block_info"]["ea"] == 1 )
				if( typeof block["block_info"]["ea"] !== "undefined" )
				{
					if( expand === 0 )
					{
block_html = block_html
.replace("<tr class='#header_class'>#thead</tr>", "")
.replace("#tbody", "");
						return block_html;
					}
				}

				
				//form THEAD
				var html_thead = "";
				
				for(var column in block["columns"])
				{
if(typeof block["columns"][column] == "object")
{
					html_thead += thead_column_tpl.replace("#column_name", block["columns"][column]["title"] );
}//fix
				}
				block_html = block_html
				.replace("#thead", html_thead )
				.replace("#header_class", header_class );

				//form TBODY
				
				//get field values
				var fields = [];
				
				for(var n = 0; n < block["records"].length; n++)
				{
					var max_length = 0;
					for( var fid in block["records"][n] )
					{
if( typeof block["records"][n][fid] == "object" )
{
						if( max_length < block["records"][n][fid].length)
						{
							max_length = block["records"][n][fid].length;
						}
}//fix						
					}//next xf
					
					//add line for calc rowspan
					var row = [];
					for( num_row = 0; num_row < max_length; num_row++ )
					{
						for( var fid in block["records"][n] )
						{
if( typeof block["records"][n][fid] !== "object")
{
	continue;
}//fix							
							var field = {};
							if( typeof block["records"][n][fid][num_row] !== "undefined")
							{
								field["id"] = fid;
								field["value"] = block["records"][n][fid][num_row];
							}
							else
							{
								field["id"] = fid;
								field["value"] = "#rowspan";

								if(block["records"][n][fid][num_row-1] === "&nbsp;")
								{
									field["value"] = "&nbsp;";
								}
							}

							if( typeof row[num_row] == "undefined")
							{
								row[num_row] = [];
							}
							row[num_row].push( field );
						}//next xf
						
						if( block["block_info"]["numbered"] == 1)
						{	
							var field_num = {
								"value": ""+ (n+1) + ".", 
								"type": "number"
							};
							var fvalue = "";
							for( var n2 = 0; n2 < row[num_row].length; n2++ )
							{
								fvalue = row[num_row][n2].value;
								//do not print number of record for limit message
								if( typeof fvalue == "string" && 
									fvalue.indexOf("limit-message") !== -1 )	
								{
									var field_num = {"value": "" };
								}
							}
							row[num_row].unshift( field_num );
						}				
						if( add_analytic == 1)
						{	
							analytic_column_code = analytic_column.replace("#xbr_id", block["records"]["ch_xbr_id"][n]);
							var field_analytic = {"value": analytic_column_code	};
							if( typeof block["records"]["ch_xbr_id"][n] === "undefined")
							{
								field_analytic = {"value":"&nbsp;"};
							}
							row[num_row].unshift( field_analytic );
						}				
						
					}//next num_row
					
					fields.push( row );
				}//next rec
				
console.log( fields);

				//add rowspan info
				for(var num_rec = 0; num_rec < fields.length; num_rec++)
				{
					for( num_col = 0; num_col < block["columns"].length; num_col++ )
					{
//if( typeof block["columns"][column] === "object")
//{
						var num_rowspan = 1;
						for( num_row = 0; num_row < fields[num_rec].length; num_row++ )
						{
							if( fields[num_rec][num_row][num_col]["value"] === "#rowspan")
							{
								num_rowspan++;
							}
						}//next row
						
						if( num_rowspan > 1)
						{
							fields[num_rec][0][num_col]["rowspan"] = num_rowspan;
						}
//}//fix							
					}//next col
				}//next rec
				
				//group limit-message by id
				var message_id = "";
				for(var num_rec = 0; num_rec < fields.length; num_rec++)
				{
					for( num_col = 0; num_col < block["columns"].length; num_col++ )
					{
						for( num_row = 0; num_row < fields[num_rec].length; num_row++ )
						{
							if( fields[num_rec][num_row][num_col]["value"].indexOf("limit-message") !== -1 )
							{
								if( message_id === $( fields[num_rec][num_row][num_col]["value"] ).attr("data-id") )
								{
									fields[num_rec][num_row][num_col]["value"] = "#colspan";
								}
								else
								{
									message_id = $( fields[num_rec][num_row][num_col]["value"] ).attr("data-id");
								}
							}
						}//next row
					}//next col
				}//next rec

				//add colspan info
				for(var num_rec = 0; num_rec < fields.length; num_rec++)
				{
					var num_colspan = 1;
					var colspan_pos = 0;
					var colspan_info = [];
					for( num_col = 0; num_col < block["columns"].length; num_col++ )
					{
						for( num_row = 0; num_row < fields[num_rec].length; num_row++ )
						{
							if( fields[num_rec][num_row][num_col]["value"] === "#colspan")
							{
								if( num_colspan == 1)
								{
									var colspan_start_pos = num_col-1;
									if( colspan_start_pos < 0)
									{
										colspan_start_pos = 0;
									}
									var colspan_pos = {
									"record" : num_rec,
									"row" : num_row,
									"column" : colspan_start_pos
									};
									colspan_info.push( colspan_pos );
								}
								num_colspan++;
							}
							
							if( (fields[num_rec][num_row][num_col]["value"] !== "#colspan") ||
									(fields[num_rec][num_row][num_col]["value"] === "#colspan" && 
										num_col == block["columns"].length-1 )
								)
							{
								if( num_colspan > 1 )
								{
									if( typeof colspan_pos == "object" )
									{
										colspan_pos["colspan"] = num_colspan;
									}
									num_colspan = 1;
									colspan_pos = 0;
								}
							}
						}//next row
					}//next col
					
					if( colspan_info.length > 0 )
					{
						for(var n = 0; n < colspan_info.length; n++)
						{
							var n1 = colspan_info[n]["record"];
							var n2 = colspan_info[n]["row"];
							var n3 = colspan_info[n]["column"];
							var n4 = colspan_info[n]["colspan"];
							fields[n1][n2][n3]["colspan"] = n4;
						}
					}
					
				}//next rec
//console.log( fields);

				//form tbody html
				var html_records = "";
				var fvalue = "";
				for(var num_rec = 0; num_rec < fields.length; num_rec++)
				{
					var html_tbody = "";
					for( num_row = 0; num_row < fields[num_rec].length; num_row++ )
					{
						var html_columns = "";
						var html_number = block_first_column_tpl.replace("#value", num_rec+1 );
						for( num_col = 0; num_col < fields[num_rec][num_row].length; num_col++ )
						{
							var fvalue = fields[num_rec][num_row][num_col]["value"];
							if( fvalue == "#rowspan")
							{
								fvalue = "";
							}
							if( fvalue == "#colspan")
							{
								fvalue = "";
							}
							
							var num_rowspan = 1;
							if( typeof fields[num_rec][num_row][num_col]["rowspan"] !== "undefined" &&
								fields[num_rec][num_row][num_col]["rowspan"] > 1)
							{
								num_rowspan = fields[num_rec][num_row][num_col]["rowspan"];
							}
							
							var num_colspan = 1;
							if( typeof fields[num_rec][num_row][num_col]["colspan"] !== "undefined" &&
								fields[num_rec][num_row][num_col]["colspan"] > 1)
							{
								num_colspan = fields[num_rec][num_row][num_col]["colspan"];
								if( block["block_info"]["numbered"] == 1)
								{	
									num_colspan++;
								}				
								
							}
							
							if( fvalue.length > 0 )
							{
								//do not print number of record for limit message
								if( typeof fvalue == "string" && 
									fvalue.indexOf("limit-message") !== -1 )	
								{
									//html_number = "";
									var add_link_next_pages = 1;
								}
								
								var cell_tpl = block_cell_field_value_tpl;
								//change template for analytic cell
								if( typeof fvalue == "string" && 
									fvalue.indexOf("analytic") !== -1 )	
								{
									cell_tpl = block_cell_tpl;
								}
								//change template for number cell
								if( typeof fields[num_rec][num_row][num_col]["type"] !== "undefined" && 
									fields[num_rec][num_row][num_col]["type"] == "number" )	
								{
									cell_tpl = block_cell_tpl;
								}
								
								html_columns += cell_tpl
								.replace("#value", fvalue )
								.replace("#rowspan", num_rowspan )
								.replace("#colspan", num_colspan );
							}
							
							html_columns = html_columns
							.replace("rowspan='#rowspan'", "")
							.replace("rowspan='1'", "")
							.replace("colspan='1'", "")
							.replace("colspan='#colspan'", "");
							
						}//next col
					
						//if( block["block_info"]["numbered"] == 1)
						//{	
							//html_columns = html_number + html_columns;
						//}				
						//add analytic_column				
						//if( add_analytic == 1 )				
						//{
							//html_columns = analytic_column + html_columns;
						//}
						
						html_tbody += record_tpl.replace("#columns", html_columns );
					}//next row

					//print table record					
					var tbody_tpl = block_table_tbody_tpl;
					
					//process active row
					if( typeof block["block_info"]["active_row"] !== "undefined" && 
						block["block_info"]["active_row"].length > 0 )
					{
						tbody_tpl = block_table_active_row_tbody_tpl;
					}
					
					//process ref info
					var ref_name = "";
					var ref_name_text = "";
					if( typeof block["block_info"]["ref"] !== "undefined" && 
						block["block_info"]["ref"].length > 0 )
					{
						tbody_tpl = block_table_ref_tbody_tpl;
						ref_name = block["block_info"]["ref"];
					}

					if( typeof block["block_info"]["xref"] !== "undefined" && 
						block["block_info"]["xref"].length > 0 )
					{
						tbody_tpl = block_table_ref_tbody_tpl;
						ref_name = block["block_info"]["xref"];
					}
					
					if( ref_name.length > 0)
					{
						for(var xref_num = 0; xref_num < z_obj.table_data["xml_info"]["xreference"]["xref"].length; xref_num++)
						{
							if( ref_name === z_obj.table_data["xml_info"]["xreference"]["xref"][xref_num]["name"] )
							{
								ref_name_text = z_obj.table_data["xml_info"]["xreference"]["xref"][xref_num]["text"];
							}
						}
					}
					html_records += tbody_tpl
						.replace("#ref_name", ref_name)
						.replace("#ref_name_text", ref_name_text)
						.replace("#ch_xbr_id", block["records"]["ch_xbr_id"][num_rec])
						.replace("#records", html_tbody);
					
				}//next rec
				
				//undo pager for print mode
				if( block["block_info"]["mode"] === "print" ||
						block["block_info"]["mode"] === "answer-mode-view")
				{
					add_link_next_pages = 0;
				}
				if( add_link_next_pages === 1 )
				{
					var first_xbr_id = block["records"]["ch_xbr_id"][0];
					var num_columns = block["columns"].length;
					var block_id_number = block_id.replace("#","");
					var xbr_id_number = xbr_id.replace("#","");
					
					html_records += block_bottom_link_tpl
					.replace("#colspan", num_columns + 1)
					.replace("#xbr_id", first_xbr_id)
					.replace("#block_id", block_id_number)
					.replace(/#block_title/g, block["title"] );
				}
				
				block_html = block_html.replace("#tbody", html_records );
				
				return block_html;
			};//end draw_block()

			
		};//end _build_detail_block()
	
		function _toggle_block( target, expand )
		{
//console.log(arguments);		
			if( expand === 0 )//down state
			{
				$(target).find(".block-list-header-exp").hide();
				$(target).find("tbody").hide();
				var img = $(target).find(".block-title-exp img");
				$(img).attr("src", block_table_expandable_icon_down_src_tpl);
				$(img).attr("state", block_table_expandable_icon_down_state_tpl);
			}
			if( expand === 1 )//up state
			{
				$(target).find(".block-list-header-exp").show();
				$(target).find("tbody").show();
				var img = $(target).find(".block-title-exp img");
				$(img).attr("src", block_table_expandable_icon_up_src_tpl);
				$(img).attr("state", block_table_expandable_icon_up_state_tpl);
				$(target).find(".block-title-exp .doc-select").show();
				$(target).find(".block-title-exp .doc-button").show();
			}
		};//end _toggle_block()

		function _show_selected_record( target )
		{
			var count=0;
			var num_group = 0;
			$(target).find(".table-list-group").each(function(){
				var input = $(this).find("input[type=checkbox]");
				var checked = $(input).is(":checked");
//console.log( input, checked );		
				if( !checked )
				{
					$(this).hide();
					count++;
				}
				num_group++;
			});
			
			$(target).find("input[name=bShowSelected2]").hide();
			$(target).find("input[name=bShowAll2]").show();
				
			if( count === num_group )
			{
				$(target).find(".table-list-group").show();
				$(target).find("input[name=bShowSelected2]").show();
				$(target).find("input[name=bShowAll2]").hide();
			}
		};//end show_selected_record()
		
		function _show_all_record( target )
		{
			$(target).find(".table-list-group").each(function(){
				var input = $(this).find("input[type=checkbox]");
				$(input).prop('checked',false);
			});
			$(target).find(".table-list-group").show();
			$(target).find("input[name=bShowSelected2]").show();
			$(target).find("input[name=bShowAll2]").hide();
		};//end show_all_record()
		
		// public interfaces
		return{
			//xml:_xml,
			revision:_repositoryRevision,
			build:	function( params ){ 
				return _build( params ); 
			},
			build_detail_block:	function( build_params){ 
				return _build_detail_block( build_params ); 
			},
			toggle_block: function( target, expand ){
				return _toggle_block( target, expand );
			},
			show_selected_record: function( target ){
				return _show_selected_record( target );
			},
			show_all_record: function( target ){
				return _show_all_record( target );
			}
			
		};
	};
	
	window.ZList = ZList;
})();

//fix ie8 
if (!window.console){ console = {log: function() {}} };
/*
if(Array.prototype.item == undefined)
{
	Array.prototype.item = function(i) { return this[i]; }
}
*/
