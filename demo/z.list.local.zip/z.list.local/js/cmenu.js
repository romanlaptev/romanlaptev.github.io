// alert("loading cmenu.js ..");

//var __cmenu_object = null;

function cmenu(uname, title, doc, force_create){
	if(force_create == undefined) force_create = false;
	this.doc = document;
	if(doc != undefined) this.doc = doc;

	if(!force_create && this.doc.all['_cmenu_' + uname]) return this;

	this.uname = uname;
if( navigator.userAgent.toLowerCase().indexOf("msie 7.0") !== -1 )
{
	this.div = this.doc.createElement("<div id='_cmenu_" + this.uname + "' class='cmenu'></div>");
}
else
{	
	//fix
	this.div = this.doc.createElement("div");
	this.div.setAttribute('id', '_cmenu_' + this.uname);	
	this.div.setAttribute('class', 'cmenu');	
}
	
	this.menu_title = undefined;

	if(title != undefined){
	
if( navigator.userAgent.toLowerCase().indexOf("msie 7.0") !== -1 )
{
		this.menu_title = this.doc.createElement("<div class='cmenu-title'></div>");
		this.menu_title.innerText = title; //only IE
}
else
{
		//fix
		this.menu_title = this.doc.createElement("div");
		this.menu_title.setAttribute('class', 'cmenu-title');	
		this.menu_title.innerHTML = title;
}
		//fix
		this.menu_title.style.width	= "auto";
		
		this.div.appendChild(this.menu_title);
	}

	this.doc.body.appendChild(this.div);

	this.doconkeydown	= undefined;
	this.doconclick		= undefined;

	this.state = '0';

	this.show =
	function _show(x, y){


		this.div.style.left		= 1;
		this.div.style.top		= 1;

		// hide other cmenu if any
		if(this.state == '1')
			this.hide();

		// save document.onkeydown & document.onclick
		this.doconkeydown	= this.doc.onkeydown;
		this.doconclick		= this.doc.onclick;


		// set __object to `this` in order to have access to the cmenu in onkeydown, onclick, etc.
//		__cmenu_object = this;

		this.keydown.cmenu = this;
		this.doc.onkeydown	= this.keydown;

		this.docclick.cmenu = this;
		this.doc.onclick	= this.docclick;

		//document.onmousedown = this.docclick;
		this.div.style.display	= "inline";
		
					//fix
					this.div.style.width	= "auto";

		var clientHeight = this.doc.body.clientHeight;
		var clientWidth = this.doc.body.clientWidth;
		var _x = x;
		if(!_x)
			_x = (clientWidth/2) - (this.div.offsetWidth/2);
		var _y = y;
		if(!_y)
			_y = (clientHeight/2) - (this.div.offsetHeight/2);
			
//console.log( clientWidth, clientHeight, _x, _y );		
//console.log( this.div, this.div.offsetWidth, this.div.offsetHeight);		
			
		this.move(_x, _y);


		// recalc items width
		var divWidth = this.div.clientWidth;
		for(i = 0; i < this.items.length; i++){
			this.items[i].style.width = divWidth;
		}

		this.state = '1';

	}

	this.move =
	function _cmenu_move(x, y){
		this.div.style.top = y;
		this.div.style.left = x;
	}

	this.keydown =
	function _keydown(){
		var cmenu = arguments.callee.cmenu;
		switch(window.event.keyCode){
			case _KEY_CODE_ESC:{
				if(cmenu)
					cmenu.hide();
			}break;
		}
	}

	this.docclick =
	function _docclick(){
		var cmenu = arguments.callee.cmenu;
		if(cmenu)
			cmenu.hide();
	}

	this.hide =
	function _hide(){
		// restore document.onkeydown
//		__cmenu_object = null;
		this.doc.onkeydown		= this.doconkeydown;
		this.doc.onclick		= this.doconclick;
		//document.onmousedown	= this.doconmousedown;
		this.div.style.display	= "none";
		this.state = '0';
	}

	this.additem =
	function _additem(text, onclick, value, uname){
	
if( navigator.userAgent.toLowerCase().indexOf("msie 7.0") !== -1 )
{
		var item = this.doc.createElement("<div class='cmenu-item'/></div>");
}
else
{		
		//fix
		var item = this.doc.createElement("div");
		item.setAttribute('class', 'cmenu-item');	
}
		if(uname != undefined) item.id = '_citem_' + this.uname + '_' + uname;

		if(value != undefined)
			item.innerHTML =  '<div style="float:left">' + text + '<\/div><div style="float:right;padding-left:5px;font-weight:normal;font-style:italic">' + value + '<\/div>';
		else
		{
//if( navigator.userAgent.toLowerCase().indexOf("msie 7.0") !== -1 )
//{
			//item.innerText = text;
//}
//else
//{			
			//fix
			item.innerHTML = text;
//}			
			//fix
			item.style.width	= "auto";
		}
		
		if(onclick)
			item.onclick = onclick;
			
		this.div.appendChild(item);
		item.onmouseover	= function(){ this.className = "cmenu-item-h"; };
		item.onmouseout		= function(){ this.className = "cmenu-item"; };
		this.items = this.div.childNodes;
		return item;
	}

	this.set_item_value =
	function _cmenu_set_item_value(uname, value){
		var item = this.doc.all['_citem_' + this.uname + '_' + uname];
		if(item && item.childNodes.length == 2)
			item.childNodes[1].innerText = value;
	}

	this.is_item =
	function _cmenu_is_item(uname){
		var item = this.doc.all['_citem_' + this.uname + '_' + uname];
		if(item) return true;
		else return false;
	}

	this.addseparator =
	function _addseparator(){
		var item = this.doc.createElement("<div class='cmenu-item' style='padding-top:0px;padding-bottom:0px'></div>");
		item.innerHTML = "<hr noshade='1' size='1'/>";
		this.div.appendChild(item);
		this.items = this.div.childNodes;
		return item;
	}

	this.clear =
	function _clear(){
		var first_index = 0;
		if(this.menu_title) first_index = 1;
		while(this.div.childNodes.length > first_index)
			this.div.childNodes(first_index).removeNode(true);
	}
}