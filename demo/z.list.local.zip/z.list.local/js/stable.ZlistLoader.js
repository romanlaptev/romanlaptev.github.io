/*
Usage:
	var z_obj = ZListLoader(xml);
	z_obj.get_table_data( update_xml );
	........
	var z_obj = ZListLoader(xml);
	z_obj.get_detail_block( block_id, xbr_id, reload );
*/
(function(){

var ZListLoader = function(xml)
{
	var _repositoryRevision = "$Rev: 208 $"; 

	var limit_text_tpl = "<span class='limit-message block-records-limit-text' data-id='#id' data-count='#count' data-remain='#remain'>Robeza sasniegta. Ierakstu kopa : #count, Ierakstu atlika : #remain</span>";
	var img_tpl = "<img src='#data' width='160' alt='#data'>";
	var css_tpl ="<span style='#css'>#data</span>";
	
	var table_data = {};
	table_data.log = [];

	//---------------------- get xml info	
	var init_start = new Date();
	
		table_data.xml_info = get_xml_info();
		
	var init_end = new Date();
	var runtime = (init_end.getTime() - init_start.getTime()) / 1000;
	table_data.log.push("ZListLoader, function get_xml_info(), runtime: " + runtime + " sec");
	
	var init_start = new Date();
		table_data.xml_obj = get_xml_obj( table_data.xml_info );
	var init_end = new Date();
	var runtime = (init_end.getTime() - init_start.getTime()) / 1000;
	table_data.log.push("ZListLoader, function get_xml_obj(), runtime: " + runtime + " sec");
	
	//var get_table_data = function()
	var get_table_data = function( update_xml )
	{
	
//refresh xml	
if( typeof update_xml !== "undefined")
{
//console.log(update_xml);	
	xml = update_xml;
	delete table_data.xml_records;
}

		var exec_start = new Date();

			table_data.columns = get_columns();
			table_data.columns_info = read_columns_info();
			table_data.presetlist = get_presetlist();
			
		var exec_end = new Date();
		var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
		table_data.log.push("ZListLoader.get_table_data(), function get_columns(), get_presetlist() runtime: " + runtime_s + " sec");
		
		
		if( typeof table_data.xml_records === "undefined")
		{
			var exec2_start = new Date();
			//---------------------- get xml data
			table_data.xml_records = get_xml_records();
			var exec2_end = new Date();
			var runtime_s = (exec2_end.getTime() - exec2_start.getTime()) / 1000;
			table_data.log.push("ZListLoader.get_table_data(), function get_xml_records, runtime: " + runtime_s + " sec");
		}
		
		
		function read_columns_info()
		{
			var columns_info = [];
			
			var xlist = $(xml).find("xlist2").children("block");
			$(xlist).children().each(function(){
				if( $(this).prop('tagName') == "block")
				{
					var block = $(this);
					var block_obj = {};
					var item_attr = get_attr_to_obj( this.attributes );
					for(attr in item_attr)
					{
						block_obj[attr] = item_attr[attr];
					}
					block_obj["columns"] = get_block_columns( block );
					columns_info.push( block_obj );
				}
				if( $(this).prop('tagName') == "column")
				{
					var column = $(this);
					var column_obj = {};
					var item_attr = get_attr_to_obj( this.attributes );
					for(attr in item_attr)
					{
						column_obj[attr] = item_attr[attr];
					}
					
					//add id for column
					column_obj["id"] = $(xlist).attr("id");
					
					column_obj["columns"] = get_main_columns( column );
					columns_info.push( column_obj );
				}
			});//next

			//define columns indexes
			gl_num_column = 0;
			for( var num_block_columns = 0; num_block_columns < columns_info.length; num_block_columns++ )
			{
				var block_column_size = columns_info[num_block_columns]["columns"].length;
				for( var num_column = 0; num_column < block_column_size; num_column++)
				{
					var column = columns_info[num_block_columns]["columns"][num_column];
					column["index"] = gl_num_column;
					gl_num_column++;
				}
			}//next block_columns
			
			return columns_info;
			
			function get_main_columns( column )
			{
				var column_obj = {};
				column_obj["fields"] = [];
				column_obj = read_column_info( column, column_obj );
				
				var column = [];
				column.push( column_obj );
				return column;
			}//end get_main_columns

			function get_block_columns( block )
			{
				var columns = [];
				$(block).find("column").each(function(){
					var column_title = $(this).attr('title');
					var column_obj = {
						"title": column_title
					};
					column_obj["fields"] = [];
					column_obj = read_column_info( $(this), column_obj );
					columns.push( column_obj );
				});
				return columns;
			}//end get_block_columns

			function read_column_info( column, column_obj ){
				var block_id = $(column).parent().attr("id");			
				column_obj["block_id"] = block_id;
				
				$(column).children().each(function(){
				
					if ( this.tagName == "field" || this.tagName == "group")
					{
						var field_obj = {
							"name": $(this).attr('name'),
							"field_id": $(this).attr('id'),
							"block_id": block_id
						};
						if ( this.tagName == "group" )
						{
							field_obj["group_id"] = $(this).attr('id');
						}
						column_obj["fields"].push( field_obj );
					}
					if ( this.tagName == "block" )
					{
						//add parent_id for column
						$(column).attr("id", block_id );
						column_obj = read_column_info( $(this), column_obj );
					}
					
				});
				//column_index++;			
				
				return column_obj;
			}//end function read_column_info()
			
		}//end read_columns_info()
		
		function get_columns(){
			var columns = [];
			$(xml).find('xlist2').find('column').each(function(){
				var column_title = $(this).attr('title');
				var column_obj = {
					"title": column_title
				};
				column_obj["fields"] = [];
				
				var number = 0;
				column_obj = read_column_info( $(this), column_obj, number );
				
				columns.push( column_obj );
						
			});
			return columns;

			function read_column_info( column, column_obj, number ){
				var block_id = $(column).parent().attr("id");			
				column_obj["block_id"] = block_id;
				$(column).children().each(function(){
				
					if ( this.tagName == "field" || this.tagName == "group")
					{
						number++;
						var field_obj = {
							"name": $(this).attr('name'),
							"field_id": $(this).attr('id'),
							"block_id": block_id

						};
						if ( this.tagName == "group" )
						{
							field_obj["group_id"] = $(this).attr('id');
						}
						field_obj["num_order"] = number;
						column_obj["fields"].push( field_obj );
					}
					if ( this.tagName == "block" )
					{
						//add parent_id for column
						$(column).attr("id", block_id );
						column_obj = read_column_info( $(this), column_obj, number );
						number = column_obj["fields_number"];
					}
					
				});
				
				column_obj["fields_number"] = number;
				return column_obj;
			}//end function read_column_info()

			
		}//end get_columns()
		
		function get_presetlist()
		{
			var xpresetlist = $(xml).find("xpresetlist");
			var list = [];
			$(xpresetlist).children("xrecord").each(function(){
				var xrec = $(this);
				var item_obj = {};
				$(xrec).children("xfield").each(function(){
					var field = $(this);
					var name = $(field).attr("name");
					item_obj[name] = $(field).text();
				});
				list.push( item_obj );				
			});
			return list;
		}//end get_presetlist()
		
	}//end get_table_data


	function get_xml_info(){
		var xml_info = {};
		xml_info["xform_name"] = $(xml).find("xdisplay > xform").attr("name");
		
		var xblock_data = $(xml).find("xdisplay > xform > xrow > xblock");
		
		// read xblock attributes
		var item_attr = get_attr_to_obj( xblock_data[0].attributes );
		for(var attr in item_attr)
		{
			xml_info[attr] = item_attr[attr];
		}//next attr
		
		xml_info.block_id = $(xblock_data).attr("id");
		xml_info.name = $(xblock_data).attr("name");

		$( xblock_data ).children("xrow").children().each(function(){
			if ( this.tagName == "xblock" )
			{
				var name = $(this).attr("name");
				var id = $(this).attr("id");
				if( !xml_info["blocks"])
				{
					xml_info.blocks = {};
				}
				xml_info["blocks"]["#"+id] = get_block_info( $(this) );
				xml_info["blocks"]["#"+id]["parent_id"] = xml_info.block_id;
			}
			if ( this.tagName == "xfield" )
			{
				var id = $(this).attr("id");
				if( typeof xml_info["fields"] === "undefined")
				{
					xml_info.fields = {};
				}
				var item_attr = get_attr_to_obj( this.attributes );
				if( typeof xml_info["fields"]["#"+id] == "undefined")
				{
					xml_info["fields"]["#"+id]=[];
				}
				for(var attr in item_attr)
				{
					xml_info["fields"]["#"+id][attr] = item_attr[attr];
				}
			}
			if ( this.tagName == "xgroup" )
			{
				if( typeof xml_info["fields"] === "undefined")
				{
					xml_info.fields = {};
				}
				if( !xml_info["groups"])
				{
					xml_info.groups = {};
				}
				xml_info["groups"] = read_xgroup_info_mod( $(this) );

				//copy xgroup field in xml_info["fields"]
				for(var group in xml_info["groups"] )
				{
					for(var field in xml_info["groups"][group]["fields"])
					{
						xml_info["fields"][field] = xml_info["groups"][group]["fields"][field];
					}
				}
			}
		});
		
		//test tab_rows,  copy xblock info, for parse detail blocks		
		for(var attr in item_attr)
		{
			if( attr == "tab_rows" )
			{
				if( typeof table_data["detail_blocks"] == "undefined")
				{
					table_data["detail_blocks"] = [];
				}
				if( $.inArray( item_attr["id"], table_data["detail_blocks"]) == -1) 
				{
					table_data["detail_blocks"]["#"+item_attr["id"] ] = {
						"title": item_attr["title"], 
						"columns":[], 
						"block_info": xml_info
					};
				}				
			}
		}//next attr
		
		xml_info["xreference"] = [];
		xml_info["xreference"]["xref"] = [];
		var xref = $(xml).find("xdisplay > xreference");
		$(xref).children("xref").each(function(){
			var xref_obj = {
				name:$(this).attr("name"),
				text:$(this).attr("text")
			};
			xml_info["xreference"]["xref"].push( xref_obj );
		});

		return xml_info;
	
		function get_block_info( xblock_data )
		{
			var block_info = {};
//----------------- read xblock attributes
			var item_attr = get_attr_to_obj( xblock_data[0].attributes );
			for(var attr in item_attr)
			{
				if( attr == "id" )
				{
					block_info["block_id"] = item_attr[attr];
				}
				else
					block_info[attr] = item_attr[attr];
			}

//----------------- read children xblock info
			if ( $(xblock_data).children("xrow").children("xblock").length > 0)
			{
				block_info.blocks = {};
				$(xblock_data).children("xrow").children("xblock").each(function(){
					var name = $(this).attr("name");
					var id = $(this).attr("id");
					block_info["blocks"]["#"+id] = get_block_info( $(this) );
					block_info["blocks"]["#"+id]["parent_id"] = block_info.block_id;
				});
			}
			
//----------------- read children xfield info
			if ( $(xblock_data).children("xrow").children("xfield").length > 0)
			{
				block_info.fields = {};
				$(xblock_data).children("xrow").children("xfield").each(function(){
					var id = $(this).attr("id");
					
					var item_attr = get_attr_to_obj( this.attributes );
					if( typeof block_info["fields"]["#"+id] == "undefined")
					{
						block_info["fields"]["#"+id]=[];
					}
					for(attr in item_attr)
					{
						block_info["fields"]["#"+id][attr] = item_attr[attr];
					}
					
					// read xfunction info
					if ( $(this).children("xfunction").length > 0 )
					{
						read_xfunction_info( $(this) );
					}
					
					//read xfstyle info
					var xfield_css = $(this).children("xfstyle").children("xfsother").text();
					if( xfield_css.length > 0 )
					{
						block_info["fields"]["#"+id]["css"] = xfield_css;
						//copy css info
						if( typeof xml_info["style"] == "undefined")
						{
							xml_info["style"] = [];
						}
						if( typeof xml_info["style"]["#"+id] == "undefined")
						{
							xml_info["style"]["#"+id] = [];
						}
						xml_info["style"]["#"+id]["css"] = xfield_css;
					}
					
					//copy mime_type info
					var xfield_mime_type = $(this).attr("mime_type");
					if( typeof xfield_mime_type !== "undefined" )
					{
						if( typeof xml_info["mime_type"] == "undefined")
						{
							xml_info["mime_type"] = [];
						}
						if( typeof xml_info["mime_type"]["#"+id] == "undefined")
						{
							xml_info["mime_type"]["#"+id] = [];
						}
						xml_info["mime_type"]["#"+id]["type"] = xfield_css;
					}
					
					
				});
			}
			
//----------------- read children xgroup info
			if ( $(xblock_data).children("xrow").children("xgroup").length > 0 )
			{
				var xgroup = $(xblock_data).children("xrow").children("xgroup");
				read_xgroup_info( xgroup );
			}

			
//----------------- read children xpform info
			if ( $(xblock_data).children("xpform").length > 0)
			{
				if( typeof block_info["pform"] == "undefined")
				{
					block_info["pform"] = [];
				}
				var pform = $(xblock_data).children("xpform");
				$(pform).each(function()
				{
					var id = $(this).attr("id");
					var item_attr = get_attr_to_obj( this.attributes );
					//var item_attr = get_attr_to_obj( $(this)[0].attributes );
					if( typeof block_info["pform"]["#"+id] == "undefined")
					{
						block_info["pform"]["#"+id]=[];
					}
					for(var attr in item_attr)
					{
						block_info["pform"]["#"+id][attr] = item_attr[attr];
					}
				});
			}

//----------------- read children xref info
			if ( $(xblock_data).children("xref").length > 0)
			{
				var xref = $(xblock_data).children("xref");
				block_info["xref"] = $(xref).attr("name");
			}
			
//----------------- read children xhref info
			if ( $(xblock_data).find("xhref").length > 0)
			{
				if( typeof block_info["xhref"] == "undefined")
				{
					block_info["xhref"] = [];
				}
				var xhref = $(xblock_data).find("xhref");
				$(xhref).each(function()
				{
					var item_attr = get_attr_to_obj( this.attributes );
					var id = $(this).attr("id");
					if( typeof block_info["xhref"]["#"+id] == "undefined")
					{
						block_info["xhref"]["#"+id]=[];
					}
					for(var attr in item_attr)
					{
						block_info["xhref"]["#"+id][attr] = item_attr[attr];
					}
				});
			}
			
//----------------- copy xblock info, for parse detail blocks
			if( typeof table_data["detail_blocks"] == "undefined")
			{
				table_data["detail_blocks"] = [];
			}
			
			for( var attr in item_attr)
			{
				if( attr == "tab_rows" )
				{
					if( $.inArray( item_attr["id"], table_data["detail_blocks"]) == -1) 
					{
						table_data["detail_blocks"]["#"+item_attr["id"] ] = { 
							"title": (typeof item_attr["title"]=="undefined"?"&nbsp;":item_attr["title"]), 
							"columns":[], 
							//"records":[],
							"block_info": block_info
						};
					}				
				}
			}
			return block_info;
			
			
			function read_xgroup_info( xgroup )
			{
//console.log(xgroup);			
				block_info.groups = {};
				$(xgroup).each(function(){
				
					var name = $(this).attr("name");
					var id = $(this).attr("id");
					var type = $(this).attr("type");
					
					block_info["groups"]["#"+id] = {};
					
//----------------- read xgroup attributes
					var item_attr = get_attr_to_obj( $(this)[0].attributes );
					for(attr in item_attr)
					{
						if( attr == "id" )
						{
							block_info["groups"]["#"+id]["group_id"] = item_attr[attr];
						}
						else
							block_info["groups"]["#"+id][attr] = item_attr[attr];
					}
					
//----------------- read xgroup fields
					var fields = {};
					$(this).children("xfield").each(function(){
						var name = $(this).attr("name");
						var id = $(this).attr("id");
						//fields[name] = id;
						//fields["#"+id] = name;

						var item_attr = get_attr_to_obj( this.attributes );
						if( typeof fields["#"+id] == "undefined")
						{
							fields["#"+id]=[];
						}
						for(attr in item_attr)
						{
							fields["#"+id][attr] = item_attr[attr];
						}
if( typeof block_info["fields"] === "undefined")
{
	block_info["fields"] = [];
}						
						block_info["fields"]["#"+id] = {
							"id": id,
							"name":name
						};
						
					});
					block_info["groups"]["#"+id]["fields"] = fields;
					
if( typeof xml_info["xgroups"] == "undefined")
{
	xml_info["xgroups"]=[];
}
block_info["groups"]["#"+id]["block_id"] = block_info["block_id"];
xml_info["xgroups"].push( block_info["groups"]["#"+id] );

					// !!!!!!!!!!!!!! xgroup / xgroup
					if( $(this).children("xgroup").length > 0 )
					{
						var xgroup = $(this).children("xgroup");
						read_xgroup_info( xgroup );
					}
				});
			
			}//end read_xgroup_info()

			function read_xfunction_info( xfield )
			{
				var name = xfield.attr("name");
				var id = xfield.attr("id");
				if( !xml_info["formats"])
				{
					xml_info.formats = {};
				}
				if (typeof xml_info["formats"][name] == "undefined")
				{
					xml_info["formats"]["#" + id] = [];
				}
				/*
				var xfunc = xfield.children("xfunction");
				var type = xfunc.attr("type");
				
				xml_info["formats"]["#"+id] = {
				"field_id": id,
				"name": name,
				"type": type
				};
				*/
				
				//read xfield attributes
				var item_attr = get_attr_to_obj( $(xfield)[0].attributes );
				for(attr in item_attr)
				{
					if( attr === "id")
					{
						xml_info["formats"]["#"+id]["field_id"] = item_attr[attr];
					}
					else
						xml_info["formats"]["#"+id][attr] = item_attr[attr];
				}
				var xfunc = xfield.children("xfunction");
				var type = xfunc.attr("type");
				xml_info["formats"]["#"+id]["type"] = type;
				
				//save xfunction, xstyle info
				xml_info["formats"]["#"+id]["xfunction"] = xfunc;
				var xfield_css = xfield.children("xfstyle");
				xml_info["formats"]["#"+id]["xfstyle"] = xfield_css;
				
				if (type == "join")
				{
if( xfunc.children("xfunction").attr("type") === "substr" )
{
					var target_info = xfunc.children("xfunction").attr("field");
}

if( xfunc.children("xparam").attr("type") == "field" )
{
	var target_info = xfunc.children("xparam").text();
}

if( typeof target_info == "string" && 
		target_info.length > 0)
{
	var last_ = target_info.lastIndexOf("_") + 1;
	var xf_id = target_info.substr(last_, target_info.length);
	
	var xb_id = target_info.substr(0, (last_ - 1));
	var last_ = xb_id.lastIndexOf("_") + 1;
	var xb_id = xb_id.substr(last_, xb_id.length);
	
	xml_info["formats"]["#"+id]["target_info"] = target_info;
	xml_info["formats"]["#"+id]["xb_id"] = xb_id;
	xml_info["formats"]["#"+id]["xf_id"] = xf_id;
}
else
{
console.log("problem parse in function read_xfunction_info( xfield ), target_info");
}
				}
				
				//test triplex function
/*
sample function????
<xfield id="99999" name="test_triplex_field" pos="15" textbefore="test_triplex_field" virt="1">
	<xfunction exec="post-query" id="99998" name="test_triplex_func" pos="3" type="triplex">
		<xparam id="99997" name="p1" pos="3" type="field">z_24668_99990</xparam>
		<xparam id="99996" name="p2" pos="4" type="field">z_24668_99991</xparam>
		<xparam id="99995" name="p3" pos="4" type="field">z_24668_99992</xparam>
	</xfunction>
</xfield>
*/				
				if( type == "triplex" )
				{
					var xf_id = [];
					var xb_id = [];
					$(xfunc).children("xparam").each(function(){
						var target_info = $(this).text();
						
						var last_ = target_info.lastIndexOf("_") + 1;
						xf_id.push( target_info.substr(last_, target_info.length) );
						
						var var_xb_id = target_info.substr(0, (last_ - 1));
						var last_ = var_xb_id.lastIndexOf("_") + 1;
						xb_id.push( var_xb_id.substr(last_, var_xb_id.length) );
					});
					xml_info["formats"]["#"+id]["xb_id"] = xb_id;
					xml_info["formats"]["#"+id]["xf_id"] = xf_id;
				}
				
			}//end read_xfunction_info()
			
		}//end get_block_info()
		
	}//end get_xml_info()

	function read_xgroup_info_mod( xgroup )
	{
		var group_info = {};
		var name = $(xgroup).attr("name");
		var id = $(xgroup).attr("id");
		var type = $(xgroup).attr("type");
		if ( type == "date" )
		{
			var d_format = $(xgroup).attr("d_format");
		}
		var fields = {};
		$(xgroup).children("xfield").each(function(){
			var name = $(this).attr("name");
			var id = $(this).attr("id");
			fields["#"+id] = name;
		});
		group_info["#"+id] = {
				"group_id": id,
				"type": type,
				"name": name,
				"fields": fields
			};
		return group_info;
	}//end read_xgroup_info()
	
	function get_xml_obj( xml_info, block_id, xbr_id )
	{
	
if( typeof block_id !== "undefined" && 
		typeof xbr_id !== "undefined")
{
		if( block_id.indexOf("#") === -1 )
		{
			block_id = "#"+block_id;
		}
		if( xbr_id.indexOf("#") === -1 )
		{
			xbr_id = "#"+xbr_id;
		}

		//xb to object
		var xml_obj = [];
		$(xml).find('xdata').find('xrecord').each(function()
		{
			var xrecord = $(this);
			var xb = $(xrecord).find(block_id);
			var xbr = $(xb).find(xbr_id);
			
			var test_xb_id = "#" + $(xb).attr("id");
			var test_xbr_id = "#" + $(xbr).attr("id");
			if( block_id === test_xb_id && 
				xbr_id === test_xbr_id)
			{
				parse_block( xb, xml_obj );
			}
		});
}
else
{
		//all xml to object
		var xml_obj = [];
		$(xml).find('xdata').find('xrecord').each(function()
		{
			var xrecord = $(this);
			$(xrecord).children().each(function(){
				if( $(this).prop('tagName') == "xb")
				{
					var xb = $(this);
					parse_block( xb, xml_obj );
				}
			});
		});
}//end test_block_id
		
		return xml_obj;

		function parse_block( xb, xml_obj )
		{
			var block_obj = [];
			var block_id = $(xb).attr("id");
			block_obj["xb#"+block_id] = [];
				
			//read xb attributes
			var item_attr = get_attr_to_obj( $(xb)[0].attributes );
			block_obj["xb#"+block_id]["attributes"] = item_attr;
				
			//check xbr_limit
			$(xb).children().each(function(){
				if( $(this).prop("tagName") == "xbr_limit" )
				{
					var xbr_limit_count = $(this).attr("count");
					var xbr_limit_remain = $(this).attr("remain");
					var xbr_limit_text = limit_text_tpl
								.replace(/#count/g, xbr_limit_count)
								.replace(/#remain/g, xbr_limit_remain)
								.replace("#id", block_id);
				
					xbr_limit = {
						"count": xbr_limit_count,
						"remain": xbr_limit_remain,
						"html":	xbr_limit_text
					};
					block_obj["xb#"+block_id]["xbr_limit"] = xbr_limit;
				}
			});//next xb item

			$(xb).children().each(function(){
				if( $(this).prop('tagName') == "xbr")
				{
					var xbr = $(this);
					var xbr_id = $(xbr).attr("id");
					block_obj["xb#"+block_id]["xbr#" + xbr_id] = [];
					
					$(xbr).children().each(function(){
						if( $(this).prop("tagName") == "xf" )
						{
							var xf_id = $(this).attr("id");
							if( typeof block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + xf_id] === "undefined" )
							{
								block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + xf_id] = [];
							}
							var fvalue = $(this).text();
							
							var test_id = "#"+xf_id;
							for( var item in xml_info["mime_type"] )
							{
								if ( item === test_id)				
								{
									var fvalue = img_tpl.replace(/#data/g, fvalue);
								}
							}//next

							//read css info
							var test_id = "#"+xf_id;
							for( var item in xml_info["style"] )
							{
								if ( item === test_id)				
								{
									var fvalue = css_tpl
									.replace("#css", xml_info["style"][item]["css"])
									.replace("#data", fvalue);
								}
							}//next
							
							block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + xf_id].push( fvalue );
						}
						if( $(this).prop("tagName") == "xb" )
						{
							parse_block( $(this), block_obj["xb#"+block_id]["xbr#" + xbr_id]);
						}
						
					});
					
					//xgroup process
					var group = test_xgroup( block_id );
					if( group.length > 0)
					{
						for( var num = 0; num < group.length; num++)
						{
							var group_id = group[num]["group_id"];
							if( typeof block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + group_id] === "undefined" )
							{
								block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + group_id] = [];
							}
							var xgroup_value = process_xgroup( group[num], block_obj["xb#"+block_id]["xbr#" + xbr_id] );
							block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + group_id].push( xgroup_value );
						}
					}

					//process format values (xfunction join, decode)
					var format = test_xfunction( block_obj["xb#"+block_id]["xbr#" + xbr_id] );
					if( format !== -1)
					{
						var format_id = format["id"];
						var format_value = format["value"];
						if( typeof block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + format_id] === "undefined" )
						{
							block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + format_id] = [];
						}
						block_obj["xb#"+block_id]["xbr#" + xbr_id]["xf#" + format_id] = format_value;
					}

				}//next xbr
				
			});//next xb item
			
			xml_obj.push(block_obj);
			
		}//end parse_block()


		function test_xgroup( block_id )
		{
			var res = [];
			for( var group in xml_info["xgroups"] )
			{
				if ( block_id == xml_info["xgroups"][group]["block_id"] )
				{
					res.push( xml_info["xgroups"][group] );
				}
			}
			return res;
		}//test_xgroup()	
		
		function process_xgroup( group, block_obj )
		{
			var group_id = group["group_id"];
			if ( group["type"] == "date")
			{
				var date_tpl = group["d_format"];
			}
			
			var fields = "";
			for(var fid in group["fields"] )
			{
				var field_name = group["fields"][fid]["name"];
				
				for(var field_id in block_obj)
				{
					var test_id = field_id.replace("xf", "");
					if( fid == test_id )
					{
						var	fvalue = block_obj[field_id][0];
						break;
					}
					else
					{
						var fvalue = "&nbsp;";
					}
				}
				
				switch( group["type"] )
				{
					case "set":
							if( group["dotted"] == 1)	
							{
								if( fields.length > 0 && fvalue !== "&nbsp;")
								{
									fvalue = "." + fvalue;
								}
								fields += fvalue;
							}//end dotted
						break
						
					case "date":
							if ( fvalue.length < 2 )
							{
								fvalue = "0" + fvalue;
							}
							var num = field_name.indexOf("_") + 1;
							var remove_prefix = field_name.substring( num, field_name.length );
//fix		
if ( field_name.length == 4 )
{
	remove_prefix = remove_prefix.replace( "yyyy", "gggg" );
}
							date_tpl = date_tpl.replace( remove_prefix, fvalue);
							fields = date_tpl;
							if( fields == "&nbsp;.&nbsp;.&nbsp;")
							{
								fields = "__.__.____";
							}
							
						break
						
					default:
						fields += fvalue;
				}//end switch
				
			}//end for
			
			//remove last nulls
			if( group["type"] == "set" )
			{
				//filter space
				var fields = fields
				.replace(/&nbsp;/g,"")
				.replace(/\s+/g, "");
				
				for(var n=0; n < fields.length; n++)
				{
					if( fields.lastIndexOf(".0") === (fields.length-2))
					{
						var pos = fields.length - 2;
						fields = fields.substring(0, pos);
					}
				}
			}
			return fields;
		}//end process_xgroup()


		function test_xfunction( xbr_obj )
		{
			if( !$.isEmptyObject( xml_info["formats"] ) )
			{
				for ( var index in xml_info["formats"] )
				{
					var field_id = xml_info["formats"][index]["field_id"];
					
					if( xml_info["formats"][index]["type"] == "join" )
					{
						var xf_id = "xf#" + xml_info["formats"][index]["xf_id"];
						for( var fid in xbr_obj )
						{
							if( fid == xf_id )
							{
								return format_field_values( xbr_obj[fid], xml_info["formats"][index] );
							}
						}
					}
					
					if( xml_info["formats"][index]["type"] == "decode" )
					{
						var field_id = "xf#" + xml_info["formats"][index]["field_id"];
						for( var fid in xbr_obj )
						{
							if( fid == field_id )
							{
								return format_field_values( xbr_obj[fid], xml_info["formats"][index] );
							}
						}
					}
					
				}
			}
			return -1;
		}//end test_xfunction
		
		function format_field_values( field, format )
		{
			var params = read_xfunc_format_params( format.field_id );
			
			if ( format.type == "join" )
			{
//console.log(field, params);			
				var format_info = {};
				format_info["id"] = format.field_id;
				format_info["value"] = process_format_value( field, params );
				return format_info;
			}
				
			if ( format.type == "decode" )
			{
				var decode_field=[];
				for(var num in field)
				{
if( typeof field[num] == "string")
{
	//if(field[num].indexOf("limit-message") !== -1)
	//{
		//continue;
	//}
	decode_field.push( field[num].replace( params[0]["value"], params[1]["value"]) );
}
				}
				
				var format_info = {};
				format_info["id"] = format.field_id;
				format_info["value"] = decode_field;
				return format_info;
			}
				
			if ( format.type == "triplex" )
			{
				//triplex_field_values( field );
			}

		}//end format_field_values
		
	}//end get_xml_obj()

	
	function get_xml_records()
	{
		var xml_records = [];
		/*
		var record = [];
		for(var num_rec = 0; num_rec < table_data.xml_obj.length; num_rec++)
		{
			record = get_values( table_data.xml_obj[num_rec] );
			xml_records.push(record);
		}//next rec
		*/
		
		/*
		//---------------------- test
		xml_records["test"] = [];
		var record = [];
		for(var num_rec = 0; num_rec < table_data.xml_obj.length; num_rec++)
		//for(var num_rec = 6; num_rec < 8; num_rec++)
		{
			record = get_values_test( table_data.xml_obj[num_rec] );
			xml_records["test"].push(record);
		}//next rec
		*/

		//---------------------- test2
		var record = [];
		for(var num_rec = 0; num_rec < table_data.xml_obj.length; num_rec++)
		//for(var num_rec = 0; num_rec < 1; num_rec++)
		{
			record = get_values( table_data.xml_obj[num_rec] );
			xml_records.push(record);
		}//next rec
		
		return xml_records;
		
		function get_values( xrecord )
		{
			var table_record = [];
			for( var num_block_columns = 0; num_block_columns < table_data.columns_info.length; num_block_columns++ )
			{
				var main_block_id = "xb#" + table_data.columns_info[num_block_columns]["id"];
				var main_xblock = [];
				get_xml_block( main_block_id, xrecord, main_xblock);
				var count = test_length_block( main_xblock );
//console.log( main_block_id, main_xblock, count);
				if( count === 0 )
				{
console.log( "empty block!!!!", main_block_id, main_xblock, count);
					continue;
				}
				
				var xbr_count = 0;
				for(var item in main_xblock)
				{
if( typeof main_xblock[item] === "function")
{
continue;
}//fix
					var xbr_limit = "";
					for( var xbr_item in main_xblock[item])
					{
						if( xbr_item.indexOf("xbr#") !== -1 )
						{
//console.log( xbr_item, typeof main_xblock[item][xbr_item]);
							var xbr_buf = [];
							xbr_buf[xbr_item] = main_xblock[item][xbr_item];
							var xbr_values = [];
							
							//read xbr values
							parse_main_xblock( xbr_buf, table_data.columns_info[num_block_columns]["columns"], xbr_values );
//console.log( xbr_count,  xbr_values );

							var column_block_index = num_block_columns;
							if( typeof  table_record[ xbr_count ] === "undefined")
							{
								table_record[ xbr_count ] = [];
								table_record[ xbr_count ][ column_block_index ] = [];
							}
							table_record[ xbr_count ][ column_block_index ] = xbr_values;
							xbr_count++;
							
						}
						
						if( xbr_item.indexOf("xbr_limit") !== -1 )
						{
							xbr_limit = main_xblock[item][xbr_item];
						}
						
					}//next xbr_item
				}

				if( typeof xbr_limit == "object")
				{
					//add limit message in last table line, in cell with max elements
					var count = parseInt( xbr_limit["count"] );
					var remain = parseInt( xbr_limit["remain"] );
					var xbr_max_limit =  count - remain;

					var add_limit = [];
					add_limit = xbr_limit["html"];
					
					var num_repeat = table_data.columns_info[num_block_columns]["columns"].length;
					var num_last_row = table_record.length-1;
					for( var n1 = 0; n1 < num_repeat; n1++)
					{
						var column_index = table_data.columns_info[num_block_columns]["columns"][n1]["index"] ;
						var column_size_count = 0;
						for( var num_row = 0; num_row < table_record.length; num_row++)
						{
if( typeof table_record[num_row][num_block_columns] === "undefined")
{
	table_record[num_row][num_block_columns] = [];
	table_record[num_row][num_block_columns][column_index] = [];
	var new_value = ["#fix"];
	table_record[num_row][num_block_columns][column_index].push(new_value);
//continue;
}						
//console.log( num_row, table_record[num_row][num_block_columns][column_index], table_record[num_row][num_block_columns][column_index].length, typeof table_record[num_row][num_block_columns][column_index] );
							if( table_record[num_row][num_block_columns][column_index][0][0] === "&nbsp;" )
							{
								continue;
							}
							column_size_count = column_size_count + table_record[num_row][num_block_columns][column_index].length;
						}
//console.log( table_data.columns_info[num_block_columns]["columns"][n1], column_size_count );
						if( column_size_count >= xbr_max_limit )
						{
							table_record[num_last_row][num_block_columns][column_index].push( [add_limit] );
						}
						
					}
				}

			}//next block_columns

			//prep array
			//concat array line ( many column blocks )
			for( var n1 = 0; n1 < table_record.length; n1++)
			{
				var concat_arr = [];
				var max_size = 0;
				for( var n2 = 0; n2 < table_record[n1].length; n2++)
				{
				
					if( typeof table_record[n1][n2] !== "undefined")
					{
						for( var n3 = 0; n3 < table_record[n1][n2].length; n3++)
						{
							if( typeof table_record[n1][n2][n3] !== "undefined")
							{
								concat_arr[n3] = table_record[n1][n2][n3];
								
								if( table_record[n1][n2][n3].length > max_size)
								{
									max_size = table_record[n1][n2][n3].length;
									concat_arr["max_size"] = max_size;
								}
								
							}
						}//next cell
					}
					
				}//next col
				table_record[n1] = concat_arr;
			}//next row


			return table_record;
			
			function get_xml_block( block_id, parent_block, xblock, xbr_limit)
			{
				if( block_id.indexOf("xb#") == -1)
				{
					if( block_id.indexOf("#") == -1)
					{
						block_id = "#" + block_id;
					}
					if( block_id.indexOf("xb") == -1)
					{
						block_id = "xb" + block_id;
					}
				}

				//check xbr_limit
				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xbr_limit") !== -1 )
						{
							xbr_limit = parent_block[item];
//console.log( parent_block["attributes"]["id"], item );			
						}
					}					
				}//next item

				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xb#") !== -1 && 
								item == block_id )
						{
							var xb = parent_block[item];
							if(typeof xbr_limit !== "undefined")
							{
								xb["xbrlimit"] = xbr_limit;
							}
							xblock.push( xb );
						}
						else
						{
							get_xml_block( block_id, parent_block[item], xblock, xbr_limit );
						}
					}					
				}//next item
				
			}//end get_xml_block()
			
			function parse_main_xblock( xbr, columns, xbr_values )
			{
//console.log(xbr);
				for( var num_column = 0; num_column < columns.length; num_column++)
				{
					var column = columns[num_column];
					var block_id = "xb#" + column["block_id"];

					if( block_id === main_block_id )
					{
						var xblock = [];
						xblock[0] = xbr;
					}
					else
					{
						var xblock = [];
						get_xml_block( block_id, xbr, xblock);
					}
					var count = test_length_block( xblock );

					if( count === 0 )
					{
						var column_values = [];
						column_values.push(["&nbsp;"]);
					}
					else
					{
						var column_values = [];
						for(var item in xblock)
						{
							parse_xblock( xblock[item], column, column_values );
						}

					}
//if( block_id === "xb#401111")
//if( block_id === "xb#401153")
//if( block_id === "xb#401238" )
//{					
//console.log( column_values);
//}
					//xbr_values.push( column_values );
					xbr_values[ columns[num_column]["index"] ] = column_values;
					
				}//next column

			}//end parse_main_xblock
			
			function parse_xblock( xblock, column, column_values )
			{
//console.log(xblock);
	
				for(var item in xblock)
				{
					if( item.indexOf("xbr#") !== -1 )
					{
						var row = [];
						parse_xbr( xblock[item], column, row );
var count = 0;
for(var item in row)
{
	if(row[item].length === 0)
	{
		row[item] = "&nbsp;";
	}
	count++;
}
						column_values.push( row );
					}
				}//next xbr
//console.log(column_values);

				function parse_xbr( xbr, column, row )
				{
					for(var item in column )
					{
						if( item === "fields" )
						{
							for(var n = 0; n < column[item].length; n++)
							{
								var test_id = "xf#" + column[item][n]["field_id"];
								if( typeof row[test_id] === "undefined")
								{
									row[test_id] = [];
								}
							}//next
						}
					}//next
					
					for(var id in xbr)
					{
						var fvalue = "";
						if( id.indexOf("xf#") !== -1)
						{
							for(var item in column )
							{
								if( item === "fields" )
								{
									get_fvalue( index="field_id" );
								}
							}//next
//if( column["fields"][0]["field_id"] == "401347")
//{
//console.log(block_id, xbr, id, fvalue );
//}					
							
						}//end test xf

						for(var ch_block_id in  xbr[id])
						{
							if( ch_block_id.indexOf("xb#") !== -1)
							{
								parse_xblock_child( xbr[id][ch_block_id], row );
							}
						}
					
						if(fvalue.length > 0)
						{
							if( typeof row[id] === "undefined")
							{
								row[id] = [];
							}
							row[id] = fvalue;
						}
					}//next  id
//console.log(row);

					function get_fvalue( index )
					{
						for(var n = 0; n < column[item].length; n++)
						{
							var test_id = "xf#" + column[item][n][index];
							if( id === test_id)
							{
								var f_array = xbr[id];
								$.each( f_array, function( index, value ) {
									if( index > 0 )
									{
										fvalue += ", " + f_array[index];
									}
									else
									{
										fvalue += f_array[index];
									}
								});
								break;
							}
						}//next
					}//end get_fvalue()				

					function parse_xblock_child( xblock, row )
					{
						for( var xbr_id in xblock )
						{
							if( xbr_id.indexOf("xbr#") !== -1)
							{
								parse_xbr( xblock[ xbr_id ], column, row );
							}
						}
					}// end function parse_xbr_child()
					
				}// end function parse_xbr()

			}//end parse_xblock()
			
		}//end get_values()
		
/*
		function get_values_old( xrecord )
		{
			var table = [];
			for( var column in table_data.columns)
			{
if( typeof table_data["columns"][column] === "function")
{
continue;
}//fix							
				var block_id = "xb#" + table_data.columns[column]["block_id"];
				var xblock = [];
				get_xml_block( block_id, xrecord, xblock);
				
				//is empty object?
				var count = 0;
				for( var item in xblock)
				{
					if( typeof xblock[item] !== "function")
					{
						count++;
					}					
				}
//console.log(xblock, count);				
				
				//if( $.isEmptyObject(xblock) )
				if( count === 0 )
				{
					var record = [];
					record.push(["&nbsp;"]);
				}
				else
				{
					var record = [];
					//record["ch_xbr_id"] = [];
					for(var xbr in xblock)
					{
						parse_xblock( xblock[xbr], table_data.columns[column], record );
					}

					//add limit message (max limit = 5)
if( typeof xblock[0] !== "undefined")
{
					if( typeof xblock[0]["xbrlimit"] !== "undefined" &&
							xblock[0]["xbrlimit"]["html"].length > 0)
					{
						var count = parseInt( xblock[0]["xbrlimit"]["count"] );
						var remain = parseInt( xblock[0]["xbrlimit"]["remain"] );
						var xbr_max_limit =  count - remain;
						if( record.length >= xbr_max_limit )
						{
							record.push( [xblock[0]["xbrlimit"]["html"]] );
						}
						else
						{
							table_data.columns[column]["cancel_rowspan"] = 1;
						}
					}
				}
}				
				table.push( record );
				//if( typeof table[block_id] === "undefined")
				//{
					//table[block_id]=[];
				//}
				//table[block_id] = record;
				
			}
			return table;
			
			//function get_xml_block( block_id, parent_block, xblock)
			function get_xml_block( block_id, parent_block, xblock, xbr_limit)
			{
				if( block_id.indexOf("xb#") == -1)
				{
					if( block_id.indexOf("#") == -1)
					{
						block_id = "#" + block_id;
					}
					if( block_id.indexOf("xb") == -1)
					{
						block_id = "xb" + block_id;
					}
				}

				//check xbr_limit
				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xbr_limit") !== -1 )
						{
							xbr_limit = parent_block[item];
//console.log( parent_block["attributes"]["id"], item );			
						}
					}					
				}//next item

				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xb#") !== -1 && 
								item == block_id )
						{
							var xb = parent_block[item];
							if(typeof xbr_limit !== "undefined")
							{
								xb["xbrlimit"] = xbr_limit;
							}
//if( block_id == "xb#401111")
//if( block_id == "xb#401336")
//if( block_id == "xb#401344")
//{
//console.log(block_id, xblock);
//}						
							xblock.push( xb );
						}
						else
						{
							//get_xml_block( block_id, parent_block[item], xblock );
							get_xml_block( block_id, parent_block[item], xblock, xbr_limit );
						}
					}					
				}//next item
				
			}//end get_xml_block()
			
			function parse_xblock( xblock, column, record )
			{
				var xbr_limit = "";
				for(var item in xblock)
				{
					if( item.indexOf("xbr#") !== -1 )
					{
						//record["ch_xbr_id"].push( item.replace("xbr#", "") );
						var row = [];
						parse_xbr( xblock[item], column, row );
var count = 0;
for(var item in row)
{
	if(row[item].length === 0)
	{
		row[item] = "&nbsp;";
	}
	count++;
}
						
						record.push( row );
					}
					if( item.indexOf("xbr_limit") !== -1 )
					{
						xbr_limit = xblock[item];
					}
				}//next xbr
				
				if( typeof xbr_limit == "object")
				{
					//add limit message in last table line
					var xbr_max_limit = xbr_limit["count"] - xbr_limit["remain"];
					var num_rec = record.length;
					record[num_rec] = [];
					var num=0;
					
					record[num_rec][column] = [ xbr_limit["html"] ];
				}

				function parse_xbr( xbr, column, row )
				{
					for(var item in column )
					{
						if( item === "fields" )
						{
							for(var n = 0; n < column[item].length; n++)
							{
								var test_id = "xf#" + column[item][n]["field_id"];
								if( typeof row[test_id] === "undefined")
								{
									//row[test_id] = ["&nbsp;"];
									row[test_id] = [];
								}
							}//next
						}
						if( item === "groups" )
						{
							for(var n = 0; n < column[item].length; n++)
							{
								var test_id = "xf#" + column[item][n]["group_id"];
								if( typeof row[test_id] === "undefined")
								{
									row[test_id] = [];
								}
							}//next
						}
					}//next
					
					for(var id in xbr)
					{
						var fvalue = "";
						if( id.indexOf("xf#") !== -1)
						{
							for(var item in column )
							{
								if( item === "fields" )
								{
									get_fvalue( index="field_id" );
								}
								if( item === "groups" )
								{
									get_fvalue( index="group_id" );
								}
							}//next
//if( column["fields"][0]["field_id"] == "401347")
//{
//console.log(block_id, xbr, id, fvalue );
//}					
							
						}//end test xf

						for(var ch_block_id in  xbr[id])
						{
							if( ch_block_id.indexOf("xb#") !== -1)
							{
								parse_xblock_child( xbr[id][ch_block_id], row );
							}
						}
					
						if(fvalue.length > 0)
						{
							if( typeof row[id] === "undefined")
							{
								row[id] = [];
							}
							//row[id].push( fvalue );
							row[id] = fvalue;
						}
					}//next  id
//console.log(row);

					function get_fvalue( index )
					{
						for(var n = 0; n < column[item].length; n++)
						{
							var test_id = "xf#" + column[item][n][index];
							if( id === test_id)
							{
								var f_array = xbr[id];
								$.each( f_array, function( index, value ) {
									if( index > 0 )
									{
										fvalue += ", " + f_array[index];
									}
									else
									{
										fvalue += f_array[index];
									}
								});
								break;
							}
						}//next
					}//end get_fvalue()				

					function parse_xblock_child( xblock, row )
					{
						for( var xbr_id in xblock )
						{
							if( xbr_id.indexOf("xbr#") !== -1)
							{
								parse_xbr( xblock[ xbr_id ], column, row );
							}
						}
					}// end function parse_xbr_child()
					
				}// end function parse_xbr()

			}//end parse_xblock()
			
		}//end get_values()

		function get_values_test( xrecord )
		{
			var table_record = [];
			for( var column in table_data.columns)
			{
if( typeof table_data["columns"][column] === "function")
{
continue;
}//fix							
				var block_id = "xb#" + table_data.columns[column]["block_id"];
				var xblock = [];
				get_xml_block( block_id, xrecord, xblock);
				
				//is empty object?
				var count = 0;
				for( var item in xblock)
				{
					if( typeof xblock[item] !== "function")
					{
						count++;
					}					
				}
//console.log(block_id, xblock, count);

				if( count === 0 )
				{
					var column_values = [];
					var bf = [];
					bf.push(["&nbsp;"]);
					column_values.push(bf);
				}
				else
				{
				
//if( block_id === "xb#401312")
if( count > 1 )
{
	var inserted_block = 1;
	var values = [];
	for(var xbr in xblock)
	{
		parse_xblock( xblock[xbr], table_data.columns[column], values, inserted_block );
	}
	var column_values = [];
	column_values.push(values);
}				
else
{				
	var column_values = [];
	for(var xbr in xblock)
	{
		parse_xblock( xblock[xbr], table_data.columns[column], column_values );
	}
}


					//add limit message (max limit = 5)
if( typeof xblock[0] !== "undefined")
{
					if( typeof xblock[0]["xbrlimit"] !== "undefined" &&
							xblock[0]["xbrlimit"]["html"].length > 0)
					{
						var count = parseInt( xblock[0]["xbrlimit"]["count"] );
						var remain = parseInt( xblock[0]["xbrlimit"]["remain"] );
						var xbr_max_limit =  count - remain;
						if( column_values.length >= xbr_max_limit )
						{
							column_values.push( [xblock[0]["xbrlimit"]["html"]] );
						}
						else
						{
							table_data.columns[column]["cancel_rowspan"] = 1;
						}
					}
				}
}				
				table_record.push( column_values );
				//if( typeof table_record[block_id] === "undefined")
				//{
					//table_record[block_id]=[];
				//}
				//table_record[block_id] = column_values;
				
			}
			return table_record;
			
			function get_xml_block( block_id, parent_block, xblock, xbr_limit)
			{
				if( block_id.indexOf("xb#") == -1)
				{
					if( block_id.indexOf("#") == -1)
					{
						block_id = "#" + block_id;
					}
					if( block_id.indexOf("xb") == -1)
					{
						block_id = "xb" + block_id;
					}
				}

				//check xbr_limit
				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xbr_limit") !== -1 )
						{
							xbr_limit = parent_block[item];
//console.log( parent_block["attributes"]["id"], item );			
						}
					}					
				}//next item

				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item.indexOf("xb#") !== -1 && 
								item == block_id )
						{
							var xb = parent_block[item];
							if(typeof xbr_limit !== "undefined")
							{
								xb["xbrlimit"] = xbr_limit;
							}
//if( block_id == "xb#401111")
//if( block_id == "xb#401336")
//if( block_id == "xb#401344")
//{
//console.log(block_id, xblock);
//}						
							xblock.push( xb );
						}
						else
						{
							get_xml_block( block_id, parent_block[item], xblock, xbr_limit );
						}
					}					
				}//next item
				
			}//end get_xml_block()
			
			function parse_xblock( xblock, column, column_values, inserted_block )
			{
				var xbr_limit = "";
				for(var item in xblock)
				{
					if( item.indexOf("xbr#") !== -1 )
					{
						var values = [];
						parse_xbr( xblock[item], column, values );
var count = 0;
for(var item in values)
{
	if( values[item].length === 0 )
	{
		values[item] = "&nbsp;";
	}
	count++;
}

//save values
if( inserted_block === 1)
{
//console.log(inserted_block);
	column_values.push( values );
}
else
{
						
						var cell_values = [];
						cell_values.push( values );
						column_values.push( cell_values );
}
						
					}
					if( item.indexOf("xbr_limit") !== -1 )
					{
						xbr_limit = xblock[item];
					}
				}//next xbr
				
				if( typeof xbr_limit == "object")
				{
					//add limit message in last table line
					var xbr_max_limit = xbr_limit["count"] - xbr_limit["remain"];
					var num_rec = column_values.length;
					column_values[num_rec] = [];
					var num=0;
					
					var cell_values = [];
					cell_values[ "limit_#xb"+column["block_id"] ] = [ xbr_limit["html"] ];
					column_values[num_rec].push( cell_values );
				}

				function parse_xbr( xbr, column, values )
				{
					for(var item in column )
					{
						if( item === "fields" )
						{
							for(var n = 0; n < column[item].length; n++)
							{
								var test_id = "xf#" + column[item][n]["field_id"];
								if( typeof values[test_id] === "undefined")
								{
									values[test_id] = [];
								}
								
							}//next
						}
					}//next
					
					for(var id in xbr)
					{
						var fvalue = "";
						if( id.indexOf("xf#") !== -1)
						{
							for(var item in column )
							{
								if( item === "fields" )
								{
									get_fvalue( index="field_id" );
								}
							}//next
//if( column["fields"][0]["field_id"] == "401347")
//{
//console.log(block_id, xbr, id, fvalue );
//}					
							
						}//end test xf

						for(var ch_block_id in  xbr[id])
						{
							if( ch_block_id.indexOf("xb#") !== -1)
							{
								parse_xblock_child( xbr[id][ch_block_id], values );
							}
						}
					
						if(fvalue.length > 0)
						{
							if( typeof values[id] === "undefined")
							{
								values[id] = [];
							}
							//values[id].push( fvalue );
							values[id] = fvalue;
						}
					}//next  id
					
					function get_fvalue( index )
					{
						for(var n = 0; n < column[item].length; n++)
						{
							var test_id = "xf#" + column[item][n][index];
							if( id === test_id)
							{
								var f_array = xbr[id];
								$.each( f_array, function( index, value ) {
									if( index > 0 )
									{
										fvalue += ", " + f_array[index];
									}
									else
									{
										fvalue += f_array[index];
									}
								});
								break;
							}
						}//next
					}//end get_fvalue()				

					function parse_xblock_child( xblock, row )
					{
						for( var xbr_id in xblock )
						{
							if( xbr_id.indexOf("xbr#") !== -1)
							{
								parse_xbr( xblock[ xbr_id ], column, row );
							}
						}
					}// end function parse_xbr_child()
					
				}// end function parse_xbr()

			}//end parse_xblock()
	
		}//end get_values_old()
*/	
		
	}//end get_xml_records()
	
//shared functions

	function test_length_block( xblock )
	{
		var count = 0;
		for( var item in xblock)
		{
			if( typeof xblock[item] !== "function")
			{
				count++;
			}					
		}
		return count;
	}//end test_length_block()

	function read_xfunc_format_params( field_id )
	{
/*	
		var xform = $(xml).find("xdisplay > xform > xrow > xblock");
		var xfunc = $(xform).find("#" + field_id).children("xfunction");
		var params = [];
//--------------------
var xfield_css = $(xform).find("#" + field_id).children("xfstyle").children("xfsother").text();
if( xfield_css.length > 0 )
{
var css = $(xform).find("#" + field_id).children("xfstyle").children("xfsother").text();
}
//--------------------				
*/
		if( !table_data["xml_info"]["formats"]["#" + field_id] )
		{
			return -1;
		}
		if( !table_data["xml_info"]["formats"]["#" + field_id]["xfunction"] )
		{
			return -1;
		}

		var xfunc = table_data["xml_info"]["formats"]["#" + field_id]["xfunction"];
		var xfield_css = table_data["xml_info"]["formats"]["#" + field_id]["xfstyle"];
		var css = $( xfield_css ).children("xfsother").text();

		var params = [];
		$(xfunc).children().each(function(){
			var type = $(this).attr("type");
			if ( type == "substr")
			{
				var id = $(this).attr("id");
				var obj = {
					xfunc_id: id,
					type: type,
					position: $(this).attr("position")
				};
				if ( $(this).attr("length") )
				{
					obj.length = $(this).attr("length");
				}
				//-------------------------------
				if ( typeof css !== "undefined" )
				{
					obj.css = css;
				}

				params.push( obj );
			}
			
			if ( type == "value")
			{
				var id = $(this).attr("id");
				var obj = {
					xfunc_id: id,
					type: type,
					value: $(this).text()
				};
				//-------------------------------
				if ( typeof css !== "undefined" )
				{
					obj.css = css;
				}
				
				params.push( obj );
			}

			if (type == "field")
			{
				var obj = get_attr_to_obj( this.attributes );
				obj.xfunc_id = obj.id;
				params.push( obj );
			}

		});
//console.log(params);
		return params;
	}//end read_xfunc_format_params()

	function process_format_value( field_values, params )
	{
		for ( var index in field_values )
		{			
			var field_value = field_values[index];
if(typeof field_value == "string")
{
			var format_field_value = [];
			for (var item in params)
			{
if(typeof params[item] == "object")
{
				if( typeof params[item].css !== "undefined")
				{
					var css = params[item].css;
				}
				
				if( params[item].type == "substr" )
				{
					var s_pos = params[item].position - 1;
					if (params[item].length)
					{
						var s_length = params[item].length;
					}
					else
						var s_length = field_value.length;
					
					var sub_value = field_value.substr(s_pos, s_length);
					format_field_value[item] = sub_value;
				}
				
				if( params[item].type == "value" )
				{
					format_field_value[item] = params[item].value;
				}
				
				if( params[item].type == "field" )
				{
					format_field_value[item] = field_values;
				}
				
}//fix ie
			}
			field_values[index] = format_field_value.join("");
			
			//apply style
			if( typeof css !== "undefined" && css.length > 0)
			{
				field_values[index] = css_tpl
				.replace("#css", css)
				.replace("#data", field_values[index]);
			}
			
			//fix
			if( field_values[index].indexOf("&nbsp;-") != -1)
			{
				field_values[index] = "&nbsp;";
			}
}//fix ie
		}			

		return field_values;
	}//end process_format_value()

	
	function get_attr_to_obj( attr )	
	{			
		var item_attr = {};				
		for(var item = 0; item < attr.length; item++)
		{
			item_attr[attr[item].name] = attr[item].value;
		}
		return item_attr;
	}//end get_attr_to_obj()
	
	
	var get_detail_block = function( block_id, xbr_id, reload )
	{
		var exec_start = new Date();
		
		if( typeof table_data.xml_obj === "undefined" ||
			reload !== 0)
		{
			if( reload !== 0)
			{
				var exec2_start = new Date();
				//reload xb in object
				var parent_id = table_data["detail_blocks"][block_id]["block_info"]["parent_id"];
				table_data.xml_obj = get_xml_obj( table_data.xml_info, parent_id, xbr_id );
				var exec2_end = new Date();
				var runtime_s = (exec2_end.getTime() - exec2_start.getTime()) / 1000;
				table_data.log.push("function get_xml_obj(), reload xb,  runtime: " + runtime_s + " sec");
			}
			//else
			//{
				//read all xml in object
				//var exec2_start = new Date();
				//table_data.xml_obj = get_xml_obj( table_data.xml_info );
				//var exec2_end = new Date();
				//var runtime_s = (exec2_end.getTime() - exec2_start.getTime()) / 1000;
				//table_data.log.push("function get_xml_obj, runtime: " + runtime_s + " sec");
			//}
		}
		
		//read columns info
		var columns = [];
		get_columns( table_data["detail_blocks"][block_id]["block_info"], columns, "" );
		table_data["detail_blocks"][block_id]["columns"] = columns;
			
		//read xml data
		table_data["detail_blocks"][block_id]["records"] = get_records( table_data["detail_blocks"][block_id], xbr_id );
			
		var exec_end = new Date();
		var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
		table_data.log.push("ZListLoader, function get_detail_block, runtime: " + runtime_s + " sec");
		
		
		function get_columns( block_info, columns, pos ){
			for(var item in block_info)
			{
				if ( item == "fields" )
				{
					for(var field in block_info["fields"] )
					{
						if( block_info["fields"][field]["visible"] == "1" )
						{
							var add_column = 1;						
							for(var key in columns)
							{
								if( block_info["fields"][field]["id"] === columns[key]["id"]  )
								{
									add_column = 0;
								}
							}
							if(add_column == 1)
							{
								if( typeof block_info["fields"][field]["textbefore"] !== "undefined")
								{
									var title = block_info["fields"][field]["textbefore"]
								}
								else
								{
									var title = "&nbsp;";
								}								
								var column_obj = {
									"id": block_info["fields"][field]["id"],
									"title": title,
									"pos": pos + block_info["fields"][field]["pos"]
								};
								columns.push( column_obj );
							}							
						}
					}
				}
				
				if ( item == "blocks" )
				{
					for(var block in block_info[item] )
					{
						get_columns( block_info[item][block], columns, block_info[item][block]["pos"] );
					}
				}

				if ( item == "groups")
				{
					for(var group in block_info[item] )
					{
						var column_obj = {
							"id": block_info["groups"][group]["group_id"],
							"title": block_info["groups"][group]["textbefore"],
							"pos": pos + block_info["groups"][group]["pos"]
						};
						columns.push( column_obj );
					}
				}
			}
			//sort columns
			for(var n1 = 0; n1 < columns.length; n1++)
			{
				for(var n2 = 0; n2 < columns.length; n2++)
				{
					//if( parseInt( columns[n1]["pos"] ) < parseInt( columns[n2]["pos"] ) )
					if( parseInt( columns[n1]["id"] ) < parseInt( columns[n2]["id"] ) )
					{
						var id = columns[n2]["id"];
						var title = columns[n2]["title"];
						var pos = columns[n2]["pos"];
						
						columns[n2]["id"] = columns[n1]["id"];
						columns[n2]["title"] = columns[n1]["title"];
						columns[n2]["pos"] = columns[n1]["pos"];
						
						columns[n1]["id"] = id;
						columns[n1]["title"] = title;
						columns[n1]["pos"] = pos;
					}
				}
			}
		
		}//end get_columns()
		
		function get_records( block, xbr_id )
		{
			var id = "xb#" + block["block_info"]["block_id"];// "xb#335904";//"xb#335409"//"xbr#1";//"xf#335412";
			if( xbr_id.indexOf("xbr#") == -1)
			{
				if( xbr_id.indexOf("#") == -1)
				{
					xbr_id = "xbr#"+xbr_id;
				}
				if( xbr_id.indexOf("#") !== -1)
				{
					xbr_id = "xbr"+xbr_id;
				}
			}
			
			var xblock = [];
			get_xml_block( id, xbr_id, table_data["xml_obj"]);
//console.log(xbr_id, xblock);
			
			//save xb attributes
			for(var item in  xblock)
			{
//if( typeof xblock[item] === "object")			
//{
				if( item === "attributes")
				{
					block["block_info"]["xb_attributes"] = xblock[item];
				}
//}
			}
			
			var table = [];
			table["ch_xbr_id"] = [];
			parse_xblock( xblock );
//console.log(table);
			return table;
			
			function parse_xblock( xblock )
			{
				var xbr_limit = "";
				for(var item in xblock)
				{
//if( typeof xblock[item] !== "object")
//{
//continue;
//}
					if( item.indexOf("xbr#") !== -1 )
					{
						//if( table["first_xbr_id"] == "")
						//{
							//table["first_xbr_id"] = item.replace("xbr#", "");
							table["ch_xbr_id"].push( item.replace("xbr#", "") );
						//}
						
						var record = [];
						parse_xbr( xblock[item], record );
						
						for(var index in block["columns"] )
						{
	if( typeof block["columns"][index] === "object")
	{
							var test_id = "xf#" + block["columns"][index]["id"];
							if( record[test_id].length == 0 )
							{
								record[test_id].push("&nbsp;");
							}
	}//fix							
						}//next column
						table.push( record );
					}
					
					if( item.indexOf("xbr_limit") !== -1 )
					{
						xbr_limit = xblock[item];
					}
					
				}//next xbr

				if( typeof xbr_limit == "object")
				{
					var counters = [];
					for(var n = 0; n < block["columns"].length; n++ )
					{
						counters[n] = 0;
					}
					for(var num_rec = 0; num_rec < table.length; num_rec++ )
					{
						var num=0;
						for(var column in table[num_rec] )
						{
//console.log( num_rec, column, table[num_rec][column] );	
							if( table[num_rec][column][0] !== "&nbsp;")
							{
								counters[num]++;
							}
							num++;
						}//next column
					}//next record
					
					//add limit message in last table line
					var xbr_max_limit = xbr_limit["count"] - xbr_limit["remain"];
					var num_rec = table.length;
					table[num_rec] = [];
					var num=0;
					for( var column in table[num_rec-1] )
					{
						if( counters[num] >= xbr_max_limit )
						{
							table[num_rec][column] = [ xbr_limit["html"] ];
						}
						else
						{
							table[num_rec][column] = ["#colspan"];
						}
						num++;
					}
//table[num_rec]["xf#401214"] = ["098"];
//table[num_rec]["xf#401216"] = ["089"];
					
				}
				
				
				
				function parse_xbr( xbr, record )
				{
					for(var index in block["columns"] )
					{
if( typeof block["columns"][index] !== "object")
{
//alert(typeof block["columns"][index]);
continue;
}
						var test_id = "xf#" + block["columns"][index]["id"];
						if( typeof record[test_id] === "undefined")
						{
							record[test_id] = [];
						}
					}//next column
								
					for(var id in xbr)
					{
						var fvalue = "";
						if( id.indexOf("xf#") !== -1)
						{
							for(var index in block["columns"] )
							{
								var test_id = "xf#" + block["columns"][index]["id"];
								if( id === test_id)
								{
									var f_array = xbr[id];
									$.each( f_array, function( index, value ) {
										if( index > 0 )
										{
											fvalue += ", " + f_array[index];
										}
										else
										{
											fvalue += f_array[index];
										}
									});
									break;
								}
							}//next column
							
						}//end test xf
						
						for(var ch_block_id in  xbr[id])
						{
							if( ch_block_id.indexOf("xb#") !== -1)
							{
								parse_xblock_child( xbr[id][ch_block_id], record );
							}
						}
					
						if(fvalue.length > 0)
						{
							if( typeof record[id] === "undefined")
							{
								record[id] = [];
							}
							record[id].push( fvalue );
						}
							
					}//next  id
					
				}// end function parse_xbr()

				function parse_xblock_child( xblock, record )
				{
					for( var xbr_id in xblock )
					{
						parse_xbr(xblock[ xbr_id ], record );
					}
				}// end function parse_xbr_child()

			}//end parse_xblock()
			
			
			function get_xml_block( id, xbr_id, parent_block )
			{
				for( var item in parent_block)
				{
					if( typeof parent_block[item] === "object" )
					{
						if( item === xbr_id || xbr_id === "xbr#0" )
						{
							var block = [];
							if( xbr_id === "xbr#0" )
							{
								get_block(id, parent_block[item]);
								
								var xbr_index = "";
								for(var block_item in block)
								{
									if( block_item.indexOf("xbr#") !== -1)
									{
										xbr_index = block_item;
										xblock[xbr_index] = block[block_item];
									}
								}
								//xblock.push(block);
							}
							else
							{
								get_block(id, parent_block[item]);
								xblock = block;
								return;
							}
						}
						else
						{
							get_xml_block( id, xbr_id, parent_block[item] )
						}
					}					
				}//next item
				
				function get_block( id, parent_block )
				{
					for( var item in parent_block)
					{
						if( typeof parent_block[item] === "object" )
						{
							if( item == id )
							{
//console.log(id);		
								block = parent_block[item]
								return;
							}
							else
							{
								get_block( id, parent_block[item] )
							}
						}					
					}//next item
				}//end get block
				
			}//end get_xml_block()

		}//end get_records()

	}//end get_detail_blocks
		
	return{
		table_data: table_data,
		get_table_data:	function( update_xml ){ 
			return get_table_data( update_xml ); 
		},
		get_detail_block: function( block_id, xbr_id, reload ){ 
			return get_detail_block( block_id, xbr_id, reload ); 
		}
	};
	
}// end ZListLoader
 
window.ZListLoader = ZListLoader;
	
})();