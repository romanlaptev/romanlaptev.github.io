//alert("loading csprd.js ...");

var dmSprPtr = {};
var dmSpr = undefined;

function CSpr()
{
	this.sprsize = 10;
	this.name	= "CSpr";
	this.nomer	= "";
	this.textField			= null;
	this.codeField			= null;
	this.documentOnClick	= document.onclick;
	this.documentOnKeydown	= document.onkeydown;

	this.tabElements		= new Array();
	this.activeList			= null;
	this.partialList		= null;
	this.fullList			= null;

	this.partialMode		= "";
	this.partialFilter		= "";
	this.multi				= false;
	this.singleCheck		= false;
//	this.hint_max_values	= 10;

	//this.mode				= "";

	this.baseurl			= ""; // for debugging purposes! do not edit this line, set it from outside only!

	this.switchFullModeState =
	function _switchFullModeState(){
		var btn_text = '';
		if(this.codeField.full_mode_state == "f"){
			btn_text = '$res:form.spr.fav$';
			this.codeField.full_mode_state = "a";
		}else{
			btn_text = '$res:form.spr.all$';
			this.codeField.full_mode_state = "f";
		}
		this.search.value = '';
		this.refresh();
		this.showall.value = btn_text;
		this.ds.style.width = '100px';
		this.div.style.width = '180px';
		this.ds.style.width = _spr.m_table.rows[1].cells[0].clientWidth;
		//this.ds.style.width = '100%';
		this.ds.w = this.ds.offsetWidth;
		this.render();
	}

	// setFull - set spr to the full mode (all values)
	this.setFull =
	function _setFull(setFocusTo){
		var i;
		for(i = 0; i < this.activeList.options.length; i++)
			_showObject(this.activeList.options[i]);
		this.ds.ds.partial = false;
		this.showall.disabled = true;
		this.setTabElements();
		if(setFocusTo) setFocusTo.focus();
	}

	// setPartial - set spr to the partial mode accordingly to the
	// given mode and filter (e.g. for 2nd level spr or 'favorite' mode)
	this.setPartial =
	function _setPartial(mode, filter){
		var i;
		var oOption;
		var condition;

		if(this.div.multiLevel == ""){
			this.div.multiLevel = "0";
			for(i = 0; i < this.activeList.options.length; i++){
				if(this.activeList.options[i].group != ''){
					this.div.multiLevel = "1";
					break;
				}
			}
		}

		if(this.div.multiLevel == "1" || mode == "_favorite_"){
			if(this.div.partialMode != mode || this.div.partialFilter != filter){

				// set full first if select already in partial mode
				// (some other partial)
				if(this.ds.ds.partial)
					this.setFull();

				switch(mode){
					case "_favorite_" :{
						condition = "this.activeList.options[i].favorite == '1'";
					}break;
					case "_group_" :{
						//alert("mode = _group_, filter = " + filter);
						condition = "this.activeList.options[i].group == '" + filter + "'";
					}break;
					case "_1level_" :{
						//alert("_1level_");
						condition = "this.activeList.options[i].group == ''";
					}break;
					case "_2level_" :{
						//alert("_2level_");
						condition = "this.activeList.options[i].group != ''";
					}break;
					case "_level_" :{
						//alert("_level_");
						condition = "this.activeList.options[i].level == '" + filter + "'";
					}break;
				}

				for(i = 0; i < this.activeList.options.length; i++){
					if(!(eval(condition) || this.activeList.getOptionText(i) == "")){
						_hideObject(this.activeList.options[i]);
					}
				}

				this.div.partialMode	= mode;
				this.div.partialFilter	= filter;
				this.ds.ds.partial = true;
			}

			// condition below is wrong: we should not enable [All] button,
			// except mode is 'favorite'. User CAN NOT select any values from 1 level
			// when he is on second level
			/*
			if(this.codeField.klass_type != "1" && this.codeField.klass_type != "5"){
				_enableObject(this.showall);
			}
			*/
			// this is right code
			if(mode == "_favorite_")
				_enableObject(this.showall);

			this.setTabElements();
		}
	}

	// setTabElements - fill in the tabElements array in order to be able to
	// cycle between elements inside spr window
	this.setTabElements =
	function _setTabElements(){
		this.tabElements.splice(0, this.tabElements.length);

		this.tabElements.push(this.search, this.activeList.ds);
		/*
		if(this.multi)
			this.tabElements.push(this.oper[0], this.oper[1]);
		if(this.codeField.full_mode)
			this.tabElements.push(this.showall);
		this.tabElements.push(this.bRefresh, this.bOk);
		*/
	}


	// used for check spr options when it was refreshed, but we need to check options which
	// has been selected before
	this.check_by_codefield =
	function _spr_check_by_codefield(){
		var checked_not = false;
		var i, k;
		if(this.notCheck.checked) checked_not = true;
		var sep = '|';
		var code = this.codeField.value;
		if(code.substr(0, 1) == '^') code = code.substr(1);
		if(code.indexOf('&') != -1) sep = '&';
		var code_array = code.split(sep);

		for(k = 0; k < code_array.length; k++){
			for(i = 0; i < this.activeList.options.length; i++){
				if(this.activeList.options[i].value == code_array[k]){
					this.activeList.checkOption(i, checked_not);
				}
			}
		}
	}

	this.load =
	function _load(from, mode, offset){

		//alert("load: begin");
		top.status = "$res:form.spr.message.load$";
		var alreadyLoaded	= true;
		var lov_main_kod	= "";
		var lov_txt			= "";
		var t_lov_txt		= "";
		var t_amount		= 0;
		var t_all			= 1;
		var s_from;
		var str;
		var spr_load_threshold;
		var removeOpt	= 0;

		var data_re = /\<\/*data\>/gi; // for removing <data> and </data> tags from data node XML
		var responseXML;
		var optHTML;
		var moreopt;

		// get the spr_load_threshold
		if(thisFrm.spr_load_threshold) spr_load_threshold = parseInt(thisFrm.spr_load_threshold.value);
		else spr_load_threshold = 100;

		// assign 's_from' accordingly to 'from' in order to be able
		// to pass this param via setTimeout (there is can be only character data)
		if(from == _SPR_LOAD_OPEN)		s_from = "_SPR_LOAD_OPEN";
		if(from == _SPR_LOAD_KEYDOWN)	s_from = "_SPR_LOAD_KEYDOWN";
		if(from == _SPR_LOAD_KEYUP)		s_from = "_SPR_LOAD_KEYUP";
		if(from == _SPR_LOAD_REFRESH)	s_from = "_SPR_LOAD_REFRESH";


		// set default mode if not specified
		if(mode == undefined) mode = _SPR_LOAD_GET;

		if(mode == _SPR_LOAD_GET)	s_mode = "_SPR_LOAD_GET";
		if(mode == _SPR_LOAD_LOAD)	s_mode = "_SPR_LOAD_LOAD";
		if(mode == _SPR_LOAD_WAIT)	s_mode = "_SPR_LOAD_WAIT";
		if(mode == _SPR_LOAD_READY)	s_mode = "_SPR_LOAD_READY";

		_debug("load(): from: " + s_from + ", mode: " + s_mode);
		// determine whether spr already loaded for current params
		// fill ds params if undefined
		if(_spr.ds.bname == undefined)	_spr.ds.bname	= "";
		if(_spr.ds.fname == undefined)	_spr.ds.fname	= "";
		if(_spr.ds.ltxt == undefined)	_spr.ds.ltxt	= "";
		if(_spr.ds.lmkod == undefined)	_spr.ds.lmkod	= "";
		if(_spr.ds.bpos == undefined)	_spr.ds.bpos	= 0;
		if(_spr.ds.moreopt == undefined)_spr.ds.moreopt	= false;

		// get lov_txt
		if(_spr.textField.value.indexOf("|") == -1 && _spr.textField.value.indexOf("&") == -1)
			// if textField contains only one value, get it as lov_txt
			lov_txt = _spr.textField.value;
		else
			// else, get searchCondition as lov_txt
			lov_txt = _spr.searchCondition;

		if( from == _SPR_LOAD_KEYUP || from == _SPR_LOAD_KEYDOWN){
			// get searchCodition as lov_txt for keyup/keydown events so that correct
			// load prev/next pages
			lov_txt = _spr.searchCondition;
		}
		if( from == _SPR_LOAD_REFRESH){
			// in refresh always get search.value and put it into searchCondition
			lov_txt = _spr.search.value;
			_spr.searchCondition = _spr.search.value;
			alreadyLoaded = false;
		}

		lov_main_kod = _spr.getMasterValue();

		// remove leading `=` and `^` symbols from lov_txt
		if(lov_txt.substr(0, 1) == "=") lov_txt = lov_txt.substr(1);
		if(lov_txt.substr(0, 1) == "^") lov_txt = lov_txt.substr(1);

		if(this.codeField.klass_type == 3 && lov_txt == ""){
			// set mode to `iestade` for klass_type = 3 only if lov_txt is empty, so that if user do not type
			// any criteria we need to show spr as tree (iestade) and dselect must init options array specifically
			this.ds.mode = "iestade";
			if(this.codeField.list_type == 3) this.ds.mode = "iestade:plain";
		}else{ this.ds.mode = ''; }

		// check whether we need to reload spr
		_debug('load: bname : ' + _spr.ds.bname + ', ' + _spr.codeField.bname);
		_debug('load: fname : ' + _spr.ds.fname + ', ' + _spr.codeField.aname);
		_debug('load: lov_txt : ' + _spr.ds.ltxt + ', ' + lov_txt);
		_debug('load: lov_main_kod : ' + _spr.ds.lmkod + ', ' + lov_main_kod);
		if(	_spr.ds.bname	!= _spr.codeField.bname ||
			_spr.ds.fname	!= _spr.codeField.aname ||
			_spr.ds.ltxt	!= lov_txt ||
			_spr.ds.lmkod	!= lov_main_kod
			)
			{
				//if(_spr.ds.bname	!= _spr.codeField.bname) alert("bname");
				//if(_spr.ds.fname	!= _spr.codeField.aname) alert("aname");
				/*
				if(_spr.ds.ltxt	!= lov_txt) {
					alert("ltxt: [" + _spr.ds.ltxt + "], [" + lov_txt + "]");
					alert("ltxt: [" + getUnicodeString(_spr.ds.ltxt) + "], [" + getUnicodeString(lov_txt) + "]");
				}
				*/
				//if(_spr.ds.lmkod	!= lov_main_kod) alert("lmkod");
				alreadyLoaded = false;
				_spr.ds.bpos = 0;
				//_debug("load(): not-loaded:bname/fname/etc");
			}

		// flush bpos if this is refresh operation
		// because we need to search from 1st position in this case
		if(from == _SPR_LOAD_REFRESH)
			_spr.ds.bpos = 0;

		// we NEED to reload if it's load by key from dselect (not for iestade spr)
		if(from == _SPR_LOAD_KEYDOWN)	{ alreadyLoaded = false; }
		if(from == _SPR_LOAD_KEYUP)		{ alreadyLoaded = false; }

		// flush spr if we has been scrolled more than to pages (so that display items form 1st entry)
		if(_spr.ds.bpos >= (spr_load_threshold*2) && from == _SPR_LOAD_OPEN){ alreadyLoaded = false; _spr.ds.bpos = 0; }

		// get spr content from server
		if(!alreadyLoaded){
			if(mode == _SPR_LOAD_GET){
				str = "GET request:\n";
				//str += "block = " + _spr.codeField.bname + "\n";
				//str += "field = " + _spr.codeField.aname + "\n";
				//str += "lov_txt = " + lov_txt + "\n";
				//str += "lov_main_kod = " + lov_main_kod + "\n";
				str += "bpos = " + _spr.ds.bpos + "\n";
				_debug("load(): " + str);

				// getspr from server
				t_lov_txt = lov_txt;
				// add trailing `%` symbol if user has not specified it
				if(t_lov_txt != "" && t_lov_txt.indexOf("%") == -1) t_lov_txt += "%";
				t_amount = spr_load_threshold; // amount of options to be loaded
				if(this.ds.mode == 'iestade') t_amount = 0; // set amount to zero for iestade - always load all options for given level(kod)
				if(this.codeField.full_mode && this.codeField.full_mode_state == 'f') t_all = 0;
				var form_name = thisFrm.formname;
				if(thisFrm.base_form) form_name = thisFrm.base_form;

				responseXML = _spr.getspr(form_name, _spr.codeField.bname, _spr.codeField.aname, _spr.ds.bpos, t_amount, t_lov_txt, lov_main_kod, t_all);
				optHTML = responseXML.selectSingleNode("/root/data").xml.replace(data_re, "");
				moreopt = responseXML.selectSingleNode("/root/reply/moreopt").getAttribute("value");
				mode = _SPR_LOAD_LOAD;

// 17.01.2006: correction - show Iestade checkbox ONLY for `iestade` mode
// 16.03.2006: correction - show Iestade checkbox for `iestade:plain` mode also
				if(this.ds.mode == 'iestade' || this.ds.mode == 'iestade:plain')
// 01.11.2009: correction - show Iestade checkbox for klass_type=3
				if(this.ds.mode == 'iestade' || this.codeField.klass_type == 3){
					_showObject(this.iestadeCell);
					if(this.codeField.inc_hierarchy){
						switch(this.codeField.inc_hierarchy){
							case "1":{
								this.iestadeCheck.checked = true;
							}break;
							case "2":{
								this.iestadeCheck.checked = true;
								_hideObject(this.iestadeCell);
							}break;
							case "3":{
								this.iestadeCheck.checked = false;
								_hideObject(this.iestadeCell);
							}break;
						}
					}
					else this.iestadeCheck.checked = false;
				}else{
					_hideObject(this.iestadeCell);
					//this.iestadeCheck.checked = false;
				}
			}
		}

		// when loadFrame is complete, load spr content into apropriate div
		// accordingly with operation
		if(mode == _SPR_LOAD_LOAD){

			// load() was called from _spr.open() function
			if(from == _SPR_LOAD_OPEN || from == _SPR_LOAD_REFRESH){
				//_debug("load(): process load_load from load_open");
				// assign new params to the ds in order to do not load again the same content
				_spr.ds.bname	= _spr.codeField.bname;
				_spr.ds.fname	= _spr.codeField.aname;
				_spr.ds.ltxt	= lov_txt;
				_spr.ds.lmkod	= lov_main_kod;

				_spr.alreadyLoaded = true;

				// replace spr content
				str = "";
				// add empty first option (only if we got something in loadFrame)
				if(optHTML != ""){
					str = "<div class='o' value='' group=''>&#xA0;</div>";
				}
				//alert(optHTML);
				// replace spr div content
				_spr.ds.innerHTML = '';
				//alert("html:\n" + '<div style="width:100%;height:100%;border:1px solid black">' + str + optHTML + '</div>');
				//var dv = _spr.ds.firstChild;
				//dv.innerHTML = str + optHTML;
				_spr.ds.innerHTML = str + optHTML;

//				_spr.div.style.width = 50;
/*
				var v = window.open("", "wPrnWindow" + _getUniqueID(), "resizable=yes,scrollbars=yes,status=yes");
				vdoc = v.document;
				vdoc.open();
				vdoc.write('<html><body>' + _spr.ds.outerHTML + '</body></html>');
				vdoc.close();
*/
				//alert(_spr.ds.outerHTML);

				// create dSelect if not exist ot just init() it.
				if(!_spr.ds.ds)
					_spr.ds.ds = new dSelect(_spr.ds);
				else
					_spr.ds.ds.init(_spr.ds);

				// check for more options and set [moreopt] attribute to the spr div
				if(moreopt == "1") {_spr.ds.moreopt = true;}
				else _spr.ds.moreopt = false;

				// set selectedIndex to 0 because it is _spr.open()
				_spr.ds.ds.selectedIndex = 0;

				if(from == _SPR_LOAD_REFRESH){
					_spr.ds.ds.highliteOption(_spr.ds.ds.selectedIndex);
					_spr.search.focus();
					_spr.ds.style.width = _spr.ds.w;
					_spr.render();
				}
				_spr.ds.ds.clearCheckedValues();
				_spr.bOk.disabled = true;

				// !! HERE ADDED !!
				//_debug('LOAD_OPEN | LOAD_REFRESH: restoreChecked');
				//_spr.check_by_codefield();
				//this.restoreChecked();
			}

			// load() was called from dSelect.keydown, [down arrow] or [PageDown]
			if(from == _SPR_LOAD_KEYDOWN){

				_spr.alreadyLoaded = true;

				// add spr content to the end of the list
				_spr.ds.innerHTML += optHTML;

				// create dSelect if not exist or just init() it.
				if(!_spr.ds.ds)
					_spr.ds.ds = new dSelect(_spr.ds);
				else
					_spr.ds.ds.init(_spr.ds);

				// check for more options and set [moreopt] attribute to the spr div
				if(moreopt == "1") _spr.ds.moreopt = true;
				else _spr.ds.moreopt = false;


				// remove options from the top of the list if we exceeds spr_load_threshold*2
				// (two pages)
				// (_spr.ds.ds.options.length - 1) because first option is empty option
				if((_spr.ds.ds.options.length - 1) > (spr_load_threshold*2)){
					// remove options from the top of the list
					removeOpt = spr_load_threshold;
					_spr.ds.ds.removeOptions(removeOpt, 'top');

					// reinitialize dselect object
					_spr.ds.ds.init(_spr.ds);
					_spr.ds.ds.selectedIndex -= removeOpt;
				}

				// set seletedIdex to selectedIndex + offset and move selected option to the bottom
				// if it was [down arrow], offset = 1, if it was [PageDown], offset = [optperpage]
				_spr.ds.ds.highliteOption(_spr.ds.ds.selectedIndex + offset, "bottom");
				this.restoreChecked();
				_spr.ds.style.width = _spr.ds.w;
				this.render();
			}

			// load() was called from dSelect.keydown, [up arrow] or [PageUp]
			if(from == _SPR_LOAD_KEYUP){
				_spr.alreadyLoaded = true;

				// remember first empty option outerHTML
				str = _spr.ds.ds.options[0].outerHTML;
				// remove first empty option
				_spr.ds.removeChild(_spr.ds.ds.options[0]);

				// add received content to the top of the content
				_spr.ds.innerHTML = str + optHTML + _spr.ds.innerHTML;

				// create dSelect if not exist ot just init() it.
				if(!_spr.ds.ds)
					_spr.ds.ds = new dSelect(_spr.ds);
				else
					_spr.ds.ds.init(_spr.ds);

				// check for more options and set [moreopt] attribute to the spr div
				if(moreopt == "1") _spr.ds.moreopt = true;
				else _spr.ds.moreopt = false;

				// remove options from the bottom of the list if we exceeds spr_load_threshold*2
				// (_spr.ds.ds.options.length - 1) because first option is empty option
				if((_spr.ds.ds.options.length - 1) > (spr_load_threshold*2)){
					// remove options from the bottom of the list
					//removeOpt = spr_load_threshold;
					removeOpt = (_spr.ds.ds.options.length - 1) - (spr_load_threshold*2);
					_spr.ds.ds.removeOptions(removeOpt, 'bottom');
					// reinitialize dselect object
					_spr.ds.ds.init(_spr.ds);
				}

				// set selectedIndex to the selectedIndex += spr_load_threshold;
				_spr.ds.ds.selectedIndex += spr_load_threshold;
				// highlite option accordingly to offset
				_spr.ds.ds.highliteOption(spr_load_threshold - offset, "top");
				// set bpos to the page toward, because we loaded TWO page backward
				_spr.ds.bpos += spr_load_threshold;
				this.restoreChecked();
				_spr.ds.style.width = _spr.ds.w;
				this.render();
			}

		}
		//_debug("load(): returning ready");
		top.status = "";
		return _SPR_LOAD_READY;
	}


	// function open() - show spr for specified code field
	this.open =
	function _open(codeField)
	{
		//alert(1);
		var init_spr	= false;
		var comma_re	= /\,/gi;
		//_opendebug();
		//_debug("open(): begin");

		if(codeField && codeField.length){
			alert("$res:error.duplicate-field$");
			return;
		}
		//if(codeField.mfs){ for(var j = 0; j < codeField.mfs.length; j++) alert('mf = ' + codeField.mfs[j].id);}

		this.codeField	= codeField;
		this.textField	= document.all["x_" + codeField.id];
		if(this.textField.dm_spr || (this.codeField.spr == 'SL_KLASS433_433' && this.codeField.klass_type == '9')){
			if(this.codeField.mfs && _trim(this.getMasterValue().replace(comma_re, '')) == "" && !this.codeField.fill_1_mode){
				alert("$res:form.spr.message.nofirstlevel$");
				return;
			}
			//alert("Digiman SPR...");
			openDigimanSpr(this.codeField, this.textField, document.all["b_" + codeField.id]);
			return;
		}
		var posLeft, posTop, clientHeight;
		//alert(1.1);
		this.hide();
		//alert(1.2);
		var sprNomer;
		sprNomer = codeField.spr;
		if(this.nomer != sprNomer) init_spr = true;
		this.nomer = sprNomer;
		this.multi = false;
		//alert(1.3);
		if(init_spr){
			//alert("assign controls");
			//_debug("open(): assign controls");
			// assign contorls
			var xdiv = document.all.xsprs;
			this.div			= xdiv.all["_spr_control_div_"			+ sprNomer];
			this.m_table			= xdiv.all["_spr_m_table_"			+ sprNomer];
			this.c_table			= xdiv.all["_spr_c_table_"			+ sprNomer];
			this.ds				= this.div.all["_spr_control_select_"		+ sprNomer];
			this.search			= this.div.all["_spr_control_search_"		+ sprNomer];
			this.oper			= this.div.all["_spr_control_oper_"			+ sprNomer];
			this.operCell		= this.div.all["_spr_control_oper_cell_"	+ sprNomer];
			this.iestadeCell	= this.div.all["_spr_iestade_cell_"			+ sprNomer];
			this.checkallCell	= this.div.all["_spr_checkall_cell_"		+ sprNomer];
			this.noarchCell		= this.div.all["_spr_noarch_cell_"		+ sprNomer];
			this.iestadeCheck	= this.iestadeCell.firstChild;
			this.checkAll		= this.checkallCell.firstChild;
			this.noarch		= this.noarchCell.firstChild;
			this.showall		= this.div.all["_spr_control_all_"			+ sprNomer];
			this.showallCell	= this.div.all["_spr_all_cell_"			+ sprNomer];
			this.bRefresh		= this.div.all["_spr_control_refresh_"		+ sprNomer];
			this.bOk			= this.div.all["_spr_control_ok_"			+ sprNomer];
			this.notCheck		= this.div.all["_spr_control_not_"			+ sprNomer];
			this.notCell		= this.div.all["_spr_not_cell_"				+ sprNomer];
			this.bClear			= this.div.all["_spr_control_clear_"		+ sprNomer];
			// hide showall button, now this button is not used
			//if(this.showall) _hideObject(this.showall);

			if(this.codeField.noarchive){
				switch(this.codeField.noarchive){
					case "1":{
						this.noarch.checked = true;
					}break;
					case "2":{
						this.noarch.checked = true;
						_hideObject(this.noarchCell);
					}break;
					case "3":{
						this.noarch.checked = false;
						_hideObject(this.noarchCell);
					}break;
				}
			}else this.noarch.checked = false;

		}
		//alert(2);

		if(this.codeField.full_mode){
			if(this.codeField.full_mode_state == "f"){
				this.showall.value = "$res:form.spr.all$";
			}else{
				this.showall.value = "$res:form.spr.fav$";
			}
			_showObject(this.showallCell);
		}else{
			_hideObject(this.showallCell);
		}


		// dissalow decoding by onFieldBlur while opening spr window, so that we can just type A
		// and press F9 and get A% values instead of decoding A code
		this.textField.nodecode = 1;

		if(this.codeField.single)
			this.single = true;
		else
			this.single = false;

		if(this.codeField.multi){
			this.multi = true;
			_showObject(this.operCell);
		}else{
			this.multi = false;
			this.oper[0].checked = true;
			_hideObject(this.operCell);
		}

		if(this.codeField.checkall){
			_showObject(this.checkallCell);
		}else{
			_enableObject(this.notCheck);
			_hideObject(this.checkallCell);
		}

		if(this.codeField.no_except){
			if(this.codeField.no_except == "1"){
				_hideObject(this.notCell);
				this.notCheck.checked = false;
			}
			if(this.codeField.no_except == "2"){
				this.notCheck.checked = true;
			}
		}else{
			_showObject(this.notCell);
		}

		//alert(2.1);
		/*
		if(this.codeField.klass_type == "1" || this.codeField.klass_type == "5"){
			_disableObject(this.showall);
		}
		*/
		//alert(2.2);
		if(!this.ds.ds){
			this.activeList		= new dSelect(this.ds);
		}else{
			this.activeList		= this.ds.ds;
		}

		_debug('this.ds.bpos = ' + this.ds.bpos);
		//alert(2.3);
		//_debug("open(): try to load");

		if(this.codeField.mfs && _trim(this.getMasterValue().replace(comma_re, '')) == "" && !this.codeField.fill_1_mode){
			alert("$res:form.spr.message.nofirstlevel$");
			this.textField.nodecode = 0;
			// clear this.nomer so that next time spr opens, init_spr become true,
			// because else event handlers does not activate
			this.nomer = "";
			return;
		}

		//if(this.load(_SPR_LOAD_OPEN) == _SPR_LOAD_WAIT){ _debug("load returned WAIT"); return; }
		try{
			this.load(_SPR_LOAD_OPEN);
		}catch(e){
			alert_e(e, 'spr.open-load');
			return;
		}
		//_debug("continue opening..");
		//alert(3);

		//this.setFull(); -- comented because there is no need to set full
		// at the begining, each spr already in full mode, only one we need
		// to do is setTabElements in order to be able to move via TAB
		if(init_spr){
			this.setTabElements();
		}
		// 31.05.2003 - we not need set partial now, because we load spr every time
		// if condition changed

		//_debug("open(): show spr");
		if(init_spr){
			// assign handlers to spr controls
			this.activeList.onkeydown	= function() { _spr.keydown(this.ds); };
			this.search.onkeydown		= function() { _spr.keydown(this); };
			this.oper[0].onkeydown		= function() { _spr.keydown(this); };
			this.oper[1].onkeydown		= function() { _spr.keydown(this); };
			this.showall.onkeydown		= function() { _spr.keydown(this); };
			this.bRefresh.onkeydown		= function() { _spr.keydown(this); };
			this.bOk.onkeydown			= function() { _spr.keydown(this); };
			this.div.onkeydown			= function() { _spr.keydown(this); };
			this.search.onkeyup			= function() { _spr.keyup(this); };

			this.activeList.ondblclick	= function(){ _spr.choose(); };
			//this.showall.onclick		= function(){ _spr.setFull(_spr.search); };
			this.showall.onclick		= function(){ _spr.switchFullModeState(); };
			this.bOk.onclick			= function(){ _spr.choose(); window.event.cancelBubble = true; };
			this.bRefresh.onclick		= function(){ _spr.refresh(); window.event.cancelBubble = true;};
			this.iestadeCheck.onclick	= function(){ _spr.iestade_check_click(this); };
			this.checkAll.onclick		= function(){ _spr.check_all_click(this); };
			this.notCheck.onclick		= function(){ _spr.not_check_click(this); };
			this.bClear.onclick			= function(){ _spr.clear_click(); window.event.cancelBubble = true; };
		}
		//alert(4);
		clientHeight = document.all._content_div_.clientHeight;
		posLeft	= this.textField.offsetLeft;
		posTop	= this.textField.offsetTop + this.textField.offsetHeight - 1;
		//_debug("open(): move and show");
		//alert(4.1);
		this.move(posLeft, posTop);
		_debug("position: " + posLeft + ", " + posTop);
		//alert(4.2);
		// hide content-div scroll-bar in order to do not scroll by the wheel
		document.all._content_div_.style.overflowY = "hidden";

		_disableObject(this.bOk);
		if(this.activeList.getCheckedCount() != 0 || this.checkAll.checked)
			_enableObject(this.bOk);

		this.show();

		//this.bOk.style.width = this.bClear.offsetWidth;

		//if(this.checkAll.checked) _enableObject(this.bOk);
		//else _disableObject(this.bOk);

		// HERE

		//this.activeList.ds.style.width = 30;



		this.activeList.ds.className = "spr-select-focused";
		this.activeList.ds.className = "spr-select";
		this.search.focus();

		// resize spr div according to the sprsize if specified
		if(this.activeList.options.length){
			var sprsize = this.sprsize;
			if(this.codeField.sprsize) sprsize = parseInt(this.codeField.sprsize, 10);
			var diff = (this.activeList.options[0].offsetHeight * (sprsize + 1)) - this.ds.offsetHeight;
			this.div.style.height = this.div.offsetHeight + diff;
		}


		// move spr div to the top of the field if spr size more than clientHeight
		// (taking into account scrollTop value)
		// this moving is AFTER show, because we can get this.div.offsetHeight only after
		// showing div (damn!)
		if((posTop - document.all._content_div_.scrollTop + this.div.offsetHeight) > clientHeight){
			posTop = this.textField.offsetTop - this.div.offsetHeight;
			if(posTop < 0) posTop = 0 + document.all._content_div_.scrollTop;
			this.move(posLeft, posTop);
		}

		// move srp-div to the left if it's right border out of _content_div_.clientWidth
		if((posLeft + this.div.offsetWidth) > document.all._content_div_.clientWidth){
			posLeft = posLeft - ((posLeft + this.div.offsetWidth) - document.all._content_div_.clientWidth);
			if(posLeft < 0) posLeft = 0 + document.all._content_div_.scrollLeft;
			this.move(posLeft, posTop);
		}

		this.ds.w = this.ds.offsetWidth;
		this.render();
		//_debug("open(): setPosition to [" + this.textField.value + "]");

		// set the spr.search value to the text field value

		this.search.value = this.textField.value;
		if(this.search.value.substr(0, 1) == "=") this.search.value = this.search.value.substr(1);
		if(this.search.value.substr(0, 1) == "^") this.search.value = this.search.value.substr(1);

		if(this.search.value.indexOf("|") == -1 && this.search.value.indexOf("&") == -1)
			this.searchCondition = this.search.value;

		this.setPosition(this.search.value);
		//_debug("open(): after setPosition");

		// assign document.onclick in order to hide spr window when user
		// click somewhere outside spr window
		this.documentOnClick	= document.onclick;
		document.onclick		= function() { _spr.lostFocus(); }

		this.documentOnKeydown	= document.onkeydown;
		document.onkeydown		= null;
		// clear checks
		if(_trim(this.textField.value) == ''){
			var i;
			for(i = 0; i < this.activeList.options.length; i++){
				this.activeList.unCheckOption(i);
			}
		}

		//this.notCheck.checked = false;
		//this.checkAll.checked = false;
		//_enableObject(this.notCheck);
		//this.restoreChecked();
	}

	this.clear_click =
	function _clear_click(){
		this.search.value = '';
	}

	this.check_all_click =
	function _check_all_click(obj){
		if(obj.checked){
			this.notCheck.checked = false;
			this.activeList.uncheckAll();
			_disableObject(this.notCheck);
			_enableObject(this.bOk);
		}else{
			_enableObject(this.notCheck);
			_disableObject(this.bOk);
		}
	}

	this.iestade_check_click =
	function _iestade_check_click(obj){
		var key;
		if(obj.checked && this.activeList.getCheckedCount() > 1){
			for(key in this.activeList.checkedValues)
				this.activeList.unCheckOption(this.activeList.checkedValues[key].pos);
		}
	}

	this.not_check_click =
	function _not_check_click(obj){
		var key;
		var checked_not = obj.checked;
		if(this.activeList.getCheckedCount() > 0){
			for(key in this.activeList.checkedValues)
				 this.activeList.checkOption(this.activeList.checkedValues[key].pos, checked_not, false, key);
		}
	}

	this.restoreChecked =
	function _restoreChecked(){
		//return;
		var i, key;
		for(i = 0; i < this.activeList.options.length; i++){
			key = "_" + this.activeList.options[i].value;
			if(this.activeList.checkedValues[key]){
				//alert('key = ' + key + ', pos = ' + i);
				//alert('ch_not = ' + this.activeList.checkedValues[key].checked_not);
				this.activeList.checkOption(i, this.activeList.checkedValues[key].checked_not);
				if(this.activeList.checkedValues[key].checked_not) this.notCheck.checked = true;
			}
		}
	}

	this.refresh =
	function _refresh(){
		this.load(_SPR_LOAD_REFRESH);
	}

	// keyup - used for 'on the fly search' when user press keys in the spr.search field
	// note: used onkeyup, because onkeypress fires before key actually written in the field
	this.keyup =
	function _keyup(obj){
		if(obj.id == this.search.id)
			if(window.event.keyCode != _KEY_CODE_UP && window.event.keyCode != _KEY_CODE_DOWN &&
				window.event.keyCode != _KEY_CODE_PAGEUP && window.event.keyCode != _KEY_CODE_PAGEDOWN)
				_spr.setPosition(_spr.search.value);
	}

	// keydown - used for processing user keys iside spr window
	this.keydown =
	function _keydown(obj){
		switch (window.event.keyCode)
		{
			case _KEY_CODE_SPACE: {
				if(obj.id == this.oper[1].id || obj.id == this.oper[0].id){
					obj.checked = true;
					window.event.returnValue = false;
				}
			}break;
			case _KEY_CODE_TAB: {
				if(obj.id != "_spr_control_div_" + this.nomer)
					this.cycleTabPosition(obj);
				window.event.returnValue = false;
			}break;
			case _KEY_CODE_ENTER:{
				if(obj.id == this.activeList.id){
					if(window.event.ctrlKey){
						window.event.returnValue = false;
						window.event.cancelBuble = true;
						this.refresh();
					}else{
						if(this.activeList.selectedIndex >= 0){
							this.activeList.checkOption(this.activeList.selectedIndex);
							this.choose();
							window.event.returnValue = false;
						}
					}
				}
				if(obj.id == this.oper[0].id || obj.id == this.oper[1].id){
					this.choose();
					window.event.returnValue = false;
				}
				if(obj.id == this.search.id){
					if(window.event.ctrlKey){
						window.event.returnValue = false;
						window.event.cancelBuble = true;
						this.refresh();
					}
					else
						if(this.activeList.selectedIndex >= 0){
							this.activeList.checkOption(this.activeList.selectedIndex);
							this.choose();
							window.event.returnValue = false;
						}
				}
			} break;
			case _KEY_CODE_ESC:{
				this.hide();
				this.textField.focus();
				window.event.returnValue = false;
			} break;
			case _KEY_CODE_DOWN:{
				if(obj.id == this.search.id){
				// route 'down arrow' key from spr.search to spr.activeList
					//_debug("key-down from search!");
					this.activeList.keydown();
					window.event.returnValue = false;
				}
			} break;
			case _KEY_CODE_UP:{
				if(obj.id == this.search.id){
				// route 'up arrow' key from spr.search to spr.activeList
					//_debug("key-up from search!");
					this.activeList.keydown();
					window.event.returnValue = false;
				}
			} break;
			case _KEY_CODE_PAGEDOWN:{
				if(obj.id == this.search.id){
				// route 'PageDown' key from spr.search to spr.activeList
					//_debug("page-down from search!");
					this.activeList.keydown();
					window.event.returnValue = false;
				}
			} break;
			case _KEY_CODE_PAGEUP:{
				if(obj.id == this.search.id){
				// route 'PageUp' key from spr.search to spr.activeList
					//_debug("page-up from search!");
					this.activeList.keydown();
					window.event.returnValue = false;
				}
			} break;
		}
	}

	// searchSpr - used for searching in spr when user press alphanumeric keys
	// in the spr.search field
	// returns found select control option index
	this.searchSpr =
	function searchSpr(filter){
		var i, re, vFilter;
		var position = 0;

		vFilter = filter;
		re = /([\?\*\.\+\$\^\(\)\[\]\{\}])/g;
		vFilter = vFilter.replace(re, "\\$1");
		re = new RegExp("^" + vFilter + ".*", "i");
		if(filter != ""){
			for(i = 0; i < this.activeList.options.length; i++){
				if(this.activeList.options[i].style.display == "none") continue;
				if(re.test(this.activeList.getOptionText(i))){
					position = i;
					break;
				}
			}
		}
		return position;
	}

	// setPosition - set selected index in the select control accordingly
	// to the given filter
	this.setPosition =
	function _setPosition(filter){
		var pos = this.searchSpr(filter);
		_debug("setPosition(): " + pos);
		this.activeList.highliteOption(this.searchSpr(filter));
	}

	/*-------------------------------------
	functions for various textField actions
	--------------------------------------*/

	// onFieldBlur - when text field loses focus
	// used for decoding
	this.onFieldBlur =
	function _onFieldBlur(obj){
		// note: decode only when decoding is allowed (!obj.nodecode) so that
		// do not decoding while opening spr window
		if(!obj.nodecode && _trim(obj.value) != ""){
			// get codeField
			var codeField = this.getCodeField(obj);
			// decode itself
			this.decode(obj, codeField);
		}
	}

	// onFieldKeyDown - when user press a key on text field
	// used for open spr on 'down arrow' key
	this.onFieldKeydown =
	function _onFieldKeydown(obj){
		switch (window.event.keyCode)
		{
			case _KEY_CODE_DOWN: {
				this.open(this.getCodeField(obj));
			}break;
			case _KEY_CODE_F9: {
				this.open(this.getCodeField(obj));
			}break;
			/*
			case _KEY_CODE_TAB: {
				if(!obj.nodecode && _trim(obj.value) != ""){
					// get codeField
					var codeField = this.getCodeField(obj);
					// decode itself
					this.decode(obj, codeField);
				}
			}break;
			*/
		}
	}

	// onFieldChange - when text field content changes, fires only after field loses focus
	// used for cleaning corresponding codeField & clear slaveField if any
	this.onFieldChange =
	function _onFieldChange(obj){

		var codeField = this.getCodeField(obj);
		//clear corresponding codeField if value was deleted
		if(obj.value == ""){
			codeField.value = "";
			if(codeField.driver == '1') _drive(codeField);
		}
		obj.decoded = 0;
		obj.title = '';
		// clear slave field if any
		this._clearSlaveField(codeField);
	}

	// decode - used for decoding integer values to text values from spr
	this.decode =
	function _decode(field, codeField){

			if(codeField.klass_type == 8) return; // no decode for klass_type=8, just dictionary

			var sprNomer	= codeField.spr;
			var value		= "";
			var codeGroup	= "";
			var code		= "";
			var comma_re	= /\,/gi;
			var f_value;
			var responseXML;
			var masterValue, i;

			var separator	= '|';
			var inp_values, out_codes, out_values;
			var spr_items	= new Array();
			var all_decoded = true;
			var wrong_value_pos;
			var prefix		= ''; // indicate `^` or `=` leading symbols

			if(codeField.mfs && _trim(_spr.getMasterValue(codeField).replace(comma_re, '')) == "" && !codeField.fill_1_mode){
				alert("$res:form.spr.message.nofirstlevel$");
				codeField.value = "";
				codeField.group = "";
				field.value = "";
				field.focus();
				return;
			}

			masterValue = '';
			if(codeField.mfs){
				masterValue = _spr.getMasterValue(codeField);
				if(masterValue != ""){
					// we do not need codeGroup(aka field_main_value) for klass_type = 6
					if(codeField.klass_type != '6') codeGroup = masterValue;
				}
				for(i = 0; i < codeField.mfs.length; i++){
//					_debug('decode: set slave for ' + codeField.mfs[i].aname);
//					codeField.mfs[i].slaveCodeField = codeField; // old syntax - now use slave_fields array
					this.register_slave(codeField.mfs[i], codeField);
				}
			}

			// in case of two or more values and empty last, add trailing `,` so that do not loose last empty value
			// needed by klasscode
			if(masterValue != '' && masterValue.substr(masterValue.length - 1, 1) == ',') masterValue += ',';

			f_value = field.value;
			if(f_value.indexOf('&')!= -1) separator = '&';
			// remove prefix if any and remeber it
			if(f_value.substr(0, 1) == '^' || f_value.substr(0, 1) == '='){
				prefix = f_value.substr(0, 1);
				f_value = f_value.substr(1);
			}

			if(field.decoded != 1 && field.decoded != undefined){
				// try to get value locally

				out_codes	= '';
				out_values	= '';
				// fill the input values array and try to decode them locally
				inp_values = f_value.split(separator);
				for(i = 0; i < inp_values.length; i++){
					_debug('inp: ' + inp_values[i]);
					var spr_item = new Object();
					spr_item.inp = inp_values[i];
					spr_item.code = '';
					spr_item.text = '';

					value = _spr.getValueByCode(sprNomer, inp_values[i], codeGroup, true);
					_debug('out: ' + value);
					if(value != ""){
						spr_item.code = inp_values[i];
						spr_item.text = value;
					}else{
						all_decoded = false;
					}
					spr_items.push(spr_item);
				}


/*
				value = _spr.getValueByCode(sprNomer, f_value, codeGroup, true);
				if(value != ""){
					codeField.value = field.value;
					codeField.group = codeGroup;
					field.value = value;
					field.title = value;
					field.decoded = 1;
				}
*/

				if(!all_decoded){
					// if not all input values has been decoded locally, try to decode them on server
					_debug('try to decode via server');
					all_decoded = true;
					var f_values = '';
					for(i = 0; i < spr_items.length; i++){
						if(spr_items[i].code == ''){
							//if(f_values!='') f_values += separator;
							f_values += spr_items[i].inp + separator;
						}
					}
					// remove trailing separator
					f_values = f_values.substr(0, f_values.length-1);

					top.status = "$res:form.spr.message.decode$";
					_debug('f_values: ' + f_values);
					//try{ responseXML = _spr.decode_spr(thisFrm.formname, codeField.bname, codeField.aname, f_values, codeGroup); }
					var form_name = thisFrm.formname;
					if(thisFrm.base_form) form_name = thisFrm.base_form;
					try{ responseXML = _spr.decode_spr(form_name, codeField.bname, codeField.aname, f_values, masterValue); }
					catch(e) { alert_e(e, 'spr.decode'); return; }

					if(responseXML.selectSingleNode("/root/data")){
						_debug('parsing data');
						//alert(responseXML.xml);
						var j = 0;
						var xitems = responseXML.selectSingleNode("/root/data").childNodes;
						for(i = 0; i < spr_items.length; i++){
							if(spr_items[i].code == ''){
								_debug('j = ' + j);
								if(xitems[j].selectSingleNode('code').firstChild)
									spr_items[i].code = xitems[j].selectSingleNode('code').firstChild.nodeValue;
								if(xitems[j].selectSingleNode('text').firstChild)
									spr_items[i].text = xitems[j].selectSingleNode('text').firstChild.nodeValue;
								_debug('j done');
								j++;
							}
						}
					}

					// check one more time whether we decoded all input values
					for(i = 0; i < spr_items.length; i++){
						if(spr_items[i].code == ''){
							all_decoded = false;
							wrong_value_pos = i;
							break;
						}
					}
					top.status = "";
				}


				if(all_decoded){
					// if all input values has been decoded (locally or/and on server),
					// cpncatenate them with separator and exit
					_debug('finally all decoded');
					codeField.group = codeGroup;
					field.decoded = 1;

					for(i = 0; i < spr_items.length; i++){
						if(out_codes!='') out_codes += separator;
						out_codes += spr_items[i].code;
						if(out_values!='') out_values += separator;
						out_values += spr_items[i].text;
					}

					out_codes = prefix + out_codes;
					out_values = prefix + out_values;
					codeField.value = out_codes;
					_debug('out_codes: ' + out_codes);
					_debug('out_values: ' + out_values);
					field.value = out_values;
//					field.title = _spr.get_hint_text(out_values, separator);
					field.title = _get_hint_text(out_values, separator);
				}else{
					// if some/all values has not been decoded, generate error message
					// and highlite 1st wrong input value
					_spr_decode_error = true;
					alert('$res:form.spr.notdecoded$');
					var range = field.createTextRange();
					var range_start_pos = 0;
					for(i = 0; i < wrong_value_pos; i++){
						range_start_pos += spr_items[i].inp.length + 1;
					}
					if(prefix != '') range_start_pos++;

					range.moveStart('character' , range_start_pos);
					range.moveEnd('character' , -(field.value.length - (range_start_pos + spr_items[wrong_value_pos].inp.length)));
					range.select();

					codeField.value = "";
					codeField.group = "";
					//field.value = "";
					field.title = '';
					field.focus();
				}



/*
				// if no, try to get it from server
				if(value == ""){
					//var str = "";
					//str += "[" + thisFrm.formname + "]\n";
					//str += "[" + codeField.bname + "]\n";
					//str += "[" + codeField.aname + "]\n";
					//str += "[" + field.value + "]\n";
					//str += "[" + codeGroup + "]\n";
					//alert(str);


					field.decoded = 1;
					top.status = "$res:form.spr.message.decode$";
					try{ responseXML = _spr.decode_spr(thisFrm.formname, codeField.bname, codeField.aname, f_value, codeGroup); }
					catch(e) { alert_e(e, 'spr.decode'); return; }
					if(responseXML.selectSingleNode("/root/data/text").firstChild){

						value	= responseXML.selectSingleNode("/root/data/text").firstChild.nodeValue;
						code	= responseXML.selectSingleNode("/root/data/code").firstChild.nodeValue;
						//alert(code + ', ' + value);
						//codeField.value = field.value;
						codeField.value = code;
						codeField.group = codeGroup;
						field.value = value;
						field.title = value;

					}else{
						_spr_decode_error = true;
						alert('$res:form.spr.notdecoded$');
						codeField.value = "";
						codeField.group = "";
						field.value = "";
						field.title = '';
						field.focus();
					}
					top.status = "";
				}

*/

				if(codeField.driver == '1') _drive(codeField);
				this._clearSlaveField(codeField);
			}
	}


	// getValueByCode - return text value for given code from given spr
	this.getValueByCode =
	function _getValueByCode(sprNomer, code, codeGroup, searchAll){
		var value = "";
		if(code == "") return ""; // do not search for empty code!
		var i;
		var v_search_all = searchAll;
		if(v_search_all == undefined) v_search_all = false;

		var _spr_control_select = document.all["_spr_control_select_" + sprNomer];
		if(!_spr_control_select.ds)
			_spr_control_select.ds = new dSelect(_spr_control_select);
		var activeList = _spr_control_select.ds;

		_debug("getValueByCode, group is [" + codeGroup + "]");
		for(i = 0; i < activeList.options.length; i++){
			if(activeList.options[i].style.display == "none" && !v_search_all) continue;
			if(activeList.options[i].value == code
				&& (/*!codeGroup ||*/ activeList.options[i].group == codeGroup)){
				_debug("found: [" + activeList.options[i].value + "], [" + activeList.options[i].group + "]");
				value = activeList.getOptionText(i);
				break;
			}
		}
		return value;
	}

	// not used since we now use mf array - codeField.mfs
	// getMasterCodeField - returns master code field for given code field
	/*
	this.getMasterCodeField =
	function _getMasterCodeField(codeField){
		var masterCodeField = undefined;
		if(codeField.masterField)
			masterCodeField = document.all[codeField.masterField];
		// return no-mastercodefield if it is radio button

		if(masterCodeField && masterCodeField.length){
			masterCodeField = undefined;
			alert("$res:error.radio-spr-1st-level$");
			throw "radio-spr-1st-level";
		}
		return masterCodeField;
	}
	*/

	// getCodeField - returns code field for given text field
	this.getCodeField =
	function _getCodeField(textField){
		var re = /^x_/;
		var codeField = document.all[textField.id.replace(re, "")];
		return codeField;
	}

	// getTextField - returns text field for given code field
	this.getTextField =
	function _getTextField(codeField){
		var textField = document.all["x_" + codeField.id];
		return textField;
	}

	// cycleTabPosition - used for walking between spr controls when
	// user press TAB key in opened spr
	this.cycleTabPosition =
	function _cycleTabPosition(obj){
		var nextElement = this.getNextTabElement(obj);
		// remove focus from spr-select - does not work! damn!
		//alert("obj.tagName = " + obj.tagName);
		if(obj.tagName == "DIV"){
			//alert("from srp-select");
			obj.className = "spr-select";
		}
		// set focus
		if(nextElement.tagName == "DIV"){
			// for spr-select div
			nextElement.setActive();
			nextElement.className = "spr-select-focused";
		}
		else // for any other
			nextElement.focus();
	}

	// getNextTabElement - used in cyclyTabPosition, returns next tab element
	// in spr controls set
	this.getNextTabElement =
	function _getNextTabElement(obj){
		var element = null;
		var i;
		var incrementBy			= 1;
		var boundIndex			= this.tabElements.length - 1;
		var boundMoveToIndex	= 0;
		if(window.event.shiftKey){
			incrementBy			= -1;
			boundIndex			= 0;
			boundMoveToIndex	= this.tabElements.length - 1;
		}
		for (i = 0; i < this.tabElements.length; i++){
			if(this.tabElements[i].id == obj.id){
				if(i == boundIndex){
					element = this.tabElements[boundMoveToIndex];
				}else{
					element = this.tabElements[i + incrementBy];
				}
				break;
			}
		}
		if(element.disabled)
			element = this.getNextTabElement(element);
		return element;
	}

	this.getMultiSeparator =
	function _getMultiSeparator(){
		if (this.oper[0].checked)
			return "|";
		else
			return "&";
	}

	// choose
	// used when user chooses some item from the spr
	this.choose =
	function _choose()
	{
		// if checkAll is checked - just set * as value and return
		if(this.checkAll.checked){
			this.textField.value	= '*';
			this.codeField.value	= '*';
			this.codeField.group	= '';
			this.textField.focus();
			this.textField.decoded = 1;
			this.hide();
			// clear salve field if any
			this._clearSlaveField(this.codeField);
			return;
		}

		var i;
		var selectedValue	= "";
		var selectedText	= "";
		var selectedGroup	= "";
		var selectedIndex	= -1;
		var multiSeparator	= "|";
		var restoredMasterText	= "";
		var checked_not		= false;
		var key;
		var responseXML;
		var sep_re		= /\|/gi;

		multiSeparator = this.getMultiSeparator();
		for(key in this.activeList.checkedValues){

				if(this.activeList.checkedValues[key].checked_not)
					checked_not = true;

				if(selectedValue != "")
					if(checked_not){
						selectedValue += "&";
					}else
						selectedValue += multiSeparator;


				selectedValue += this.activeList.checkedValues[key].value;

				if(selectedText != '')
					if(checked_not){
						selectedText += "&";
					}
					else
						selectedText += multiSeparator;

			selectedText += this.activeList.checkedValues[key].text;
			selectedGroup	= this.activeList.checkedValues[key].group;
		}

		if(checked_not){
			selectedText	= "^" + selectedText;
			selectedValue	= "^" + selectedValue.replace(sep_re, "&");

		}

		if(this.iestadeCheck.checked && selectedValue!=""){
			selectedText	= "=" + selectedText;
			selectedValue	= "=" + selectedValue;
		}

		this.textField.value	= selectedText;
		this.textField.title	= '';

		// set textField hint
		if(selectedText != ''){
			var sText = selectedText;
//			this.textField.title = this.get_hint_text(sText, multiSeparator);
			this.textField.title = _get_hint_text(sText, multiSeparator);
		}
		// note: now we do not put selectedText into ltxt so that use selected value as like condition for next open
		//if(selectedText != "")
		//	this.ds.ltxt			= selectedText; // put new lov_txt value in order to do not reload
												// spr content because value is already in the list

		this.codeField.value	= selectedValue;

		_debug('choose: codes selected: ' + selectedValue);
		this.codeField.group	= selectedGroup;
		this.textField.focus();
		this.textField.decoded = 1;
		this.hide();

		// "restore" master field value (works only for single-master mode, not for ADDRES - klass_type=6)
		// also does not work for 1st level radio-spr (check for this.codeField.mfs[0].length)
		if(selectedValue != ""){
			if(this.codeField.mfs){
				// set slaveCodeField for given codeField in order to be
				// able to clearSlave whenever master is changed
				var k;
				for (k = 0; k < this.codeField.mfs.length; k++){
					if(!this.codeField.mfs[k].length){
//						_debug('choose: set slave for ' + this.codeField.mfs[k].aname);
//						this.codeField.mfs[k].slaveCodeField = this.codeField; // old syntax - now use slave_fields array
						this.register_slave(this.codeField.mfs[k], this.codeField);
					}else{
						// set slaveCodeField for each radio-spr option
						// so that be able to clearSlaveField from any option (onclick)
						var mf = this.codeField.mfs[k];
						for(i = 0; i < mf.length; i++){
//							mf[i].slaveCodeField = this.codeField; // old syntax - now use slave_fields array
							this.register_slave(mf[i], this.codeField);
						}
					}
				}

				if(!this.codeField.mfs[0].length && this.codeField.klass_type != '6'){
					// note: avoid this operation for 1st level radio-spr and klass_type = 6

					// set master field with appropriate value if it does not correspond
					//if(this.codeField.mfs[0].value != selectedGroup){
					if(this.codeField.mfs[0].value == ''){
						_debug('set master field: m=[' + this.codeField.mfs[0].value + '], selGr=['+ selectedGroup +']');
						restoredMasterText = this.getValueByCode(this.codeField.mfs[0].spr, selectedGroup, false, true);
						_debug('restored text=[' + restoredMasterText +']');
						if(restoredMasterText == ""){
							top.status = "$res:form.spr.message.decode$";
							var form_name = thisFrm.formname;
							if(thisFrm.base_form) form_name = thisFrm.base_form;
							try{ responseXML = this.get_1stlevel(form_name, this.codeField.mfs[0].bname, this.codeField.mfs[0].aname, selectedGroup);}
							catch(e){ alert_e(e, 'spr.choose'); return; }
							restoredMasterText = "";
							if(responseXML.selectSingleNode("/root/data").firstChild){
								restoredMasterText = responseXML.selectSingleNode("/root/data").firstChild.nodeValue;
							}
							top.status = "";
						}
						// restore, only if we can find master value text in prev level spr !!!
						if(restoredMasterText != ""){
							this.codeField.mfs[0].value = selectedGroup;
							this.getTextField(this.codeField.mfs[0]).value = restoredMasterText;
						}
					}
				}

			}

		}
		// clear salve field if any
		this._clearSlaveField(this.codeField);

		if(this.codeField.driver == '1') _drive(this.codeField);
	}


/*
	this.get_hint_text =
	function _get_hint_text(sText, multiSeparator){

			var hint_max_values = this.hint_max_values;
			var hintText = '';

			if(sText.substr(0, 1) == '='){
				hintText += "$res:form.spr.iestade_check$:\n";
				sText = sText.substr(1);
			}

			if(sText.substr(0, 1) == '^'){
				hintText += "$res:form.spr.not$:\n";
				sText = sText.substr(1);
			}
			var val_ar = sText.split(multiSeparator);
			var h;
			for(h = 0; h < val_ar.length && h < hint_max_values; h++){
				hintText += val_ar[h];
				if(h != val_ar.length - 1 && h != hint_max_values - 1) hintText += "\n";
			}
			if(val_ar.length > hint_max_values)
				hintText += "\n...";

			return hintText;
	}
*/


	this.register_slave =
	function _spr_register_slave(master, slave){
		// if no slave-fields defined, create array, add provided slave and return;
		if(!master.slave_fields){
			master.slave_fields = new Array();
			master.slave_fields.push(slave);
			return;
		}
		// if slave-fields array exists, find slave with given ID and return if found
		var i;
		for(i = 0; i < master.slave_fields.length; i++){
			if(master.slave_fields[i].id == slave.id) return;
		}
		// if slave-fields array exixts, but we have not found provided slave, add it
		master.slave_fields.push(slave);
	}

	// clearSaveField
	// clear slave field (if any) when master field contents changes
	// to some other group than slave field current group
/*	// old version - now use version with slave_fields array
	this._clearSlaveField =
	function _clearSlaveField(codeField, force){
		if(force == undefined) force = false;
		if(codeField.slaveCodeField){
			_debug('_clear: slave = ' + codeField.slaveCodeField.aname + ', group = ' + codeField.slaveCodeField.group + ', value = ' + codeField.value);
			if((codeField.slaveCodeField.group != codeField.value) || force || codeField.slaveCodeField.klass_type == '6'){
				// note: for klass_type = 6 always clear slave-field, because we do not know their group (it depends on more than one field)
				codeField.slaveCodeField.value = "";
				this.getTextField(codeField.slaveCodeField).value = "";
			}
			this._clearSlaveField(codeField.slaveCodeField);
		}
	}
*/
	this._clearSlaveField =
	function _clearSlaveField(codeField, force){
		if(force == undefined) force = false;
		if(codeField.slave_fields){
			var i, sf;
			for(i = 0; i < codeField.slave_fields.length; i++){
				sf = codeField.slave_fields[i];
//				_debug('_clear: slave = ' + sf.aname + ', group = ' + sf.group + ', value = ' + codeField.value);
				if((sf.group != codeField.value) || force || sf.klass_type == '6'){
					// note: for klass_type = 6 always clear slave-field, because we do not know their group (it depends on more than one field)
					sf.value = "";
					this.getTextField(sf).value = "";
					if(sf.driver == '1') _drive(sf);
				}
				this._clearSlaveField(sf);
			}
		}
	}

	this.show =
	function _show(){
		// hide date-period selects if any
		if(document.all.date_period_table)
			_showSelects(document.all.date_period_table, 'hidden');
		_showObject(this.div);
		this.search.focus();
	}

	this.move =
	function _move(x, y){
		this.div.style.top = y;
		this.div.style.left = x;
	}

	this.hide =
	function _hide(){
		if(this.div && this.div.style.display != 'none'){
			// show date-period selects if any
			if(document.all.date_period_table)
				_showSelects(document.all.date_period_table, 'visible');

			this.textField.nodecode = 0;
			document.onclick	= this.documentOnClick;
			document.onkeydown	= this.documentOnKeydown;
			_hideObject(this.div);
			// restore content-div scroll-bar
			document.all._content_div_.style.overflowY = "auto";
		}
	}

	this.clear =
	function _clear(list){
		while(list.options.length){
				list.removeChild(list.options[0]);
		}
	}

	// lostFocus - when spr opened, assigned to document.onclick
	// in order to check whether user went to some another field
	// ans spr should be closed
	this.lostFocus =
	function _lostFocus(){
		//alert('lost focus: ' + window.event.keyCode);
		//_opendebug();
		var x = window.event.clientX + document.all._content_div_.scrollLeft;
		var y = window.event.clientY + document.all._content_div_.scrollTop;
		if(document.all._fixed_div_)
			y -= document.all._fixed_div_.offsetHeight;

		//_debug("x = " + x + ", y = " + y);
		//_debug("e.y = " + window.event.y + ", e.offsetY = " + window.event.offsetY);
		//_debug("content.clientTop = " + document.all._content_div_.clientTop);
		var divLeft		= this.div.offsetLeft;
		var divTop		= this.div.offsetTop;
		var divWidth	= this.div.offsetWidth;
		var divHeight	= this.div.offsetHeight;

		//_debug("l = " + divLeft + ", w = " + divWidth + ", t = " + divTop + ", h = " + divHeight);

		if (window.event.srcElement.id != ("b_" + this.codeField.id)){
			if (x < divLeft || x > (divLeft + divWidth)
				|| y < divTop || y > (divTop + divHeight)){
				this.hide();
			}
		}
	}

	// function decode_spr call iis_z_from.decode_spr
	this.decode_spr =
	function _decode_spr(task_name, block_name, field_name, field_value, field_main_value){

		var params;
		var errmsg = "unknow error";

		if(field_value == undefined)		field_value			= "";
		if(field_main_value == undefined)	field_main_value	= "";
		if(thisFrm.form_type.value == 'tree') task_name = 'tree';

		params = "";
		params += "task_name="		+ task_name;
		params += "&block_name="	+ block_name;
		params += "&field_name="	+ field_name;
		params += "&field_value="	+ encodeURIComponent(field_value);
		params += "&field_main_value="	+ encodeURIComponent(field_main_value);

		var response = _http.post("iis_z_form.decode_spr", params);
		//alert("response \n" + response);
		var xml = _http.get_response_xml();
		if(!xml.documentElement){
			myErr = xml.parseError;
			if (myErr.errorCode != 0) {
				errmsg = myErr.reason;
			}
			throw "decode_spr: could not get response XML: " + errmsg + "\nResponse is:\n" + response;
		}
		errnode = xml.selectSingleNode("/root/error");
		if(errnode){
			errmsg = "decode_spr: error occured";
			if(errnode.getAttribute("desc"))
				errmsg += "\ndescription: " + errnode.getAttribute("desc");
			if(errnode.getAttribute("logid"))
				errmsg += "\nlogid: " + errnode.getAttribute("logid");
			throw errmsg;
		}
		return xml;
	}

	// function getspr call iis_z_from.getspr
	this.getspr =
	function _getspr(task_name, block_name, field_name, begin_pos, amount, lov_txt, lov_main_kod, p_all, renderer){
		var params;
		var errmsg = "unknow error";
		var errnode;

		if(begin_pos == undefined)		begin_pos		= "";
		if(amount == undefined)			amount			= "";
		if(lov_txt == undefined)		lov_txt			= "";
		if(lov_main_kod == undefined)	lov_main_kod	= "";
		if(p_all == undefined)			p_all			= "1";
		if(renderer == undefined)		renderer		= "html";

		if(renderer == 'html')
			if(thisFrm.form_type.value == 'tree') task_name = 'tree';

		var xA0 = String.fromCharCode(160);
		var sp = String.fromCharCode(32);
		params = "";
		params += "task_name="		+ task_name;
		params += "&block_name="	+ block_name;
		params += "&field_name="	+ field_name;
		params += "&begin_pos="		+ begin_pos;
		params += "&amount="		+ amount;
		params += "&lov_txt="		+ encodeURIComponent(unicodeReplace(lov_txt, 160, 32));
		params += "&lov_main_kod="	+ encodeURIComponent(lov_main_kod);
		params += "&p_all="			+ p_all;
		params += "&renderer="		+ renderer;

		if(this.noarch.checked) params += "&p_archive_stat=0";

		_debug(params);
		//http://sun:3339/iis/
		var url = 'iis_z_form.getspr';
		if(this.baseurl != '') url = this.baseurl + url;
		var response = _http.post(url, params);
		//alert("response \n" + response);
		var xml = _http.get_response_xml();
		if(!xml.documentElement){
			myErr = xml.parseError;
			if (myErr.errorCode != 0) {
				errmsg = myErr.reason;
			}
			throw "getspr: could not get response XML: " + errmsg + "\nResponse is:\n" + response;
		}
		errnode = xml.selectSingleNode("/root/error");
		if(errnode){
			errmsg = "getspr: error occured";
			if(errnode.getAttribute("desc"))
				errmsg += "\ndescription: " + errnode.getAttribute("desc");
			if(errnode.getAttribute("logid"))
				errmsg += "\nlogid: " + errnode.getAttribute("logid");
			throw errmsg;
		}
		return xml;
	}

	this.get_1stlevel =
	function _get_1stlevel(task, block, field, code){

		var params;
		var errmsg = "unknow error";
		if(thisFrm.form_type.value == 'tree') task = 'tree';

		params = "";
		params += "task_name="		+ task;
		params += "&block_name="	+ block;
		params += "&field_name="	+ field;
		params += "&kod_gr=" + encodeURIComponent(code);
		//alert(params);
		var response = _http.post("iis_z_form.get_1stlevel", params);
		//alert("response \n" + response);
		var xml = _http.get_response_xml();
		if(!xml.documentElement){
			myErr = xml.parseError;
			if (myErr.errorCode != 0) {
				errmsg = myErr.reason;
			}
			throw "get_1stlevel: could not get response XML: " + errmsg + "\nResponse is:\n" + response;
		}
		errnode = xml.selectSingleNode("/root/error");
		if(errnode){
			errmsg = "get_1stlevel: error occured";
			if(errnode.getAttribute("desc"))
				errmsg += "\ndescription: " + errnode.getAttribute("desc");
			if(errnode.getAttribute("logid"))
				errmsg += "\nlogid: " + errnode.getAttribute("logid");
			throw errmsg;
		}
		return xml;
	}

	this.getLevel =
	function _getLevel(obj, kod){
		var responseXML, optHTML;
		var data_re = /\<\/*data\>/gi; // for removing <data> and </data> tags from data node XML
		var t_level;		// used for generating options padding
		var t_grid = 0;		// used for drawing grid - not worked properly!
		var loaded_count = 0;
		var option		= obj.parentNode;
		var container	= option.parentNode;
		var task_name = thisFrm.formname;
		if(thisFrm.base_form) task_name = thisFrm.base_form;

		if(thisFrm.form_type.value == 'tree') task_name = 'tree';

		//alert("getLevel: " + obj.tagName + ", " + kod);

		//save select div X-size so that be able to restore after opening the level
		var w = this.ds.offsetWidth;
		//alert('w: ' + w);
		_spr.ds.ds.highliteOption(option.pos);
		if(!obj.loaded){
			top.status = "$res:form.spr.message.load$";
			if(container.t_level == undefined) container.t_level = 0;
			t_level = parseInt(container.t_level, 10);
			t_grid = 0;
			if(option.nextSibling) t_grid = 1;
			//_http.baseurl = "http://sun:3339/iis/";
			try{
			responseXML = _spr.getspr(task_name, _spr.codeField.bname, _spr.codeField.aname, t_grid, t_level + 1, '', kod, 1);
			}catch(e){ alert_e(e, 'spr.getLevel'); return; }

			//optHTML = unescapeXML(responseXML.selectSingleNode("/root/data").xml.replace(data_re, ""));
			loaded_count = responseXML.selectSingleNode("/root/data").childNodes.length;
			optHTML = responseXML.selectSingleNode("/root/data").xml.replace(data_re, "");
			if(_trim(optHTML) != ""){
				optHTML = "<div class='dsc' style='width:100%'>\n" + optHTML + "\n</div>";
				//alert("adding: [" + optHTML + "]");
				option.insertAdjacentHTML("afterEnd", optHTML);
				// set level for newly created container
				option.nextSibling.t_level = t_level + 1;
				obj.innerText = "-";
				obj.loaded = true;

				// 29.04.2008:greg: don't so this(`cut-paste..`), because in IE7 it causes that all content of SPR scrolls to the top position
				/*
				// cut-paste whole ds.innerHTML in order to re-parse and get higher performance
				var iHTML = _spr.ds.innerHTML;
				_spr.ds.innerHTML = '';
				_spr.ds.innerHTML = iHTML;
				*/

				_spr.ds.ds.init(_spr.ds);
//------------------------------------------
//				_debug('set div width to 50');
//				_spr.div.style.width = 50;
//------------------------------------------
				// increase selectedIndex to loaded_count if selectedIndex was below the option we have loaded
				//if(_spr.ds.ds.selectedIndex > option.pos)
				//	_spr.ds.ds.selectedIndex += loaded_count;
			}else{
				obj.innerHTML = "&#186;";
				obj.onclick = null;
			}
			top.status = "";
		}else{
			//alert("loaded, empty = " + obj.empty);
			if(obj.innerText == "+"){
				_showObject(obj.parentNode.nextSibling);
				obj.innerText = "-";
			}
			else{
				_hideObject(obj.parentNode.nextSibling);
				obj.innerText = "+";
			}
		}

		//restore select div X-size so that do not out of view in case of long spr values
		this.ds.style.width = this.ds.w;
		this.render();
	}

	this.render =
	function _cspr_render(){
		var i;
		var maxW = 0;
		// set all options 100% width and see which has max width
		for (i = 0; i < this.ds.ds.options.length; i++){
			this.ds.ds.options[i].style.width = "100%";
			if(this.ds.ds.options[i].offsetWidth > maxW) maxW = this.ds.ds.options[i].offsetWidth;
		}
		// set max width to all options
		for (i = 0; i < this.ds.ds.options.length; i++)
			this.ds.ds.options[i].style.width = maxW;
	}

	this.getMasterValue =
	function _getMasterValue(codeField){
		if(codeField == undefined) codeField = this.codeField;
		var i;
		var mvalue = "";
		if(codeField.mfs){
			for(i = 0; i < codeField.mfs.length; i++){
				// handle 1st level radio-spr
				if(codeField.mfs[i].length && codeField.mfs[i][0].type == 'radio'){
					mvalue += _getCheckValue(codeField.mfs[i]) + ',';
				}else{
					// usual hidden spr-field
					mvalue += codeField.mfs[i].value + ',';
				}
			}
			// remove last comma
			if(mvalue != "") mvalue = mvalue.substr(0, mvalue.length - 1);
		}
		return mvalue;
	}
}

function registerMF(obj, src){
	//alert('obj = ' + obj + ', ' + obj.tagName);
	if(!obj.mfs) obj.mfs = new Array();
	obj.mfs.push(src);
}


function getUnicodeString(str){
	var t_str = "";
	var i;
	for(i = 0; i < str.length; i++) t_str += str.charCodeAt(i) + " ";
	return t_str;
}


function unicodeReplace(str, p_what, p_with){
	var t_str = "";
	var i, code;
	for(i = 0; i < str.length; i++){
		code = str.charCodeAt(i);
		if(code == p_what) code = p_with;
		t_str += String.fromCharCode(code);
	}
	return t_str;
}

function FindSprField(button) // :INPUT
{
    //var n = button.previousSibling;
    var n = button.parentNode.parentNode.previousSibling;
    while(n && (n.nodeType != 1 || n.tagName != "INPUT" || n.type != "hidden" || n.spr == undefined))
        n = n.previousSibling;
    return n;
}

function openDigimanSpr(codeField, textField, sprButton){

        var deltaY = 0;
	if(document.all._fixed_div_)
		deltaY = document.all._fixed_div_.offsetHeight;

	dmSpr = dmSprPtr['spr_' + codeField.id];
_debug('spr_' + codeField.id);
	var already_loaded = true;

	if(dmSpr && codeField.spr.substr(codeField.spr.length - 3, 3) == '433'){
		already_loaded = false;
		dmSpr.udata.dv.innerHTML = '';
		dmSpr.udata.master_value = _spr.getMasterValue(codeField);
_debug('mv: ' + dmSpr.udata.master_value);
		dm_loadTree(dmSpr.udata.dv, new Array(dmSpr.udata.btn_show, dmSpr.udata.btn_clear, dmSpr.udata.btn_ok), dmSpr);
	}
	if(!dmSpr){
		already_loaded = false;
		// create dialog box
		var fn = function(){ document.all._content_div_.style.overflowY = "auto"; dmSpr = undefined;};
		var spr_height = parseInt(document.all._content_div_.clientHeight * 0.4, 10);

		dmSpr = new Z.UI.Dialog({
			onclose: fn,
			offsetParent: document.all._content_div_,
			centered: false,
			closeByESC: true,
			closeByClick: true,
			excludeClickOn: sprButton,
			offsetParentDeltaY: deltaY,
			bottomPaneSeparator: false,
			modal: false,
			xPos:0, yPos:0, width:300, height:spr_height,
			dragOpacity:70,
			title: '$res:digiman.spr.title$'});

		dmSpr.show();

		dmSprPtr['spr_' + codeField.id] = dmSpr;

		// create DIV that will contain the tree
		var dv = document.createElement('<div id="dm_content" style="text-align:left;overflow:auto;border:1px solid #A2A3A6;width:100%;height:100%;background:white"></div>');
		dmSpr.udata.dv = dv;
		var content = dmSpr.getContent();
		content.style.padding = '3px';
		content.appendChild(dv);

		dv.onselectstart = function() { window.event.returnValue = false; };
		dv.mode = 'all';

/*
		var chk = document.createElement('<input type="checkbox" id="dm_noside"/>');
		var lbl = document.createElement('<label for="dm_noside" class="doc-checkbox"></label>');
		lbl.innerText = 'No side';

		dmSpr.addControl(chk);
		dmSpr.addControl(lbl);
*/

		// create handler functions and buttons
		var fn_show = function(){ dm_switchMode(arguments.callee.dv); }
		fn_show.dv = dv;
                dmSpr.udata.btn_show = dmSpr.addButton('$res:digiman.ctrl.showsel$', fn_show, 'blue');
		dmSpr.udata.btn_show.disabled = 1;

		var fn_clear = function(){ dm_clearTree(arguments.callee.dv); }
		fn_clear.dv = dv;
                dmSpr.udata.btn_clear = dmSpr.addButton('$res:form.spr.clear$', fn_clear, 'blue');
		dmSpr.udata.btn_clear.disabled = 1;

		var fn_ok = function(){ dm_choose(arguments.callee.dv); }
		fn_ok.dv = dv;
                dmSpr.udata.btn_ok = dmSpr.addButton('$res:form.spr.ok$', fn_ok, 'blue');

		// fix div size inside content so that scrolling works.
		// do it after adding controls so that get real dialog window size
		dv.style.height = content.clientHeight;
		dv.style.width = content.clientWidth;

		dmSpr.udata.buttons = new Array(dmSpr.udata.btn_show, dmSpr.udata.btn_clear, dmSpr.udata.btn_ok);
		dmSpr.udata.dv = dv;

_debug('assign fields..');
		dmSpr.udata.textField = textField;
		dmSpr.udata.codeField = codeField;
		dmSpr.udata.sprno = codeField.spr.substr(codeField.spr.length - 3, 3);
		dmSpr.udata.master_value = _spr.getMasterValue(codeField);
_debug('mv: ' + dmSpr.udata.master_value);
		// load tree content
		dm_loadTree(dv, new Array(dmSpr.udata.btn_show, dmSpr.udata.btn_clear, dmSpr.udata.btn_ok), dmSpr);
	}

	dmSpr = dmSprPtr['spr_' + codeField.id];
_debug('c: ' + dmSpr.udata.codeField.id);
_debug('t: ' + dmSpr.udata.textField.id);
_debug('s: ' + dmSpr.udata.sprno);
_debug('al: ' + already_loaded);
	// restore checks. Here only if already loaded, else - in dm_loadTree_handler
	if(already_loaded){
		dm_restore_checks(dmSpr);
	}

	var clientHeight = document.all._content_div_.clientHeight;
	var posLeft = textField.offsetLeft;
	var posTop = textField.offsetTop + textField.offsetHeight - 1;
	dmSpr.show(posLeft, posTop);

	document.all._content_div_.style.overflowY = "hidden";

	// move spr div to the top of the field if spr size more than clientHeight
	// (taking into account scrollTop value)
	if((posTop - document.all._content_div_.scrollTop + dmSpr.getHeight()) > clientHeight){
		posTop = textField.offsetTop - dmSpr.getHeight();
		if(posTop < 0) posTop = 0 + document.all._content_div_.scrollTop;
		dmSpr.show(posLeft, posTop);
	}

	// move srp-div to the left if it's right border out of _content_div_.clientWidth
	if((posLeft + dmSpr.getWidth()) > document.all._content_div_.clientWidth){
		posLeft = posLeft - ((posLeft + dmSpr.getWidth()) - document.all._content_div_.clientWidth);
		if(posLeft < 0) posLeft = 0 + document.all._content_div_.scrollLeft;
		dmSpr.show(posLeft, posTop);
	}
}

function dm_loadTree(dv, buttons, dmSpr){

	var url = 'iis_z_form.get_dm_spr?sprno=' + dmSpr.udata.sprno;
	if(dmSpr.udata.master_value) url += '&mv=' + encodeURIComponent(dmSpr.udata.master_value);
	var fn = function(){ dm_loadTree_handler(arguments.callee.data); };
	fn.data = {http: _http, dv: dv, buttons: buttons, dmSpr: dmSpr};
	var response = _http.post(url, '', true, fn);
}

function dm_loadTree_handler(data){

	if(data.http.request.readyState == 4){
		if(parseInt(data.http.request.status, 10) == 200){
			var xml = data.http.get_response_xml();
			if(!xml.documentElement){
				myErr = xml.parseError;
				if (myErr.errorCode != 0) {
					errmsg = myErr.reason;
				}
				alert("getspr: could not get response XML: " + errmsg);
				return;
			}
			errnode = xml.selectSingleNode("/root/error");
			if(errnode){
				errmsg = "getspr: error occured";
				if(errnode.getAttribute("desc"))
					errmsg += "\ndescription: " + errnode.getAttribute("desc");
				if(errnode.getAttribute("logid"))
					errmsg += "\nlogid: " + errnode.getAttribute("logid");
				alert(errmsg);
				return;
				//throw errmsg;
			}
			var treeData = xml.documentElement.selectSingleNode('data').xml;
			data.dv.innerHTML = dm_buildHTML(xml.documentElement.selectSingleNode('data'), 0);

			data.dmSpr.recalc();
			// restore checks from codeField
			dm_restore_checks(data.dmSpr);
		}else{
			alert('Could not load data. Error: ' + data.http.request.status);
		}
	}
}

function dm_restore_checks(dmSpr){

	var dm_content = dmSpr.getContent().all.dm_content;
//_debug('dm_content: ' + dm_content);
	var dm_checks = dm_content.all.dm_check;
	if(!dm_checks) return;
//_debug('dm_checks: ' + dm_checks.length);
_debug('cv: ' + dmSpr.udata.codeField.value);
	//dmSpr.udata.codeField
	var values = dmSpr.udata.codeField.value.split('&');
	var i, j;
	for(i = 0; i < dm_checks.length; i++){
		// uncheck
		if(dm_checks[i].checked){
			dm_checks[i].checked = false;
			dm_checkClick(dm_checks[i]);
		}
		// check if value found
		for(j = 0; j < values.length; j++){
			if(dm_checks[i].value == values[j] && !dm_checks[i].checked){
				dm_checks[i].checked = true;
				dm_checkClick(dm_checks[i]);
			}
		}
	}
}

function dm_buildHTML(p_node, level){
	var i, n, buf;
	buf = '';
	for(i = 0; i < p_node.childNodes.length; i++){
		n = p_node.childNodes[i];
		buf += '<div class="o" value="" state="0" style="padding-left:' + (level * 20) + 'px;"';
		buf += ' kod="' + n.getAttribute('KOD') + '"';
		buf += ' title="' + n.getAttribute('KOD') + '"';
		buf += '>';
		if(n.getAttribute('IS_MASTER') == '1')
			buf += '<span class="ss" onclick="dm_openNode(this);">+</span>';
		else
			buf += '<span class="ss">&#xA0;</span>';
		buf += '<input type="checkbox" onclick="dm_checkClick(this)" id="dm_check" value="' + n.getAttribute('KOD') + '"/>';
		buf += '<span onclick="this.previousSibling.click();">' + n.getAttribute('TEXT') + '</span></div>';
		if(n.getAttribute('IS_MASTER') == '1'){
			buf += '<div class="dsc" style="width:100%;display:none">';
			buf += dm_buildHTML(n, level + 1);
			buf += '</div>';
		}
	}
	return buf;
}

function dm_openNode(obj){
	if(obj.parentNode.state == '1') { obj.innerText = '+'; _hideObject(obj.parentNode.nextSibling); obj.parentNode.state = '0'; dmSpr.recalc();}
	else{ obj.innerText = '-'; _showObject(obj.parentNode.nextSibling); obj.parentNode.state = '1'; dmSpr.recalc();}
}

function dm_checkClick(obj){
	var container = obj.parentNode.nextSibling;


	// bold parents
	if(obj.parentNode.parentNode.className == 'dsc')
		markBranch(obj.parentNode.parentNode);

	if(container && container.className == 'dsc'){
		dm_enableChilds(!obj.checked, container);
		unmarkBranch(obj.parentNode);
	}

	if(_getCheckValue(dmSpr.getContent().all.dm_check) != ''){
		for(var i = 0; i < dmSpr.udata.buttons.length; i++) _enableObject(dmSpr.udata.buttons[i]);
	}else{
		if(dmSpr.udata.dv.mode == 'all')
			for(var i = 0; i < 2; i++) _disableObject(dmSpr.udata.buttons[i]);
		else
			_disableObject(dmSpr.udata.buttons[1]);
	}

}

function markBranch(container){
	is_selected = false;
	for(var i = 0; i < container.childNodes.length; i++){
		if(container.childNodes[i].childNodes[1].checked){ is_selected = true; break; }
	}
	if(is_selected) markParent(container, 'bold');
	else markParent(container, 'normal');
}

function markParent(container, style){
	container.previousSibling.childNodes[2].style.fontWeight = style;
	if(container.previousSibling.parentNode.className == 'dsc') markParent(container.previousSibling.parentNode, style);
}

function unmarkBranch(n){
	var i;
	if(n.nextSibling && n.nextSibling.className == 'dsc'){
		n.childNodes[2].style.fontWeight = 'normal';
		var container = n.nextSibling;
		for(i = 0; i < container.childNodes.length; i++){
			n = container.childNodes[i];
			if(n.nextSibling && n.nextSibling.className == 'dsc') unmarkBranch(n);
		}
	}
}

function dm_enableChilds(enable, container){
	var i, n;
	// enable|disable childs
	for(i = 0; i < container.childNodes.length; i++){
		n = container.childNodes[i];
		if(n.className == 'dsc') dm_enableChilds(enable, n);
		else{
			if(enable) n.childNodes[1].disabled = false;
			else{
				n.childNodes[1].checked = false;
				n.childNodes[1].disabled = true;
			}
		}
	}
}

function dm_switchMode(dv){
	if(dv.mode == 'all'){
		dm_show(false, dv);
		dv.mode = 'sel';
		dmSpr.udata.buttons[0].value = '$res:digiman.ctrl.showall$';
	}else{
		dm_show(true, dv);
		dv.mode = 'all';
		dmSpr.udata.buttons[0].value = '$res:digiman.ctrl.showsel$';
		if(_getCheckValue(dmSpr.getContent().all.dm_check) == '') _disableObject(dmSpr.udata.buttons[0]);
	}
}

function dm_show(show, container){
	var i, n;
	for(i = 0; i < container.childNodes.length; i++){
		n = container.childNodes[i];
		if(n.className != 'dsc'){
			if(!show && !n.childNodes[1].checked) _hideObject(n);
			else _showObject(n);
		}else{
			dm_show(show, n);
		}
	}
	if(!show){
		var checks = dmSpr.getContent().all.dm_check;
		for(i = 0; i < checks.length; i++){
			if(checks[i].checked) openBranch(checks[i].parentNode);
		}
	}
}

function openBranch(n){
	if(n.parentNode.className == 'dsc'){
		_showObject(n.parentNode);
		_showObject(n.parentNode.previousSibling);
		openBranch(n.parentNode.previousSibling);
	}
}

function dm_clearTree(dv){
	var i, n;
	var container = dv;
	for(i = 0; i < container.childNodes.length; i++){
		n = container.childNodes[i];
		if(n.className == 'dsc') dm_clearTree(n);
		else{
			if(n.nextSibling && n.nextSibling.className == 'dsc') n.childNodes[2].style.fontWeight = 'normal';
			n.childNodes[1].checked = false;
			n.childNodes[1].disabled = false;
		}
	}
	_disableObject(dmSpr.udata.buttons[0]);
	_disableObject(dmSpr.udata.buttons[1]);
	if(dv.mode == 'sel')
		_enableObject(dmSpr.udata.buttons[0]);
}

function dm_choose(dv){
	var re = /,/g;
	if(!dmSpr.getContent().all.dm_check) return;

	var code = _getCheckValue(dmSpr.getContent().all.dm_check).replace(re, "&");
	//alert(code);
	dmSpr.udata.codeField.value = code;
	var str = '';
	var checks = dmSpr.getContent().all.dm_check;
	for(i = 0; i < checks.length; i++) if(checks[i].checked) str += ((str!='')?' & ':'') + checks[i].nextSibling.innerText;
	//alert(str);
	dmSpr.udata.textField.value = str;

	// register as slave in case of any master fields
	if(dmSpr.udata.codeField.mfs){
		var k;
		for (k = 0; k < dmSpr.udata.codeField.mfs.length; k++){
			if(!dmSpr.udata.codeField.mfs[k].length){
				_spr.register_slave(dmSpr.udata.codeField.mfs[k], dmSpr.udata.codeField);
			}else{
				var mf = dmSpr.udata.codeField.mfs[k];
			for(i = 0; i < mf.length; i++){
					_spr.register_slave(mf[i], dmSpr.udata.codeField);
				}
			}
		}
		// set group to not-exists value so that clearSlaveField always clear field
		dmSpr.udata.codeField.group = '$not-exsits$';
	}
	dmSpr.hide();
}

