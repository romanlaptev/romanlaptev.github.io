/*

Usage:
	var table = ZList();
	table.build( xml, "#insert_data");
or	
	var table = ZList();
	var show_log = 1;
	table.build( xml, "#insert_data", show_log );
*/
(function(){
	var ZList = ZList || function(options){

		//обязательный элемент здесь будет автоматически хранится версия
		// из version control
		var _repositoryRevision = "$Rev: 128 $"; 
		var _log = ""; 

		// private variables and functions
		var _init = function(){
		};

		//------------------- html templates
		var table_tpl ="<table class='table table-bordered'><thead><tr class='list-header info'>#thead</tr></thead><tbody>#records</tbody></table>";
		var thead_tpl = "<th>#column_name</th>";
		var record_tpl = "<tr>#columns</tr>";
		var column_tpl = "<td class='list-body' valign='top'>#value</td>";
		var column_rowspan_tpl = "<td class='list-body' valign='top' rowspan='#rowspan'>#value</td>";
		var checkbox_tpl = "<td class='list-body' valign='top'><input value='#value' type='checkbox' name='records_list_check2'></td>";
		var checkbox_rowspan_tpl = "<td class='list-body' valign='top' rowspan='#rowspan'><input value='#value' type='checkbox' name='records_list_check2'></td>";
		var value_tpl = "<a class=list-body-link href='javascript:goRecord(#record_number)'>#value</a>";
		var message_tpl = "#value";
		var css = "<style>.limit-message{color:red;}</style>";
		
		var _build = function(xml, target, show_log){

			var html = css;
			var log_html = "";
			$(target).empty( html );
			
			var exec_start = new Date();
		
			var table_data = ZListLoader(xml);
			if ( typeof table_data == "undefined")
			{
console.log( "error, table_data  == undefined " );
				return;
			}
//console.log( table_data );

			html += table_tpl;
		//---------------------------- form THEAD
			var html_thead = "";
			html_thead += thead_tpl.replace("#column_name", "" );
			html_thead += thead_tpl.replace("#column_name", "#" );
			$(table_data["columns"]).each(function(){
					html_thead += thead_tpl.replace("#column_name", $(this).attr('title') );
				}
			);
			html = html.replace("#thead", html_thead );
			
		//---------------------------- form TBODY
			var html_records = "";
			var num_record = 0;
			$(table_data["records"]).each(function(){
				var num_tr = table_data["records"]["parameters"][num_record]["num_tr"];
				var number = table_data["records"]["parameters"][num_record]["number"];
				
				for ( var num_row = 0; num_row < num_tr; num_row++)
				{
					var html_columns = "";
					if (num_row == 0)
					{
						if (num_tr > 1)
						{
							html_columns += checkbox_rowspan_tpl
							.replace("#value", number )
							.replace("#rowspan", num_tr);
							
							html_columns += column_rowspan_tpl
							.replace("#value", number )
							.replace("#rowspan", num_tr);
						}
						else
						{
							html_columns += checkbox_tpl
							.replace("#value", number );
							
							html_columns += column_tpl
							.replace("#value", number );
						}
					}
	
					var num_rowspan = 1;
					for ( var num_col = 0; num_col < $(this).length; num_col++)
					{
						var f_value = $(this)[num_col][num_row];
						num_rowspan = calc_rowspan( $(this), num_tr );
						if ( typeof f_value != "undefined")
						{
if(typeof f_value === "string")
{
							if(f_value.indexOf("limit-message") !== -1)
							{
								process_limit_message();
							}						
							else
							{
								f_value = value_tpl
								.replace("#record_number", number)
								.replace("#value", f_value);
							}
}//ie fix
							
							if (num_rowspan > 1)
							{
								var test_value = $(this)[num_col][num_row+1];
								if ( typeof test_value == "undefined")
								{
									html_columns += column_rowspan_tpl
									.replace("#value", f_value )
									.replace("#rowspan", num_rowspan);
								}
								else
								{
									html_columns += column_tpl.replace("#value", f_value );
								}
							}
							else
							{
									html_columns += column_tpl.replace("#value", f_value );
							}
						}
						//else
							//html_columns += column_tpl.replace("#value", "1" );

						
					}//end for

					html_records += record_tpl.replace("#columns", html_columns );
				}
				num_record++;
				
				function process_limit_message()
				{
					var f_value_p1 = f_value.substring(0, f_value.indexOf("limit-message"));
					var start_pos = f_value_p1.indexOf("<span class='limit-message'");
					if( start_pos == 0 )
					{
						f_value = message_tpl.replace("#value", f_value);
					}
					else
					{
						f_value = value_tpl
						.replace("#record_number", number)
						.replace("#value", f_value);
					}
					
				}//end process_limit_message()
				
				function calc_rowspan( record, max_rowspan )
				{
//---------------------- remove "undefinded" from table record
					var filterArr = record[num_col].filter(function(e){return e});
					if ( filterArr.length > 0 )
					{
						var num_field_elements = filterArr.length;
					}
					else
						var num_field_elements = record[num_col].length;
						
//---------------------- cansel rowspan
if( !table_data["records"]["parameters"][num_record]["alignment"]["rowspan"][num_col] )
{
	if( record[num_col].length < max_rowspan )
	{
		var num_repeat = max_rowspan - record[num_col].length;
		
		var last_num = record[num_col].length - 1;
if( typeof record[num_col][last_num] == "string" &&
		record[num_col][last_num].indexOf("limit-message") !== -1 )	
{
		var buff = record[num_col][last_num];
		record[num_col][last_num] = "&nbsp;"
		for( var n = 0; n < num_repeat; n++)
		{
			record[num_col].push("&nbsp;");
		}
		record[num_col][max_rowspan -1] = buff;
}
else
{
		for( var n = 0; n < num_repeat; n++)
		{
			record[num_col].push("&nbsp;");
		}
}		

	}
	return;
}
//----------------------
					var num_rowspan = 1;
					
					k = max_rowspan / num_field_elements;
					var index1 = Math.floor(k);
					var index2 = Math.ceil(k);

					var k_shot = k - index1;
					if (k_shot < 0.5  )
					{
						num_rowspan = index1;
						num_last_rowspan = index2;
					}
					else
					{
						num_rowspan = index2;
						num_last_rowspan = index1;
					}

					//correct rowspan
//undefuned elements in table array
					if( table_data["records"][num_record][num_col].length == num_field_elements )
					{
						var rowspan_arr = [];
						var step = num_rowspan;
						var num = 0;
						for (var n = 0; n < record[num_col].length; n++)
						{
							rowspan_arr[num] = record[num_col][n];
							num = num + step;
						}
						table_data["records"][num_record][num_col] = rowspan_arr;
					}	


					//last rowspan
					if ( (num_row / num_rowspan ) +1 == num_field_elements)
					{
						num_rowspan = num_last_rowspan;
					}
					

					return num_rowspan;
				}//end calc_rowspan()

			});
			
			html = html.replace("#records", html_records );
			
			var exec_end = new Date();
			var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
log_html += "<p>Ajax load runtime: " + load_runtime + " sec</p>";
log_html += "Parse runtime: " + runtime_s + " sec, num records: " + num_record;
log_html += "<ul>"+table.log+"</ul>";
			
			if (show_log == 1)
			{
				$(target).append( log_html );
			}
			$(target).append( html );

			
		};//end _build()
		
		// public interfaces
		return{
			revision:_repositoryRevision,
			log:_log,
			build:	function(xml, target, show_log){ 
				return _build(xml, target, show_log); 
			}
		};
	};
	window.ZList = ZList;
})();

//fix ie8 error
if (!window.console){ console = {log: function() {}} };
if (!Array.prototype.filter)
{
  Array.prototype.filter = function(fun /*, thisp */)
  {
    "use strict";

    if (this === void 0 || this === null)
      throw new TypeError();

    var t = Object(this);
    var len = t.length >>> 0;
    if (typeof fun !== "function")
      throw new TypeError();

    var res = [];
    var thisp = arguments[1];
    for (var i = 0; i < len; i++)
    {
      if (i in t)
      {
        var val = t[i]; // in case fun mutates this
        if (fun.call(thisp, val, i, t))
          res.push(val);
      }
    }

    return res;
  };
}
