//alert("loading initspr.js ...");
_push(_initActions, "_spr = new CSpr()");
