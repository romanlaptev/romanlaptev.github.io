/*
Usage:

//INIT 
	var localcache = LocalCache(); //return object or false if no support web-storages
	
//PUT	
	var params = {
		name: obj_key,
		data: obj_content,
		cdate: cdate,
		callback: put_callback //link to callback function - put_callback( key, status, log )
	};
	localcache.cache( params );

	
//GET	
	var params = {
		"name": obj_key, 
		"callback": function( res, status, log ){
console.log("obj_data : ", res );
console.log( status, log );
		} 
	}		
	localcache.get( params );
	
	
//REMOVE	
	var params = {
		name: obj_key,
		"callback": function( status, log ){
console.log( status, log );
		} 
	};
	localcache.remove( params );

	
//GET DATE	
	var params = {
		"name": obj_key, 
		"callback": function( res, status, log ){
console.log( res, status, log );
		} 
	}		
	localcache.get_date( params );
	
	
//CLEAR	
	localcache.clear();
	
*/
(function(){
	var LocalCache = function(){

		//version control
		var _repositoryRevision = "$Rev: 129 $"; 
		
		// private variables and functions
		var _test = function(){
			var test = {};
			
//alert("localStorage = " + typeof( window.localStorage ));
			test["localStorage"] = false;
			if( 'localStorage' in window && window['localStorage'] !== null )
			{
				test["localStorage"] = true;
			} 
			
//alert("WebSQL, openDatabase = " + typeof(openDatabase));
			test["WebSQL"] = false;
			if(window.openDatabase)
			{
				test["WebSQL"] = true;
			}
			
//alert("indexedDB = " + typeof(indexedDB));
			test["indexedDB"] = false;
			if("indexedDB" in window) {
				test["indexedDB"] = true;
			}
			
			return test;
		};//end _test()

		var _init = function(){
			localforage.config({
				driver: [localforage.INDEXEDDB,
						 localforage.WEBSQL,
						 localforage.LOCALSTORAGE],
				name: 'localforage',
				//name: 'webapp-store'
				//driver: [localforage.WEBSQL],
				driver: [localforage.LOCALSTORAGE]
			});
			
			localforage.ready(function() {
//alert('localForage ready');
//console.log('localforage.driver():', localforage.driver());
			});

			localforage.length(function(err, numberOfKeys) {
//console.log('length of the database - ' + numberOfKeys);
//console.dir(err);
			});
			
		};//end _init()
		
		//let's start
		var test = _test();
		if ( !test["localStorage"] &&
				!test["WebSQL"] &&
					!test["indexedDB"])
		{
//console.log( "error, no support web-storages, ", test);
			return false;
		}
		
		_init();
		
		//cache put
		var _cache = function( params ){
		
			//test in array of keys		
			localforage.keys(function(err, keys) {
				var j_keys = keys.join();
				var pos = j_keys.indexOf( params["key"] );
				if( pos >= 0)
				{
					//remove element
					localforage.removeItem( params["key"], function(err) {
//console.log("Remove " + params["key"] );
//console.log("err = ", err);
						var log = "localcache element with key " + params["key"] + " was removed";
//alert(log);						
_debug(log);
						//_put( params );
					});
				}
				_put( params );
			});
			
		};//end _cache()

		function _put( params )
		{
			var key = params["key"];
			var value = {
				"cdate": params["cdate"],
				"data": params["data"]
			};

			localforage.setItem(key, value, function(err, v) {
//console.log('Saved ' + key);
//console.log(err);
//console.log(v);
				var log = 'saved in cache: ' + key;
				var status = true;
				if( err !== null)
				{
//console.log(err.name);		
					if( isQuotaExceeded(err) )
					{
						log = "QuotaExceededError, no save " + key + ", " + err.message;
					}
					else
						log = "error, no save " + key + ", " + err;
					status = false;
				}
				params.callback( key, status, log );	
			});//end add
			
			function isQuotaExceeded(e) {
				var quotaExceeded = false;
				if (e) {
					if (e.code) {
						switch (e.code) {
							case 22://Chrome, IE >= 9
//e.code = 22
//e.name = QuotaExceededError
//e.message = Failed to execute 'setItem' on 'Storage': Setting the value of 'localforage/export_lib4.xml' exceeded the quota.
								quotaExceeded = true;
							break;
							case 1014:// Firefox
//e.code = 1014
//e.message = Persistent storage maximum size reached
//e.name = NS_ERROR_DOM_QUOTA_REACHED
								if (e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
									quotaExceeded = true;
								}
							break;
							}
						} 
						else 
						{
							if (e.number === -2147024882) // Internet Explorer 8
							{
//e.message = ������������ ������ ��� ���������� ��������.
//e.description = ������������ ������ ��� ���������� ��������.
								quotaExceeded = true;
							}
						}
				}
				return quotaExceeded;
			}//end isQuotaExceeded()
			
		}//end _put()
		
		//var _get = function( params ){
		function _get( params ){
			//var exec_start = new Date();
			localforage.keys(function(err, keys) {
				//test in array of keys
				var j_keys = keys.join();
				var pos = j_keys.indexOf( params["key"] );
//alert('_get(), key - ' + params["key"] +", pos - "+ pos);
				if( pos >= 0)
				{
					localforage.getItem( params["key"], function(err, readValue) {
//alert('Read: ' + readValue["data"]);
//console.log('Read: ', readValue);
//console.log(err);
						//var exec_end = new Date();
						//var runtime_s = (exec_end.getTime() - exec_start.getTime()) / 1000;
					
						var cache_size = readValue["data"].length; 
						var cache_size_kb = cache_size / 1024 ;
						//var cache_size_mb = cache_size_kb / 1024;
						var log = "get cache element " + params["key"]+ ", <b>size</b>: "+ cache_size_kb.toFixed(2) +" Kbytes";
						//log += ", <b>runtime</b>: " + runtime_s + " <b>sec</b><br>";
						params.callback( readValue["data"], true, log );	
					 });
				}
				else
				{
					var log = "error, not found " + params["key"] + " in keys";
					params.callback( "", false, log );	
				}
			});
		
		};//end _get
		
		function _get_sync( params ){
			var key = localforage._config.name + "/" + params["key"];
			var jsonString = localStorage.getItem( key );
//alert("jsonString = " +  jsonString);	
			if( jsonString !== null )
			{
				var obj = JSON.parse( jsonString );
				obj.log = "get cache element " + key;
				return obj;
			}
			return false;
			
		};//end _get_sync
		
		var _get_date = function( params ){
		
			localforage.keys(function(err, keys) {
				//test in array of keys
				var j_keys = keys.join();
				var pos = j_keys.indexOf( params["key"] );
				if( pos >= 0)
				{
					localforage.getItem( params["key"], function(err, readValue) {
//console.log('Read: ', readValue);
//console.log(err);
						var log = "cache element with key: " + params["key"] + " was created in " + readValue["cdate"];
						params.callback( readValue["cdate"], true, log );	
					 });
				}
				else
				{
					var readValue={"data":""};
					var log = "error, not found " + params["key"] + " in keys";
					params.callback( readValue["data"], false, log );	
				}
			});
		
		};
		
		var _remove = function( params ){
			localforage.keys(function(err, keys) {
				//test in array of keys
				var j_keys = keys.join();
				var pos = j_keys.indexOf( params["key"] );
				if( pos >= 0)
				{
					localforage.removeItem( params["key"], function(err) {
//console.log("Remove " + params["key"] );
//console.log("err = ", err);
						var log = "cache element with key " + params["key"] + " was removed";
						params.callback( true, log );	
					 });
				}
				else
				{
					var log = "error, not found " + params["key"] + " in keys";
					params.callback( false, log );	
				}
			});
		};
		
		var _clear = function(){
			localforage.clear(function(err) {
//console.log('Clear storage');
//console.dir(err);
			});
		};

		var _get_list = function( params ){
//alert("get cache list!" + params );		
			var out = "";
			out += "<p>localforage.driver(): " + localforage.driver();
			localforage.length(function(err, numberOfKeys) {
				out += '<p>length of the local database - ' + numberOfKeys + '</p>';
				params["html"] = out;
				if( numberOfKeys > 0)
				{
					form_list( params );
				}
				else
				{
					params.callback( out );	
				}
			});

			function form_list( params )
			{
				var html = params.html;
				var cache_size = 0;
				var count = 0;
				localforage.iterate(function(value, key, iterationNumber) {
//console.log(key, value["data"].length + " bytes");
//console.log(key, typeof value);
					count++;
					html += count + ". " +key + ", " + value["data"].length + " bytes, (cdate = "+value["cdate"]+")<br>";
					cache_size = cache_size + value["data"].length; 
				}, function(err) {
					if (!err) {
//console.log('Iteration has completed', err);
//console.log(cache_size + " bytes, ", (cache_size)/1024  + " Mbytes");

						var cache_size_kb = cache_size / 1024 ;
						var cache_size_mb = cache_size_kb / 1024;
						html += cache_size + " bytes, " + cache_size_kb.toFixed(2)  + " Kbytes, <b>" + cache_size_mb.toFixed(2) + " Mbytes</b>";

						//localstorage-list
						html += "<h2>localstorage list</h2>";
						for(var item in localStorage)
						{
							if( typeof localStorage[item] === "function")
							{
								continue;
							}
							html += item + " = " + typeof localStorage[item];
							html += "<br>";
						}
						
						params.callback( html );	
					}
					else
					{
alert(err);				
						html += "<p>localforage.iterate, error: "+err+"</p>";
						params.callback( html );	
					}
				});

			}//end form_list()
			
		};//end _get_list
		
		// public interfaces
		return{
			revision:_repositoryRevision,
			get: function( params ){ 
				return _get( params ); 
			},
			get_sync: function( params ){ 
				return _get_sync( params ); 
			},
			cache: function( params ){ 
				return _cache( params ); 
			},
			get_date: function( params ){ 
				return _get_date( params ); 
			},
			remove: function( params ){ 
				return _remove( params ); 
			},
			clear: function(){ 
				return _clear(); 
			},
			get_list: function( params ){
				return _get_list( params ); 
			}
		};
	};
	
	window.LocalCache = LocalCache;
})();

//fix ie8 
//if (!window.console){ console = {log: function() {}} };
