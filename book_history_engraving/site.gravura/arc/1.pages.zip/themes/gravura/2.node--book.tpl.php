<!-- ======================================= -->
<link rel="stylesheet" href="/pages/js/pirobox/pirobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="/pages/js/pirobox/jquery.min.js"></script>
<script type="text/javascript" src="/pages/js/pirobox/pirobox_ansi.js"></script>
<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery().piroBox({
			my_speed: 300, //animation speed
			bg_alpha: 0.1, //background opacity
			slideShow : false, // true == slideshow on, false == slideshow off
			slideSpeed : 6, //slideshow duration in seconds(3 to 6 Recommended)
			close_all : '.piro_close,.piro_overlay'// add class .piro_overlay(with comma)if you want overlay click close piroBox

	});
});
</script>
<!-- ======================================= -->
<?
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//echo "</pre>";
?>
<style>
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	font-weight:bold;
	color:green;
}
.warning
{
	font-weight:bold;
	color:blue;
}
</style>

<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?>"<?php print $attributes; ?>>

  <?php print $user_picture; ?>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

  <?php if ($display_submitted): ?>
    <span class="submitted"><?php //print $submitted ?></span>
  <?php endif; ?>

<div class="content clearfix"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
?>
<div class="notebook_page">
<table>
	<tbody><tr>
		<td valign="top" class="text_col">
			<div class="text_column">

<!--			<h2>node--book.tpl.php</h2>-->
<!--{TEXT_COLUMN_START}-->
				<p>	
<?
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//print_r($content);
//echo "</pre>";

	//print render($content['body']['#object']->body['und'][0]['value']);
	if (!empty($content['book_navigation']))
	{
		if (isset($content['body']['#object']->book))
		{
			//if ($content['body']['#object']->book['has_children'] == 0)
			if ($content['body']['#object']->book['depth'] == 3)
			{
				//echo $content['book_navigation']['#markup'];
				$temp = $content['book_navigation'];
				$content['book_navigation']="";
//убрать дублирование навигации книги
				print render($content);

				$content['book_navigation']=$temp;
			}
			else
				print render($content);
		}
		else
			print render($content);
	}


?>
<!--{TEXT_COLUMN_END}-->

			</div><!-- end text column -->
		</td>

		<td valign="top">
			<div class="picture_column">
<!--{PICTURE_START}-->
<?php
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//echo "</pre>";
error_reporting(E_ALL);

//if (arg(0) == 'node')
if (!empty($node->field_img1_book['und']))
{
	//$node=node_load(arg(1));
//echo "<pre>";
//print_r($node);
//echo "</pre>";

	global $base_url;

	//base_url для изображений контента, позволяет загружать картинки контента с других сайтов
	//если не указан адрес, то изображения загружаеются из папки контента текущего сайта	
	//$url_content_preview = "http://gravura.ts6.ru";
	//$url_content_medium = "http://gravura.ts6.ru";
	//$url_content_small = "http://gravura.ts6.ru";
	//$url_content_large = "http://gravura.ts6.ru";
	//$url_content_original = "http://gravura.ts6.ru";
	$url_content_preview = "";
	$url_content_medium = "";
	$url_content_small = "";
	$url_content_large = "";
	$url_content_original = "";

	//файловый путь к прикрепленным к ноде изображениям
	$fs_root_src = "/mnt/transcend/0_sites/book_history_engraving";
	$fs_root_src = $fs_root_src."/sites/default/files";

	//файловый путь папки изображений контента
	$fs_root_dest = "/mnt/wd160/documents/0_sites/site_graphics";
/*
	$url_content_preview = $node->field_url_content_preview['und'][0]['value'];
	$url_content_medium = $node->field_url_content_medium['und'][0]['value'];
	$url_content_small = $node->field_url_content_small['und'][0]['value'];
	$url_content_large = $node->field_url_content_large['und'][0]['value'];
	$url_content_original = $node->field_url_content_original['und'][0]['value'];
*/
/*
	$fs_root_src = $node->field_fs_root_src['und'][0]['value'];
	$fs_root_dest = $node->field_fs_root_dest['und'][0]['value'];
*/

/*
	//global $fs_root_src;
	//global $fs_root_dest;
//echo "global_fs_root_src === ".variable_get($gl_fs_root_src);
	$fs_root_src = variable_get($global_fs_root_src);
echo "fs_root_src = ".$fs_root_src;
echo "<br>";
	$fs_root_dest = variable_get($global_fs_root_dest);
echo "fs_root_dest = ".$fs_root_dest;
echo "<br>";
*/
	$out ="";
	if (count($node->field_img1_book['und']>0))
	{
		for ($n1=0;$n1<count($node->field_img1_book['und']);$n1++)
		{
//echo $node->field_img1_book['und'][$n1]['filename'];
//echo "<br>";

//echo $node->field_img1_book['und'][$n1]['title'];
//echo "<br>";
//echo $node->field_img1_book['und'][$n1]['alt'];
//echo "<br>";
//echo $base_url."/sites/default/files/styles/preview_gallery_img/public/img_book/".$filename;
//echo "<br>";

			$filename = trim($node->field_img1_book['und'][$n1]['filename']);
			$title = trim($node->field_img1_book['und'][$n1]['title']);
			$alt = trim($node->field_img1_book['und'][$n1]['alt']);

			//$folder_img = "/content/book_history_engraving/09.Western_european_engraving_19th";
			//$folder_img = $base_url."/sites/default/files/styles";
//-----------------------------------------------------------------------------
			//$preview_gallery_img = $folder_img."/preview_gallery_img/".$filename;
			//$preview_gallery_img = $folder_img."/preview_gallery_img/public/img_book/".$filename;
			$preview_gallery_img = $node->field_preview_gallery_img['und'][0]['value']."/".$filename;
//echo "preview_gallery_img = ".$preview_gallery_img;
//echo "<br>";
			$source_file = $fs_root_src."/styles/preview_gallery_img/public/img_book/".$filename;
			$dest_file = $fs_root_dest.$preview_gallery_img;
			move_img ($source_file, $dest_file); //скопировать изображение ноды в папку контента
//-----------------------------------------------------------------------------
			//$medium_img = $folder_img."/medium/".$filename;
			//$medium_img = $folder_img."/medium/public/img_book/".$filename;
			$medium_img = $node->field_medium_img['und'][0]['value']."/".$filename;

			$source_file = $fs_root_src."/styles/medium/public/img_book/".$filename;
			$dest_file = $fs_root_dest.$medium_img;
			move_img ($source_file, $dest_file); //скопировать изображение ноды в папку контента
//-----------------------------------------------------------------------------
			//$small_img = $folder_img."/small/".$filename;
			//$small_img = $folder_img."/small/public/img_book/".$filename;
			$small_img = $node->field_small_img['und'][0]['value']."/".$filename;
			$source_file = $fs_root_src."/styles/small/public/img_book/".$filename;
			$dest_file = $fs_root_dest.$small_img;
			move_img ($source_file, $dest_file); //скопировать изображение ноды в папку контента
//-----------------------------------------------------------------------------
			//$large_img = $folder_img."/large/".$filename;
			//$large_img = $folder_img."/large/public/img_book/".$filename;
			$large_img = $node->field_large_img['und'][0]['value']."/".$filename;
			$source_file = $fs_root_src."/styles/large/public/img_book/".$filename;
			$dest_file = $fs_root_dest.$large_img;
			move_img ($source_file, $dest_file); //скопировать изображение ноды в папку контента
//-----------------------------------------------------------------------------
			//$original_img = $folder_img."/original/".$filename;
			//$original_img = $folder_img."/original/public/img_book/".$filename;
			$original_img = $node->field_original_img['und'][0]['value']."/".$filename;
			$source_file = $fs_root_src."/img_book/".$filename;
			$dest_file = $fs_root_dest.$original_img;
			move_img ($source_file, $dest_file); //скопировать изображение ноды в папку контента
//-----------------------------------------------------------------------------
			$out.=	"<div class='picture'>";
			//вывод изображения с лайтбоксом и ссылками на другие размеры картинки
/*
			$out .="<a rel='lightbox' title='".$title."' href='".$url_content_medium.$medium_img."'>
<img alt='".$alt."' title='".$title."' src='".$url_content_preview.$preview_gallery_img."'></a>
<span class='resize'>увеличить в 
	<a rel='lightbox' href='".$url_content_small.$small_img."'>2x</a> 
	<a rel='lightbox' href='".$url_content_medium.$medium_img."'>3x</a> 
	<a rel='lightbox' href='".$url_content_large.$large_img."'>4x</a>
	<a href='".$url_content_original.$original_img."' target=_blank>полный размер</a>
</span>
<br>
<p>".$title."</p>";
*/
			$out .="<a class='pirobox' 
title='".$title."' href='".$url_content_medium.$medium_img."'>
<img alt='".$alt."' title='".$title."' src='".$url_content_preview.$preview_gallery_img."'></a>
<span class='resize'>увеличить в 
	<a class='pirobox' href='".$url_content_small.$small_img."'>2x</a> 
	<a class='pirobox' href='".$url_content_medium.$medium_img."'>3x</a> 
	<a class='pirobox' href='".$url_content_large.$large_img."'>4x</a>
	<a href='".$url_content_original.$original_img."' target=_blank>полный размер</a>
</span>
<br>
<p>".$title."</p>";

			$out.=	"</div>";
		}//--------------- end for
echo $out;
	}//---------------------- end if 
}

//----------------------------------------------
//скопировать изображение ноды в папку контента
//----------------------------------------------
function move_img($source_file, $dest_file)
{
	global $out;
			if (!file_exists($dest_file))
			{
				if (file_exists($source_file))
				{
					if (!copy($source_file, $dest_file)) 
					{
$out .= "<span class='error'>Не удалось скопировать </span>".$source_file."<br>";
					}
					else
					{
						$out .= "<span class='ok'>Скопирован </span>";
						$out .= $source_file." >> ".$dest_file."<br>";
					}
				}
			}
			else
			{
				if (file_exists($source_file))
				{
					if (unlink ($source_file))
					{
						$out .= "<span class='ok'>Remove </span>".$source_file;
						$out .= "<br>";
					}
				}
/*
				else
				{
					$out .= "<span class='error'>Dont remove </span>".$source_file;
					$out .= "<br>";
				}
*/
			}
}//------------ end func
?>
				</div>
			</div> <!-- end picture column -->
		</td>

	</tr>
</tbody>
</table>
</div>			<!-- end notebook_page -->
<?
//-------------------------------------------------------------------------
	if (!empty($content['book_navigation']))
	{
		if (isset($content['body']['#object']->book))
		{
			//if ($content['body']['#object']->book['has_children'] == 0)
			if ($content['body']['#object']->book['depth'] == 3)
			{
				echo $content['book_navigation']['#markup'];
			}
		}
	}
//-------------------------------------------------------------------------
?>
</div>

  <div class="clearfix">
    <?php if (!empty($content['links'])): ?>
      <div class="links"><?php print render($content['links']); ?></div>
    <?php endif; ?>

    <?php print render($content['comments']); ?>
  </div>

</div>
