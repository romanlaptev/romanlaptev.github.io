<?php 
global $theme;
//$theme_path = base_path().drupal_get_path('theme',$theme);
$theme_path = drupal_get_path('theme',$theme);

echo <<<EOF
<!-- ======================================= -->
<link rel="stylesheet" href="$theme_path/js/pirobox/pirobox.css" type="text/css" media="screen" />
<script type="text/javascript" src="$theme_path/js/pirobox/jquery.min.js"></script>
<script type="text/javascript" src="$theme_path/js/pirobox/pirobox_ansi.js"></script>
<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery().piroBox({
			my_speed: 300, //animation speed
			bg_alpha: 0.1, //background opacity
			slideShow : false, // true == slideshow on, false == slideshow off
			slideSpeed : 6, //slideshow duration in seconds(3 to 6 Recommended)
			close_all : '.piro_close,.piro_overlay'// add class .piro_overlay(with comma)if you want overlay click close piroBox

	});
});
</script>
<!-- ======================================= -->

EOF;
?>

<?
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//echo "</pre>";
?>
<style>
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	font-weight:bold;
	color:green;
}
.warning
{
	font-weight:bold;
	color:blue;
}
</style>

<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?>"<?php print $attributes; ?>>

  <?php print $user_picture; ?>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

  <?php if ($display_submitted): ?>
    <span class="submitted"><?php //print $submitted ?></span>
  <?php endif; ?>

<div class="content clearfix"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
?>
<div class="notebook_page">
<table>
	<tbody><tr>
		<td valign="top" class="text_col">
			<div class="text_column">

<!--			<h2>node--book.tpl.php</h2>-->
<!--{TEXT_COLUMN_START}-->
				<p>	
<?
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//print_r($content['book_navigation']['#markup']);
//echo "</pre>";

	//print render($content['body']['#object']->body['und'][0]['value']);
	if (!empty($content['book_navigation']))
	{
//======================================
/*
$str = '<a href="/notebook-1.html">Тетрадь I. Вступительные статьи</a>';
     if (preg_match("|href=\"(.*)\">|sei", $str, $arr))
     {
         echo $arr[1];
         echo "<br>";

	$change_href=str_replace(base_path(),"",$arr[1]);
	$content['book_navigation']['#markup'] = str_replace($arr[1],$change_href,$content['book_navigation']['#markup']);
     }
*/

$content['book_navigation']['#markup'] = str_replace(base_path(),"",$content['book_navigation']['#markup']);
$content['book_navigation']['#markup'] = str_replace("<a><li>","</a></li>",$content['book_navigation']['#markup']);
$content['book_navigation']['#markup'] = str_replace("<a>","</a>",$content['book_navigation']['#markup']);
$content['book_navigation']['#markup'] = str_replace("<div>","</div>",$content['book_navigation']['#markup']);

//======================================

		if (isset($content['body']['#object']->book))
		{
			//if ($content['body']['#object']->book['has_children'] == 0)
			if ($content['body']['#object']->book['depth'] == 3)
			{
				//echo $content['book_navigation']['#markup'];
				$temp = $content['book_navigation'];
				$content['book_navigation']="";
//убрать дублирование навигации книги
				print render($content);

				$content['book_navigation']=$temp;
			}
			else
				print render($content);
		}
		else
			print render($content);
	}


?>
<!--{TEXT_COLUMN_END}-->

			</div><!-- end text column -->
		</td>
<!--
</tr>
<tr>
-->
		<td valign="top">
			<div class="picture_column">
<!--{PICTURE_START}-->
<?php
//echo "<pre>";
//print_r($_REQUEST);
//print_r($_SERVER);
//echo "</pre>";
error_reporting(E_ALL);

//if (arg(0) == 'node')
if (!empty($node->field_img1_book['und']))
{
	//$node=node_load(arg(1));
//echo "<pre>";
//print_r($node);
//echo "</pre>";

	global $base_url;

	//base_url для изображений контента, позволяет загружать картинки контента с других сайтов
	//если не указан адрес, то изображения загружаеются из папки контента текущего сайта	

	$url_content_preview = "";
	$url_content_medium = "";
	$url_content_small = "";
	$url_content_large = "";
	$url_content_original = "";
/*
	$url_content_preview = "http://gravura.ts6.ru";
	$url_content_medium = "http://gravura.ts6.ru";
	$url_content_small = "http://gravura.ts6.ru";
	$url_content_large = "http://gravura.ts6.ru";
	$url_content_original = "http://gravura.ts6.ru";
*/
	//файловый путь к прикрепленным к ноде изображениям
	//$fs_root_src = "/mnt/transcend/0_sites/book_history_engraving";
	$fs_root = getcwd();
//echo "fs_root = ".$fs_root;
//echo "<br>";
	$fs_root_src = $fs_root."/sites/default/files";
	$img_subfolder="img_book";

	//файловый путь папки изображений контента
	//$fs_root_dest = "/mnt/wd160/documents/0_sites/site_graphics";
	if (count($node->field_content_location)>0)
	{
		$fs_root_dest = trim($node->field_content_location['und'][0]['value']);
	}
	else
		$fs_root_dest = '/mnt/terra/0_sites/site-content';


	//получить файловый путь к изображениям и иконкам, из текстового поля ноды
	$url_preview = trim($node->field_preview_gallery_img['und'][0]['value']);
	$url_medium = trim($node->field_medium_img['und'][0]['value']);
	$url_small = trim($node->field_small_img['und'][0]['value']);
	$url_large = trim($node->field_large_img['und'][0]['value']);
	$url_original = trim($node->field_original_img['und'][0]['value']);

	$out ="";
	if (count($node->field_img1_book['und']>0))
	{
		for ($n1=0;$n1<count($node->field_img1_book['und']);$n1++)
		{
			$filename = trim($node->field_img1_book['und'][$n1]['filename']);
//echo "filename = ".$filename;
//echo "<br>";
			$title = trim($node->field_img1_book['und'][$n1]['title']);
			$alt = trim($node->field_img1_book['und'][$n1]['alt']);

//=============================================================================
			$preview_img = $url_preview."/".$filename;
//echo "preview_img = ".$preview_img;
//echo "<br>";
			$medium_img = $url_medium."/".$filename;
//echo "medium_img = ".$medium_img;
//echo "<br>";
			$small_img = $url_small."/".$filename;
//echo "small_img = ".$small_img;
//echo "<br>";
			$large_img = $url_large."/".$filename;
//echo "large_img = ".$large_img;
//echo "<br>";

			$original_img = $url_original."/".$filename;
//echo "original_img = ".$original_img;
//echo "<br>";
//------------------- скопировать изображение ноды в папку контента (см. template.php)
			$source_file_original_img = $fs_root_src."/".$img_subfolder."/".$filename;
			$dest_file = $fs_root_dest.$original_img;
		if (file_exists($source_file_original_img))
		{
			$res_copy_original_img = 0;
			$res_copy_original_img = copy_img ($source_file_original_img, $dest_file); 
//=============================================================================
			$source_file_preview_img = $fs_root_src."/styles/preview_gallery_img/public/".$img_subfolder."/".$filename;
			$dest_file = $fs_root_dest.$preview_img;
			if (file_exists($source_file_preview_img))
			{
					// скопировать изображение иконки в папку контента
					$res_copy_preview_img = 0;
					$res_copy_preview_img = copy_img ($source_file_preview_img, $dest_file); 
					if ($res_copy_preview_img == 1)
					{
//echo " res_copy_preview_img = ".$res_copy_preview_img;
//echo "<br>";
						$out .= remove_img($source_file_preview_img); 
					}
			}
			else // создать иконку
			{
					if (!file_exists($dest_file))
					{
						$alt = "";
						$img_title = "";
						$preset_name = 'preview_gallery_img';
						$src_file = $img_subfolder."/".$filename;
						$out .= create_icon ($alt,$img_title,$preset_name,$src_file);
					}
					else
						$remove_preview_img = 1;
			}
//=============================================================================
			$source_file_medium_img = $fs_root_src."/styles/medium/public/".$img_subfolder."/".$filename;
			$dest_file = $fs_root_dest.$medium_img;
			if (file_exists($source_file_medium_img))
			{
					// скопировать изображение ноды в папку контента
					$res_copy_medium_img = 0;
					$res_copy_medium_img = copy_img($source_file_medium_img, $dest_file); 
					if ($res_copy_medium_img == 1)
					{
//echo " res_copy_medium_img = ".$res_copy_medium_img;
//echo "<br>";
						$out .= remove_img($source_file_medium_img); 
					}
			}
			else // создать иконку
			{
//echo "2.medium_img = ".$medium_img;
//echo "<br>";
					if (!file_exists($dest_file))
					{
						$alt = "";
						$img_title = "";
						$preset_name = 'medium';
						$src_file = $img_subfolder."/".$filename;
						$out .= create_icon ($alt,$img_title,$preset_name,$src_file);
					}
					else
						$remove_medium_img = 1;
			}


//=============================================================================
			$source_file_small_img = $fs_root_src."/styles/small/public/".$img_subfolder."/".$filename;
			$dest_file = $fs_root_dest.$small_img;
			if (file_exists($source_file_small_img))
			{
					// скопировать изображение ноды в папку контента
					$res_copy_small_img = 0;
					$res_copy_small_img = copy_img($source_file_small_img, $dest_file); 
					if ($res_copy_small_img == 1)
					{
//echo " res_copy_small_img = ".$res_copy_small_img;
//echo "<br>";
						$out .= remove_img($source_file_small_img); 
					}
			}
			else // создать иконку
			{
					if (!file_exists($dest_file))
					{
						$alt = "";
						$img_title = "";
						$preset_name = 'small';
						$src_file = $img_subfolder."/".$filename;
						$out .= create_icon ($alt,$img_title,$preset_name,$src_file);
					}
					else
						$remove_small_img = 1;
			}

//=============================================================================
			$source_file_large_img = $fs_root_src."/styles/large/public/".$img_subfolder."/".$filename;
			$dest_file = $fs_root_dest.$large_img;
			if (file_exists($source_file_large_img))
			{
					// скопировать изображение ноды в папку контента
					$res_copy_large_img = 0;
					$res_copy_large_img = copy_img($source_file_large_img, $dest_file); 
					if ($res_copy_large_img == 1)
					{
//echo " res_copy_large_img = ".$res_copy_large_img;
//echo "<br>";
						$out .= remove_img($source_file_large_img); 
					}
			}
			else // создать иконку
			{
					if (!file_exists($dest_file))
					{
						$alt = "";
						$img_title = "";
						$preset_name = 'large';
						$src_file = $img_subfolder."/".$filename;
						$out .= create_icon ($alt,$img_title,$preset_name,$src_file);
					}
					else
						$remove_large_img = 1;
			}

//=============================================================================

			if (
				//($res_copy_original_img == 1) && 
				($remove_preview_img == 1) &&
				($remove_medium_img == 1) &&
				($remove_small_img == 1) &&
				($remove_large_img == 1)
			)
			{
//echo "res_copy_original_img = ".$res_copy_original_img;
echo " remove_preview_img = ".$remove_preview_img;
echo " remove_medium_img = ".$remove_medium_img;
echo " remove_small_img = ".$remove_small_img;
echo " remove_large_img = ".$remove_large_img;
echo "<br>";
				$out .= remove_img($source_file_original_img); 
			}

//=============================================================================
		}//----------------- end if

//----------------------------- вывод изображения с лайтбоксом и ссылками на другие размеры картинки
			$out.=	"<div class='picture'>";
/*
			$out .="<a rel='lightbox' title='".$title."' href='".$url_content_medium.$medium_img."'>
<img alt='".$alt."' title='".$title."' src='".$url_content_preview.$preview_gallery_img."'></a>
<span class='resize'>увеличить в 
	<a rel='lightbox' href='".$url_content_small.$small_img."'>2x</a> 
	<a rel='lightbox' href='".$url_content_medium.$medium_img."'>3x</a> 
	<a rel='lightbox' href='".$url_content_large.$large_img."'>4x</a>
	<a href='".$url_content_original.$original_img."' target=_blank>полный размер</a>
</span>
<br>
<p>".$title."</p>";
*/

			$out .="<a class='pirobox' 
title='".$title."' href='".$url_content_medium.$medium_img."'>
<img alt='".$alt."' title='".$title."' src='".$url_content_preview.$preview_img."'></a>
<br>
<span class='resize'>увеличить в 
	<a class='pirobox' href='".$url_content_small.$small_img."'>2x</a> 
	<a class='pirobox' href='".$url_content_medium.$medium_img."'>3x</a> 
	<a class='pirobox' href='".$url_content_large.$large_img."'>4x</a>
	<a href='".$url_content_original.$original_img."' target=_blank>полный размер</a>
</span>
<br>
<p>".$title."</p>";

			$out.=	"</div>";

		}//--------------- end for
echo $out;
	}//---------------------- end if 
}

?>

			</div> <!-- end picture column -->
		</td>

	</tr>
</tbody>
</table>
</div>			<!-- end notebook_page -->
<?
//-------------------------------------------------------------------------
	if (!empty($content['book_navigation']))
	{
		if (isset($content['body']['#object']->book))
		{
			//if ($content['body']['#object']->book['has_children'] == 0)
			if ($content['body']['#object']->book['depth'] == 3)
			{
				echo $content['book_navigation']['#markup'];
			}
		}
	}
//-------------------------------------------------------------------------
?>
</div>

  <div class="clearfix">
    <?php if (!empty($content['links'])): ?>
      <div class="links"><?php print render($content['links']); ?></div>
    <?php endif; ?>

    <?php print render($content['comments']); ?>
  </div>

</div>
