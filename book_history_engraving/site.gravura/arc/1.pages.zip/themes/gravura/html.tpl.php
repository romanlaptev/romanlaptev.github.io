<?php

/**
 * @file
 * Default theme implementation to display the basic html structure of a single
 * Drupal page.
 *
 * Variables:
 * - $css: An array of CSS files for the current page.
 * - $language: (object) The language the site is being displayed in.
 *   $language->language contains its textual representation.
 *   $language->dir contains the language direction. It will either be 'ltr' or 'rtl'.
 * - $rdf_namespaces: All the RDF namespace prefixes used in the HTML document.
 * - $grddl_profile: A GRDDL profile allowing agents to extract the RDF data.
 * - $head_title: A modified version of the page title, for use in the TITLE
 *   tag.
 * - $head_title_array: (array) An associative array containing the string parts
 *   that were used to generate the $head_title variable, already prepared to be
 *   output as TITLE tag. The key/value pairs may contain one or more of the
 *   following, depending on conditions:
 *   - title: The title of the current page, if any.
 *   - name: The name of the site.
 *   - slogan: The slogan of the site, if any, and if there is no title.
 * - $head: Markup for the HEAD section (including meta tags, keyword tags, and
 *   so on).
 * - $styles: Style tags necessary to import all CSS files for the page.
 * - $scripts: Script tags necessary to load the JavaScript files and settings
 *   for the page.
 * - $page_top: Initial markup from any modules that have altered the
 *   page. This variable should always be output first, before all other dynamic
 *   content.
 * - $page: The rendered page content.
 * - $page_bottom: Final closing markup from any modules that have altered the
 *   page. This variable should always be output last, after all other dynamic
 *   content.
 * - $classes String of classes that can be used to style contextually through
 *   CSS.
 *
 * @see template_preprocess()
 * @see template_preprocess_html()
 * @see template_process()
 */
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language; ?>" version="XHTML+RDFa 1.0" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces; ?>>

<head profile="<?php print $grddl_profile; ?>">
  <?php print $head; ?>
  <title><?php print $head_title; ?></title>
<?php print $styles; ?>
<?php //print $scripts; ?>

<?php 
//$alias_arr = explode("/",request_uri());
//echo $alias_arr[1];
//echo "<br>";

global $theme;
//$theme_path = base_path().drupal_get_path('theme',$theme);
$theme_path = drupal_get_path('theme',$theme);

echo <<<EOF
<!--
<style type="text/css" media="all">@import url("http://gravura.local/modules/contextual/contextual.css");</style>
<style type="text/css" media="all">@import url("http://gravura.local/sites/all/modules/ckeditor/ckeditor.css");
-->

<link rel="stylesheet" href="modules/system/system.base.css">
<link rel="stylesheet" href="modules/system/system.menus.css">
<link rel="stylesheet" href="modules/system/system.messages.css">
<link rel="stylesheet" href="modules/system/system.theme.css">

<link rel="stylesheet" href="modules/system/system.admin.css">
<link rel="stylesheet" href="modules/field/theme/field.css">
<link rel="stylesheet" href="modules/node/node.css">
<link rel="stylesheet" href="modules/search/search.css">
<link rel="stylesheet" href="modules/user/user.css">
<link rel="stylesheet" href="sites/all/modules/views/css/views.css">
<link rel="stylesheet" href="sites/all/modules/ctools/css/ctools.css">
<link rel="stylesheet" href="sites/all/modules/lightbox2/css/lightbox.css">
<link rel="stylesheet" href="modules/toolbar/toolbar.css">
<link rel="stylesheet" href="modules/shortcut/shortcut.css">

<link rel="stylesheet" href="$theme_path/style.css">
<link rel="stylesheet" href="$theme_path/css/book.css">

<!--
<script type="text/javascript" src="/misc/jquery.js"></script>
<script type="text/javascript" src="/misc/jquery.once.js"></script>
<script type="text/javascript" src="/misc/drupal.js"></script>
<script type="text/javascript" src="/misc/jquery.cookie.js"></script>
<script type="text/javascript" src="/misc/form.js"></script>
<script type="text/javascript" src="/sites/default/files/languages/ru_t4s7oC-HEeYZs_PSoIy2iYh9dsoek79BbS7vTGlJGkw.js"></script>

<script type="text/javascript" src="/sites/all/modules/lightbox2/js/lightbox.js"></script>
-->
EOF;
?>

</head>
<body class="<?php print $classes; ?>" <?php print $attributes;?>>

  <?php print $page_top; ?>
  <?php print $page; ?>
  <?php print $page_bottom; ?>
</body>
</html>
