<?php

/**
 * Return a themed breadcrumb trail.
 *
 * @param $breadcrumb
 *   An array containing the breadcrumb links.
 * @return a string containing the breadcrumb output.
 */
function gravura_breadcrumb($variables) {
//echo "function gravura_breadcrumb()";
//echo "<br>";

$breadcrumb = $variables['breadcrumb'];
//==========================================================
/*
$alias_arr = explode("/",request_uri());
//echo $alias_arr[1];
//echo "<br>";

$breadcrumb = str_replace($alias_arr[1],"",$breadcrumb);
$breadcrumb = str_replace("//","",$breadcrumb);
$breadcrumb = str_replace("<a href=\"\">","<a href=\"./\">",$breadcrumb);
*/

$breadcrumb = str_replace(base_path(),"",$breadcrumb);
$breadcrumb = str_replace("<a href=\"\">","<a href=\"./\">",$breadcrumb);
$breadcrumb = str_replace("<a>","</a>",$breadcrumb);
//==========================================================

  if (!empty($breadcrumb)) {
    // Provide a navigational heading to give context for breadcrumb links to
    // screen-reader users. Make the heading invisible with .element-invisible.
    $output = '<h2 class="element-invisible">' . t('You are here') . '</h2>';

    $output .= '<div class="breadcrumb">' . implode(' › ', $breadcrumb) . '</div>';

    return $output;
  }
}

/**
 * Override or insert variables into the maintenance page template.
 */
function gravura_preprocess_maintenance_page(&$vars) {
//drupal_set_message('themes/gravura/template.php, gravura_preprocess_maintenance_page');

  // While markup for normal pages is split into page.tpl.php and html.tpl.php,
  // the markup for the maintenance page is all in the single
  // maintenance-page.tpl.php template. So, to have what's done in
  // gravura_preprocess_html() also happen on the maintenance page, it has to be
  // called here.
  gravura_preprocess_html($vars);
}

/**
 * Override or insert variables into the html template.
 */
function gravura_preprocess_html(&$vars) {
//drupal_set_message('themes/gravura/template.php, function gravura_preprocess_html');

  // Toggle fixed or fluid width.
  if (theme_get_setting('gravura_width') == 'fluid') {
    $vars['classes_array'][] = 'fluid-width';
  }
  // Add conditional CSS for IE6.
  drupal_add_css(path_to_theme() . '/fix-ie.css', array('group' => CSS_THEME, 'browsers' => array('IE' => 'lt IE 7', '!IE' => FALSE), 'preprocess' => FALSE));
}

/**
 * Override or insert variables into the html template.
 */
function gravura_process_html(&$vars) {
//drupal_set_message('themes/gravura/template.php, function gravura_process_html');
  // Hook into color.module
  if (module_exists('color')) {
    _color_html_alter($vars);
  }
}

/**
 * Override or insert variables into the page template.
 */
function gravura_preprocess_page(&$vars) {
//drupal_set_message('function gravura_preprocess_page');

  // Move secondary tabs into a separate variable.
  $vars['tabs2'] = array(
    '#theme' => 'menu_local_tasks',
    '#secondary' => $vars['tabs']['#secondary'],
  );
  unset($vars['tabs']['#secondary']);

  if (isset($vars['main_menu'])) {
    $vars['primary_nav'] = theme('links__system_main_menu', array(
      'links' => $vars['main_menu'],
      'attributes' => array(
        'class' => array('links', 'inline', 'main-menu'),
      ),
      'heading' => array(
        'text' => t('Main menu'),
        'level' => 'h2',
        'class' => array('element-invisible'),
      )
    ));
  }
  else {
    $vars['primary_nav'] = FALSE;
  }
  if (isset($vars['secondary_menu'])) {
    $vars['secondary_nav'] = theme('links__system_secondary_menu', array(
      'links' => $vars['secondary_menu'],
      'attributes' => array(
        'class' => array('links', 'inline', 'secondary-menu'),
      ),
      'heading' => array(
        'text' => t('Secondary menu'),
        'level' => 'h2',
        'class' => array('element-invisible'),
      )
    ));
  }
  else {
    $vars['secondary_nav'] = FALSE;
  }

  // Prepare header.
  $site_fields = array();
  if (!empty($vars['site_name'])) {
    $site_fields[] = $vars['site_name'];
  }
  if (!empty($vars['site_slogan'])) {
    $site_fields[] = $vars['site_slogan'];
  }
  $vars['site_title'] = implode(' ', $site_fields);
  if (!empty($site_fields)) {
    $site_fields[0] = '<span>' . $site_fields[0] . '</span>';
  }
  $vars['site_html'] = implode(' ', $site_fields);

  // Set a variable for the site name title and logo alt attributes text.
  $slogan_text = $vars['site_slogan'];
  $site_name_text = $vars['site_name'];
  $vars['site_name_and_slogan'] = $site_name_text . ' ' . $slogan_text;
}

/**
 * Override or insert variables into the node template.
 */
function gravura_preprocess_node(&$vars) {
  $vars['submitted'] = $vars['date'] . ' — ' . $vars['name'];
}

/**
 * Override or insert variables into the comment template.
 */
function gravura_preprocess_comment(&$vars) {
  $vars['submitted'] = $vars['created'] . ' — ' . $vars['author'];
}

/**
 * Override or insert variables into the block template.
 */
function gravura_preprocess_block(&$vars) {
  $vars['title_attributes_array']['class'][] = 'title';
  $vars['classes_array'][] = 'clearfix';
}

/**
 * Override or insert variables into the page template.
 */
function gravura_process_page(&$vars) {
//echo "function gravura_process_page()";
//echo "<br>";

  // Hook into color.module
  if (module_exists('color')) {
    _color_page_alter($vars);
  }
}

/**
 * Override or insert variables into the region template.
 */
function gravura_preprocess_region(&$vars) {
  if ($vars['region'] == 'header') {
    $vars['classes_array'][] = 'clearfix';
  }
}



//----------------------------------------------
//скопировать изображение ноды в папку контента
//----------------------------------------------
function copy_img($source_file, $dest_file)
{
echo "function copy_img";
echo "<br>";
//echo "copy ".$source_file." --> ".$dest_file;
//echo "<br>";
	global $out;
	$res=0;
	if (!file_exists($dest_file))
	{
$out2 .= "<ul>";
$out2 .= "<span class='error'>Не найден </span>".$dest_file;
$out2 .= "</ul>";

		if (mkdir(dirname($dest_file),0,true))
		{
$out2 .= "<ul>";
$out2 .= "<ul>";
$out2 .= "<span class='ok'>Создание </span>".dirname($dest_file);
$out2 .= "</ul>";
$out2 .= "</ul>";
		}
		else
		{
$out2 .= "<ul>";
$out2 .= "<ul>";
$out2 .= "<span class='error'>Не удалось создать </span>".dirname($dest_file);
$out2 .= "</ul>";
$out2 .= "</ul>";
		}

	}
	else
		$res=1;

	if (file_exists($source_file))
	{
$out2 .= "<span class='ok'>Исходный файл </span>".$source_file." существует, <span class='warning'>перемещаем</span>";
$out2 .= "<br>";
		if (file_exists($dest_file))
		{
$out2 .= "<ul>";
$out2 .= "<span class='warning'>Файл назначения</span>".$dest_file." существует, <span class='warning'>перезаписываем</span>";
$out2 .= "</ul>";
		}

		if (!copy($source_file, $dest_file)) 
		{
$out2 .= "<ul>";
$out2 .= "<span class='error'>Не удалось скопировать </span>".$source_file;
$out2 .= "</ul>";
		}
		else
		{
			$res=1;
$out2 .= "<ul>";
$out2 .= "<span class='ok'>Скопирован </span>";
$out2 .= $source_file." >> ".$dest_file;
$out2 .= "</ul>";
		}

	}

echo $out2;
//echo "res = ".$res;
//echo "<br>";
	return $res;

}//------------ end func
//----------------------
//удалить изображение 
//----------------------
function remove_img($file)
{
echo "function remove_img";
echo "<br>";
	if (unlink ($file))
	{
$out2 .= "<ul>";
$out2 .= "<span class='ok'>Remove </span>".$file;
$out2 .= "</ul>";
	}

echo $out2;
	return $out2;
}//------------ end func

//-----------------
// Создать иконку 
//-----------------
function create_icon ($alt,$img_title,$preset_name,$src_file)
{
echo "function create_icon";
echo "<br>";
	$out="";
	$image_settings = array(
			'style_name' => $preset_name,
//'path' => 'public://img_book/p0007_1.jpg',
//'path' => 'img_book/p0007_1.jpg',
			'path' => $src_file,
			'alt' => $alt,
			'title' => $img_title,
			'attributes' => array('class' => 'image'),
			'getsize' => FALSE,
			);
	//print theme('image_style', $image_settings);
	$img = theme('image_style', $image_settings);
	//$img = theme('imagecache', $preset_name, $src_file, $alt, $img_title);		
	echo $img;

	$out .= "<ul>";
	$out .= "<span class='warning'>создать PRESET $preset_name для </span> ".$src_file;
	$out .= "</ul>";
	return $out;
}//------------------------ end func
