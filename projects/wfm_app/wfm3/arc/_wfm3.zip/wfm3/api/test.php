<?php
//phpinfo();
echo 2+2;
?>
