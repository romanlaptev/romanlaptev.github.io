<html>
<head>
<meta charset="utf-8">
<style>
#field
{
	width:55%;
	border:1px solid;
	padding:10px;
}

#field input
{
	float:right;
}

#field h2
{
	text-align:center;
}

td
{
	border:1px solid;
	width:50px;
	height:50px;
	text-align:center;
}
td.marked
{
	background:lightblue;
}
td.move2
{
	background:red;
}
td.move3
{
	background:yellow;
}
td.move4
{
	background:orange;
}
</style>
</head>
<body>
<?php

$field=array();

for ($n1=0; $n1<100; $n1++)
{
	$field[$n1]=0;
}

$pos=0;
for ($n1=0; $n1<10; $n1++)
{
	$pos=get_random_num_cell();
}//--------------------------- end for

//echo "<pre>";
//print_r($field);
//echo "</pre>";

//====================================================
function get_random_num_cell()
{
	global $field;
	$pos=rand(0,99);
//echo $pos;
//echo "<br>";
	while ($field[$pos]==1) //исключение повторов номера
	{
//echo "<ul>";
//echo "error!";
//echo "<br>";
		$pos=rand(0,99);
//echo "new pos=".$pos;
//echo "<br>";
//echo "</ul>";
	}//--------------------------- end while

	if ($field[$pos+1] == 0)
	{
		if ($field[$pos-1] == 0)
		{

			if ($field[$pos+10] == 0)
			{
				if ($field[$pos-10] == 0)
				{

					if ($field[$pos-11] == 0)
					{
						if ($field[$pos+11] == 0)
						{

							if ($field[$pos-9] == 0)
							{
								if ($field[$pos+9] == 0)
								{
$field[$pos]=1;
								}
								else
								{
									$pos=get_random_num_cell();
									//$field[$pos]=4;
								}
							}
							else
							{
								$pos=get_random_num_cell();
								//$field[$pos]=4;
							}
						}
						else
						{
							$pos=get_random_num_cell();
							//$field[$pos]=4;
						}
					}
					else
					{
						$pos=get_random_num_cell();
						//$field[$pos]=4;
					}
				}
				else
				{
					$pos=get_random_num_cell();
					//$field[$pos]=4;
				}
			}
			else
			{
				$pos=get_random_num_cell();
				//$field[$pos]=4;
			}

		}
		else
		{
			$pos=get_random_num_cell();
			//$field[$pos]=4;
		}
	}
	else
	{
		$pos=get_random_num_cell();
		//$field[$pos]=4;
	}

	return $pos;
}//-------------------------- end func
?>

<div id="field">
<h2>Морской бой</h2>
<input type="button" value="Обновить" onClick="javascript:window.location.reload();"/>
<?
$n3=0;
echo "<table>";
for ($n1=0; $n1<10; $n1++)
{
	echo "<tr>";
	for ($n2=0; $n2<10; $n2++)
	{
		if ($field[$n3]==1)
		{
			echo "<td class='marked'>";
		}

		if ($field[$n3]==2)
		{
			echo "<td class='move2'>";
		}

		if ($field[$n3]==3)
		{
			echo "<td class='move3'>";
		}

		if ($field[$n3]==4)
		{
			echo "<td class='move4'>";
		}

		if ($field[$n3]==0)
		{
			echo "<td>";
		}

		//echo $n3.".".$field[$n3];
		echo "&nbsp;";
		$n3++;

		echo "</td>";
	}
	echo "</tr>";
}
echo "</table>";
?>
</div>

</body>
</html>

