<html>
<head>
<meta charset="utf-8">

<script>
function createRequestObject() 
{
	if (window.XMLHttpRequest) 
		req = new XMLHttpRequest();
	else 
		if (window.ActiveXObject) 
		{
			try 
			{
				req = new ActiveXObject('Msxml2.XMLHTTP');
			} catch (e){}

			try 
			{
				req = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e){}
		}
	return req;		
}

function view_field()
{
	var request = createRequestObject();
	url = "./view.php";
	request.onreadystatechange  = function() 
	{ 
		document.getElementById('step').innerHTML=request.readyState;
		if(request.readyState == 4) 
		{
			document.getElementById('status').innerHTML=request.status;
			var str_res = request.responseText;
//alert (str_res);
//document.write (str_res);
			var result = document.getElementById('result');
			result.innerHTML = str_res;
		}
	};
	request.open('POST', url, true);
	
	if (request.setRequestHeader) 
	{
		request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	}

	var str = 'action=<?php echo $_REQUEST['action'] ?>&id=<?php echo $_REQUEST['id'] ?>';
	//var str = '';

	request.send(str);
	return true;
}//----------------------------------- end func

</script>

<style>
#result
{
	/*border:1px solid;*/
	padding:20px;
}
#control
{
	width:55%;
}
#control input
{
	float:right;
}
/*---------------------------------*/
#field
{
	width:48%;
	border:1px solid;
	padding:10px;
	float:left;
}

#info
{
	width:45%;
	float:left;
	padding:10px;
}

#field input
{
	float:right;
}

#field h2
{
	text-align:center;
}

td
{
	border:1px solid;
	width:50px;
	height:50px;
	text-align:center;
}
td.marked
{
	background:lightblue;
}
td.cell2
{
	background:red;
}
td.cell3
{
	background:yellow;
}
td.cell4
{
	background:orange;
}
td.cell5
{
	background:silver;
}

</style>

</head>

<body onload="view_field();">

<h2>Морской бой</h2>

<div id="control">
	<input type="button" value="reload page" onClick="javascript:window.location.reload();"/>
	<input type="button" value="Обновить (ajax)" onClick="view_field();"/>
</div>

<div style="clear:both;"></div>

<div>
	Ход выполнения запроса: <b id="step">null</b><br>
	Статус ответа: <b id="status">null</b><br>
</div>
<div>
<!--	<input type="button" value="save" onClick="save_field();"/> -->
	<a href="index.php?action=load&id=1">load field state 1</a> 
<!--	<a href="view.php">view.php</a><br> -->
</div>

<div id="result"></div>


</body>
</html>

