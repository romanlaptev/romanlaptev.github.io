<html>
<head>
<meta charset="utf-8">
<style>
td
{
	border:1px solid;
	width:50px;
	height:50px;
	text-align:center;
}
td.marked
{
	background:lightblue;
}
td.move2
{
	background:red;
}
td.move3
{
	background:yellow;
}
td.move4
{
	background:orange;
}
</style>
</head>
<body>
<h2>Морской бой</h2>
<?php

$field=array();

for ($n1=0; $n1<100; $n1++)
{
	$field[$n1]=0;
}

$pos=0;

for ($n1=0; $n1<10; $n1++)
{
echo $n1;
echo ".";
	$pos=rand(0,99);
echo $pos;
echo "<br>";

	while ($field[$pos]==1) //определить незанятую ячейку
	{
//echo "<ul>";
//echo "error!";
//echo "<br>";
		$pos=rand(0,99);
//echo "new pos=".$pos;
//echo "<br>";
//echo "</ul>";
	}
	$field[$pos]=1;
}

//echo "<pre>";
//print_r($field);
//echo "</pre>";

//-----------------------------------
for ($n1=0; $n1<100; $n1++)
{
/*
	if (($field[$n1] == 1) &&
		($field[$n1+1] == 1))
	{
		$field[$n1]=2;
		$field[$n1+1]=3;
	}
*/
	if ($field[$n1] == 1)
	{

		if ($field[$n1+1] == 1)
		{
			$field[$n1]=2;
			$field[$n1+1]=3;
			move_value($n1+1);
		}
		if ($field[$n1-1] == 1)
		{
			$field[$n1]=2;
			$field[$n1-1]=3;
			move_value($n1-1);
		}

		if ($field[$n1+10] == 1)
		{
			$field[$n1]=2;
			$field[$n1+10]=3;
			move_value($n1+10);
		}
		if ($field[$n1-10] == 1)
		{
			$field[$n1]=2;
			$field[$n1+10]=3;
			move_value($n1-10);
		}

		if ($field[$n1-11] == 1)
		{
			$field[$n1]=2;
			$field[$n1-11]=3;
			move_value($n1-11);
		}
		if ($field[$n1+11] == 1)
		{
			$field[$n1]=2;
			$field[$n1+11]=3;
			move_value($n1+11);
		}

		if ($field[$n1-9] == 1)
		{
			$field[$n1]=2;
			$field[$n1-9]=3;
			move_value($n1-9);
		}
		if ($field[$n1+9] == 1)
		{
			$field[$n1]=2;
			$field[$n1+9]=3;
			move_value($n1+9);
		}

	}

}
//-----------------------------------

$n3=0;
echo "<table>";
for ($n1=0; $n1<10; $n1++)
{
	echo "<tr>";
	for ($n2=0; $n2<10; $n2++)
	{
		if ($field[$n3]==1)
		{
			echo "<td class='marked'>";
		}

		if ($field[$n3]==2)
		{
			echo "<td class='move2'>";
		}

		if ($field[$n3]==3)
		{
			echo "<td class='move3'>";
		}

		if ($field[$n3]==4)
		{
			echo "<td class='move4'>";
		}

		if ($field[$n3]==0)
		{
			echo "<td>";
		}

		echo $n3.".".$field[$n3];
		$n3++;

		echo "</td>";
	}
	echo "</tr>";
}
echo "</table>";

function move_value($value)
{
	global $field;
echo "function move_value($value)";
echo "<br>";

	for ($n1=0; $n1<100; $n1++)
	{
		if ($field[$n1] == 0)
		{

			if ($field[$n1+1] == 0)
			{
				if ($field[$n1-1] == 0)
				{

					if ($field[$n1+10] == 0)
					{
						if ($field[$n1-10] == 0)
						{

							if ($field[$n1-11] == 0)
							{
								if ($field[$n1+11] == 0)
								{

									if ($field[$n1-9] == 0)
									{
										if ($field[$n1+9] == 0)
										{
//$field[$value];
$field[$n1]=4;
return;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}//-------------------------- end for
}
?>
</body>
</html>

