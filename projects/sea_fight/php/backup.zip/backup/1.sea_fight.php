<html>
<head>
<meta charset="utf-8">
<style>
td
{
	border:1px solid;
	width:50px;
	height:50px;
	text-align:center;
}
td.marked
{
	background:lightblue;
}
td.move
{
	background:red;
}
</style>
</head>
<body>
<h2>Морской бой</h2>
<?php

$field=array();

for ($n1=0; $n1<100; $n1++)
{
	$field[$n1]=0;
}

$pos=0;
for ($n1=0; $n1<20; $n1++)
{
//echo $n1;
//echo ".";
	$pos=rand(0,99);
//echo $pos;
//echo "<br>";

	$cont=0;
	while ($field[$pos]==1) //определить незанятую ячейку
	{
//echo "<ul>";
//echo "error!";
//echo "<br>";
		$pos=rand(0,99);
//echo "new pos=".$pos;
//echo "<br>";
//echo "</ul>";
	}
	$field[$pos]=1;
}

//echo "<pre>";
//print_r($field);
//echo "</pre>";

$field[0] = 0;
$field[1] = 0;
$field[2] = 0;
$field[3] = 0;
$field[4] = 0;
$field[5] = 1;
$field[6] = 1;
$field[7] = 0;
$field[8] = 0;
$field[9] = 0;
$field[10] = 0;
$field[11] = 1;
$field[12] = 0;
$field[13] = 0;
$field[14] = 0;
$field[15] = 0;
$field[16] = 0;
$field[17] = 0;
$field[18] = 0;
$field[19] = 1;
$field[20] = 0;
$field[21] = 0;
$field[22] = 0;
$field[23] = 0;
$field[24] = 0;
$field[25] = 0;
$field[26] = 1;
$field[27] = 0;
$field[28] = 0;
$field[29] = 0;
$field[30] = 0;
$field[31] = 0;
$field[32] = 0;
$field[33] = 0;
$field[34] = 0;
$field[35] = 0;
$field[36] = 0;
$field[37] = 0;
$field[38] = 0;
$field[39] = 0;
$field[40] = 0;
$field[41] = 0;
$field[42] = 0;
$field[43] = 1;
$field[44] = 1;
$field[45] = 0;
$field[46] = 0;
$field[47] = 0;
$field[48] = 1;
$field[49] = 0;
$field[50] = 0;
$field[51] = 0;
$field[52] = 0;
$field[53] = 0;
$field[54] = 0;
$field[55] = 0;
$field[56] = 0;
$field[57] = 0;
$field[58] = 0;
$field[59] = 1;
$field[60] = 0;
$field[61] = 1;
$field[62] = 0;
$field[63] = 1;
$field[64] = 1;
$field[65] = 1;
$field[66] = 0;
$field[67] = 0;
$field[68] = 0;
$field[69] = 0;
$field[70] = 0;
$field[71] = 0;
$field[72] = 1;
$field[73] = 1;
$field[74] = 1;
$field[75] = 0;
$field[76] = 0;
$field[77] = 0;
$field[78] = 1;
$field[79] = 0;
$field[80] = 0;
$field[81] = 0;
$field[82] = 0;
$field[83] = 0;
$field[84] = 0;
$field[85] = 0;
$field[86] = 0;
$field[87] = 1;
$field[88] = 1;
$field[89] = 0;
$field[90] = 0;
$field[91] = 1;
$field[92] = 0;
$field[93] = 0;
$field[94] = 0;
$field[95] = 0;
$field[96] = 0;
$field[97] = 0;
$field[98] = 0;
$field[99] = 0;

//---------------------------------------
for ($n1=0; $n1<100; $n1++)
{
	if ($field[$n1]==1)
	{
		$n2=$n1+11;
		if ($field[$n2]==1)
		{
			$field[$n2]=2;
			//$field[$n2-1]=1;
		}

		$n3=$n3+9;
		if ($field[$n3]==1)
		{
			//$field[$n3]=2;
			//$field[$n2-1]=1;
		}
	}
}
//---------------------------------------

$n3=0;
echo "<table>";
for ($n1=0; $n1<10; $n1++)
{
	echo "<tr>";
	for ($n2=0; $n2<10; $n2++)
	{
		if ($field[$n3]==1)
		{
			echo "<td class='marked'>";
		}

		if ($field[$n3]==2)
		{
			echo "<td class='move'>";
		}

		if ($field[$n3]==0)
		{
			echo "<td>";
		}

		echo $field[$n3];
		$n3++;

		echo "</td>";
	}
	echo "</tr>";
}
echo "</table>";

?>
</body>
</html>

