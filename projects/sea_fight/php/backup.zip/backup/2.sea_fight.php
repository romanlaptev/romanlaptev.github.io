<html>
<head>
<meta charset="utf-8">
<style>
td
{
	border:1px solid;
	width:50px;
	height:50px;
	text-align:center;
}
td.marked
{
	background:lightblue;
}
td.move2
{
	background:red;
}
td.move3
{
	background:yellow;
}
</style>
</head>
<body>
<h2>Морской бой</h2>
<?php

$field=array();

for ($n1=0; $n1<100; $n1++)
{
	$field[$n1]=0;
}

$pos=0;

for ($n1=0; $n1<10; $n1++)
{
echo $n1;
echo ".";
	$pos=rand(0,99);
echo $pos;
echo "<br>";

/*
	while ($field[$pos]==1) //определить незанятую ячейку
	{
echo "<ul>";
echo "error!";
echo "<br>";
		$pos=rand(0,99);
echo "new pos=".$pos;
echo "<br>";
echo "</ul>";
	}
*/
	if(($field[$pos] != 1) &&
		($field[$pos+1] != 1) &&
			($field[$pos-1] != 1)
		)
	{
		$field[$pos]=1;
	}
	else
	{
		//$field[$pos]=2;
	}

/*
	if ($field[$pos+1]==1)
	{
echo "<ul>";
echo "2.error!";
echo "<br>";
		$field[$pos]=2;
		$pos=rand(0,99);
echo "2.new pos=".$pos;
echo "<br>";
echo "</ul>";
		$field[$pos]=3;
	}
	else
	{
		$field[$pos]=1;
	}
*/
/*
	if ($field[$pos-1]==1)
	{
echo "<ul>";
echo "3.error!";
echo "<br>";
		$pos=rand(0,99);
echo "3.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}
*/

/*
	if ($field[$pos+10]==1)
	{
echo "<ul>";
echo "4.error!";
echo "<br>";
		$pos=rand(0,99);
echo "4.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}

	if ($field[$pos-10]==1)
	{
echo "<ul>";
echo "5.error!";
echo "<br>";
		$pos=rand(0,99);
echo "5.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}

/*
	if ($field[$pos+11]==1)
	{
echo "<ul>";
echo "6.1.error!";
echo "<br>";
		$pos=rand(0,99);
echo "6.1.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}

	if ($field[$pos-11]==1)
	{
echo "<ul>";
echo "6.2.error!";
echo "<br>";
		$pos=rand(0,99);
echo "6.2.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}

	if ($field[$pos+9]==1)
	{
echo "<ul>";
echo "7.1.error!";
echo "<br>";
		$pos=rand(0,99);
echo "7.1.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}

	if ($field[$pos-9]==1)
	{
echo "<ul>";
echo "7.2.error!";
echo "<br>";
		$pos=rand(0,99);
echo "7.2.new pos=".$pos;
echo "<br>";
echo "</ul>";
	}
*/

	//$field[$pos]=1;
}

//echo "<pre>";
//print_r($field);
//echo "</pre>";


$n3=0;
echo "<table>";
for ($n1=0; $n1<10; $n1++)
{
	echo "<tr>";
	for ($n2=0; $n2<10; $n2++)
	{
		if ($field[$n3]==1)
		{
			echo "<td class='marked'>";
		}

		if ($field[$n3]==2)
		{
			echo "<td class='move2'>";
		}

		if ($field[$n3]==3)
		{
			echo "<td class='move3'>";
		}

		if ($field[$n3]==0)
		{
			echo "<td>";
		}

		echo $field[$n3];
		$n3++;

		echo "</td>";
	}
	echo "</tr>";
}
echo "</table>";

?>
</body>
</html>

