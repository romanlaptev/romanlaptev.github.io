<?
$host = "localhost";
$user = "root";
$pwd = "master";
$dbname = "sea_fight";
$tablename = "field_coord";

//$host = "localhost";
//$user = "fr18091_db1";
//$pwd = "m@ster";
//$dbname = "fr18091_db1";
//$tablename = "field_coord";
?>

