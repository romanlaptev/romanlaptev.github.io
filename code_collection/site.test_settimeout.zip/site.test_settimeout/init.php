﻿<a href="index.php">Вернуться на сайт</a><br>
<?php 
    $HOST_DB 		= "localhost";	// Имя хоста
    $USER_DB 		= "root";		// Имя пользователя БД
    $PASSWORD_DB 	= "";			// Пароль пользователя БД	
    $db = mysql_connect ($HOST_DB,$USER_DB,$PASSWORD_DB);		//запрос к базе данных

$base = "slider";
if (mysql_query("CREATE DATABASE IF NOT EXISTS `$base`")) {
        echo  ("<p>База данных успешно создана!".PHP_EOL."</p>");
    } else {
        echo  ("<p>Ошибка создания базы данных: ".mysql_error().PHP_EOL."</p>");
    }

if (mysql_query("USE `$base`")) {
        echo ("<p>База данных успешно подключена!".PHP_EOL."</p>");
    } else {
        echo ("<p>Ошибка подключения базы данных: ".mysql_error().PHP_EOL."</p>");
    }

$f = file_get_contents("_BASE/".$base.".sql");
$tables = explode("\n\n",$f);
foreach($tables as $table) {
	echo $table.PHP_EOL;
    $result = mysql_query($table);

	if ($result) {
        echo ("<p>Запрос успешно выполнен!".PHP_EOL."</p>");
    } else {
        echo ("<p>Ошибка запроса: ".mysql_error().PHP_EOL."</p>");
    }
	echo "<hr>";
}

?>
