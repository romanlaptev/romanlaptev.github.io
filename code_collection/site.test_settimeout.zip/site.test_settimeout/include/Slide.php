<?php
// echo "<pre>";
// print_r ($_REQUEST);
// echo "</pre>";
// error_reporting(E_ALL|E_STRICT);
// ini_set('display_errors', 1);

	// Вывод всех записей о слайдах в таблицу
    function index(){
	if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(is_user())	{ // если текущий пользователь - студент
			$sql = "SELECT * FROM user WHERE id = ".$_SESSION['userid'];
			$result = mysql_query($sql);
			if($result) {
				$myrow = mysql_fetch_array($result);
				if(!$myrow['public']) {	// если регистрация не одобрена
					echo "<h3 style='margin-top:68px;' class='text-center text-danger'>Вы не можете добавлять информацию, пока администратор не одобрит Вашу регистрацию</h3>";
					return;
				}
			}
			else return;		
		}
		?>
			<script>	<!-- Функция всплывающего окна при удалении -->
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<?php 
			if(is_user()) 		// если текущий пользователь - студент
				echo '<h1 class="top">Мои слайды</h1>';
			else echo '<h1 class="top">Слайды</h1>';
		?>
			<div class="text-center">
				<!-- Ссылки на добавление разных типов слайдов -->
				<a href='?table=slide&action=insertform&value=text' >Добавить текстовый слайд</a>
				<a href='?table=slide&action=insertform&value=image'>Добавить слайд-изображение</a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href='?table=slide&action=insertform&value=video'>Добавить видеослайд</a>&nbsp;&nbsp;&nbsp;&nbsp;
			</div>
		<!-- Таблица слайдов -->	
		<table>
			<tr>
				<th></th>
				<th>№</th>
				<?php	
					if(is_admin())  	// если текущий пользователь - администратор
						echo "<th>Пользователь</th>";
				?>
				<th>Тип</th>
<!--
				<th>Ссылка</th>
-->
				<th>Текст</th>
				<th>Изображение</th>
				<th>Заголовок</th>
				<th>Дата начала показа</th>
				<th>Дата конца показа</th>
				<th>Цвет фона</th>
				<th>Подразделение</th>
				<th>Приоритет</th>
				<th>Опубли-<br>ковано</th>
			</tr>
		<?php
		if(is_user())	$query = "SELECT id,(SELECT CONCAT(lastname,'&nbsp;',left(firstname,1),'.&nbsp;',' ',left(fname,1)) FROM user WHERE id = user_id) AS user,url,text,image,header,starttime,endtime,(SELECT name FROM type WHERE id = type_id) AS type_id,(SELECT name FROM bg WHERE id = bg_id) AS bg, public, priority_id, (SELECT name FROM department WHERE id = department_id) AS department FROM slide WHERE user_id = ".$_SESSION['userid']." ORDER BY id";
		if(is_admin())		$query = "SELECT id,(SELECT CONCAT(lastname,'&nbsp;',left(firstname,1),'.&nbsp;',' ',left(fname,1)) FROM user WHERE id = user_id) AS user,url,text,image,header,starttime,endtime,(SELECT name FROM type WHERE id = type_id) AS type_id,(SELECT name FROM bg WHERE id = bg_id) AS bg, public, priority_id, (SELECT name FROM department WHERE id = department_id) AS department FROM slide WHERE 1 ORDER BY id";
		$result = mysql_query($query);
		$i = 0;
		if($result)	while ($slide = mysql_fetch_assoc($result)) {			

				$i++;
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=slide&action=delete&id=<?php echo $slide['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
							<a href='?table=slide&action=updateform&id=<?php echo $slide['id']; ?>'><img src='images/edit.png'></a>
						</td>
						<td><?php echo $i; ?>	</td>
				<?php	
						if(is_admin())	// если текущий пользователь - администратор
							echo "<td>".$slide['user']."</td>";
				?>
						<td><?php echo $slide['type_id']; ?>	</td>
<!--
						<td><?php if((!empty($slide['url']))&&(($slide['url']<>"#"))) echo "<a href='".$slide['url']."'>Ссылка</a>";?></td>
-->
						<td><?php if((!empty($slide['text'])))  echo "<a href='#' title='".$slide['text']."'>Текст</a>";?></td>
						<td><?php if((!empty($slide['image']))) {
// echo "slide:<pre>";
// print_r ($slide);
// echo "</pre>";		
if( $slide['type_id'] !== "video" ){							
echo "<img style='width:100px;' src='".$slide['image']."'>";
}
							}?></td>
						<td><?php echo $slide['header']; ?>	</td>
						<td><?php echo $slide['starttime']; ?>	</td>
						<td><?php echo $slide['endtime']; ?>	</td>
						<td style="background-color:<?php echo $slide['bg']; ?>"></td>
					<td><?php echo $slide['department']; ?>	</td>
					<td>
						<?php 
							if ($slide['priority_id'] == 2) 
								  echo "<a href='admin.php?table=slide&action=setPriorityStandart&id=".$slide['id']."'>Высокий</a>"; 
							else  echo "<a href='admin.php?table=slide&action=setPriorityHigh&id=".$slide['id']."'>Стандартный</a>"; 
						?>							
					</td>
				<?php	if(is_admin())	{  	// если администратор
				?>
					<td>
						<?php 
							if ($slide['public']) 
								  echo "<a href='admin.php?table=slide&action=setPublicOff&id=".$slide['id']."'><img src='images/ok.png'></a>"; 
							else  echo "<a href='admin.php?table=slide&action=setPublicOn&id=".$slide['id']."'><img src='images/no.png'></a>"; 
						?>							
					</td>
				<?php	}	
						else	{	// если пользователь
				?>
					<td>
						<?php 
							if ($slide['public']) 
								  echo "<img src='images/ok.png'>"; 
							else  echo "<img src='images/no.png'>"; 
						?>							
					</td>
				<?php	}	?>
				</tr>
				<?php	
			}
		echo "</table>";
    }

    // Обновления записи (форма)
     function updateform($id = NULL, $type=NULL){
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(!empty($id))	{
			$query = "SELECT S.*, T.name AS type FROM slide AS S, type AS T WHERE  (S.type_id = T.id) AND (S.id=".$id.")";
			$result = mysql_query($query);
			if($result)	{
				$slide = mysql_fetch_assoc($result);
				$type = $slide['type'];
				$days = $slide['days'];
			}
		}
		else {
			$fields = "id,user_id,url,text,image,header,starttime,endtime,type_id,bg,duration_id,public";
			foreach(explode(",",$fields) as $f) $slide[$f] = '';
		}
		if(!empty($id)) echo "<h1>Редактирование записи № ".$id." в таблице Слайды</h1>".PHP_EOL;
		else echo "<h1>Добавление записи в таблицу Слайды</h1>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div class="close">'.PHP_EOL;
		echo '			<a href="admin.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?table=slide' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL; ?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Заголовок *</label>
			<div>
				<input class='form-control' id='header' name='header' type='text' value='<?php echo $slide['header']; ?>' required = "true"/>
			</div>
		</div>
		
		<?php if($type == "image")	{	?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Текст</label>
			<div>
<!--
				<input class='form-control' id='text' name='text' type='text' value='<?php echo $slide['text']; ?>' />
-->
<textarea name="text" id="text" cols="45" rows="5"><?php echo $slide['text']; ?></textarea>
			</div>
		</div>
		<?php	}	?>
		<?php if($type == "text")	{	?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Текст *</label>
			<div>
<!--			
				<input class='form-control' id='text' name='text' type='text' value='<?php echo $slide['text']; ?>'  required = "true"/>
-->				
<textarea name="text" id="text" cols="45" rows="5"><?php echo $slide['text']; ?></textarea>
			</div>
		</div>
		<?php	}	?>
		
	
		<?php if($type == "video")	{	
// echo "slide:<pre>";
// print_r ($slide);
// echo "</pre>";		
		?>
		<div class='form-group'>
<!--			
			<label style='word-wrap: break-word;'>Ссылка *</label>
			<div>
				<input class='form-control' id='url' name='url' type='text' value='<?php echo $slide['url']; ?>' required = "false"/>
			</div>
-->			
<?php
	if(!empty( $slide['image'] ) ){
?>
			<div>
<video width="560" height="315" controls="controls">
	<source  src='<?php echo $slide['image']; ?>'/>
Tag <b>video</b> not support by this browser.... 
</video>
			</div>
<?php
		}
?>
			<div>
				<input id = "upload-video" name = "image" type="file"  required = "true" accept=".mp4,.avi" />
<small>допустимые форматы видео - mp4, avi</small>
			</div>

		</div>
		<?php	}	?>
		<?php if($type == "image")	{	?>
		<?php if(empty($id))	{ ?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Изображение *</label>
			<div>
				<img width = "25%" src="<?php echo $slide['image']; ?>">
				<input id = "image" name = "image" type="file"  required = "true"  accept=".jpg,.jpeg,.png" />
				<input cols = "70" name = "imagename" type = "hidden" value="<?php echo $slide['image']; ?>" />
			</div>
		</div>
		<?php	}	?>
		<?php if(!empty($id))	{ ?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Изображение</label>
			<div>
				<img width = "25%" src="<?php echo $slide['image']; ?>">
				<input id = "image" name = "image" type="file" />
				<input cols = "70" name = "imagename" type = "hidden" value="<?php echo $slide['image']; ?>" />
			</div>
		</div>
		<?php	}	?>
		<?php	}	?>
		
		
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Дата начала показа *</label>
			<div>
				<input style='padding-top:0px;' class='form-control' id='starttime' name='starttime' type='date' value="<?php if(!empty($id)) echo substr($slide['starttime'],0,10); ?>"  required = "true"/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Дата конца показа *</label>
			<div>
				<input style='padding-top:0px;' class='form-control' id='endtime' name='endtime' type='date' value="<?php if(!empty($id)) echo substr($slide['endtime'],0,10); ?>"  required = "true"/>
			</div>
		</div>
		
<?php if($type == "text" || $type == "image"){	?>
		
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Время показа</label>
			<div>
				<select class="form-control" id="play-time" name="playtime">
						<option></option>
<?php
			$query = "SELECT * FROM playtime;";
			$res = mysql_query($query);
			for( $n = 0; $n < mysql_num_rows ($res); $n++){
				$row = mysql_fetch_array($res);
				if( $row['id'] === $slide['playtime']){
					echo "<option value=".$row['id']." selected>".$row['name']."</option>";
				} else {
					echo "<option value=".$row['id'].">".$row['name']."</option>";
				}
			}
?>						
				</select>
			</div>
		</div>		
<?php	}	?>
		
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Приоритет *</label>
			<div>
			<select class="form-control"  id="priority_id"  name="priority_id">
<?php
/*				
				$query = "SELECT id, name FROM priority WHERE 1 ORDER By id"; 
				$result = mysql_query($query); 
				while ($option = mysql_fetch_assoc($result)) 
					echo '				<option value="'.$option['id'].'" '.is_sel($option['id'],$slide['duration_id']).'>'.$option['name'].'</option>'.PHP_EOL;
*/
				$query = "SELECT id, name FROM priority ORDER By id"; 
				$res = mysql_query($query); 
				for( $n = 0; $n < mysql_num_rows ($res); $n++){
					$row = mysql_fetch_array($res);
					if( $row['id'] === $slide['priority_id']){
						echo "<option value=".$row['id']." selected>".$row['name']."</option>";
					} else {
						echo "<option value=".$row['id'].">".$row['name']."</option>";
					}
				}
				
?>
			</select>
			</div>
		</div>
		<div class="form-group">
			<label style='word-wrap: break-word;'>Подразделение *</label>
			<div>
				<select class="form-control" id="exampleFormControlSelect1" name="department_id"   required = "true" >
<?php
			$query = "SELECT * FROM department WHERE 1 ORDER BY id DESC";
			$result = mysql_query($query);
			if ($result) 
				while ($mrow = mysql_fetch_array($result))
				   echo "						<option style='text-align:center' ".(($mrow['id'] == $myrow['department_id'])?"SELECTED":"")." value=".$mrow['id'].">".$mrow['name']."</option>";
?>
				</select>
			</div>
		</div>
<?php if($type == "text")	{	?>
		<div class="form-group">
			<label style='word-wrap: break-word;'>Цвет фона *</label>
			<div>
				<select class="form-control" id="exampleFormControlSelect1" name="bg_id"   required = "true" >
<?php
			$query = "SELECT * FROM bg WHERE 1 ORDER BY id DESC";
			$result = mysql_query($query);
			if ($result) 
				while ($mrow = mysql_fetch_array($result))
				   echo "						<option style='text-align:center' ".(($mrow['id'] == $myrow['bg_id'])?"SELECTED":"")." value=".$mrow['id'].">".$mrow['name']."</option>";
?>
				</select>
			</div>
		</div>
		<?php	}	?>
<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'slide'>".PHP_EOL;
		echo "			<input type='hidden' name='type' value = '".$type."'>".PHP_EOL;
		echo "<div class='w-100 text-center'>";
		if(!empty($id)) echo '			<input class="submit mx-auto" id="Submit" value="Сохранить изменения" type="submit" name="Submit" >'.PHP_EOL;
		else echo '			<input class="submit mx-auto" id="Submit" value="Добавить" type="submit" name="Submit" >'.PHP_EOL;
		echo "</div>".PHP_EOL;
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo "</div>".PHP_EOL;
	}

// Обновление записи
 	function update()	{
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		$post = $_POST;
		$files = $_FILES;
		// Загрузка файлов
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];
					unset($post[$var]);
			}
		}
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id'],$post['type']);
		$values = array();
		foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
		// Обновляем запись
		$query = "UPDATE slide SET ".implode(",",$values)." WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

// Добавление записи
 	function insert()	{
// echo "function insert()";
// echo "<br>";
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		$type_arr = array('image'=>1,'video'=>2,'text'=>3);
		$post = $_POST;
// echo "POST:<pre>";
// print_r ($post);
// echo "</pre>";
		
		$post['type_id'] = $type_arr[$post['type']];
		$post['user_id'] = $_SESSION['userid']; // текущий пользователь
		$files = $_FILES;
		// Загрузка файлов
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];
					unset($post[$var]);
			}
		}
			$table = $post['table'];
			
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id'],$post['type']);
			$values = "'".implode("','",array_values($post))."'";
			$keys = implode(",",array_keys($post));
// echo "keys:<pre>";
// print_r ($keys);
// echo "</pre>";
// echo "values:<pre>";
// print_r ($values);
// echo "</pre>";
			
			// Добавление записи
			$query = "INSERT INTO slide (".$keys.") VALUES (".$values.")";
			$result = mysql_query($query);
		index();
	}
	
	// Функция удаления записи
	function delete()	{	
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		$id = 		$_GET['id'];
		$query = "DELETE FROM slide WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}
	
     // Добавления записи (форма)
    function insertform($type){
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		updateform(NULL, $type);
	}

	// Функция снятия с публикации
	function setPublicOn($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE slide SET public = 1 WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

	// Функция одобрения публикации
	function setPublicOff($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE slide SET public = NULL WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

	// Функция изменения приоритета слайда на стандартный
	function setPriorityStandart($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE slide SET priority_id = 1 WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

	// Функция изменения приоритета слайда на высокий
	function setPriorityHigh($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE slide SET priority_id = 2 WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}
