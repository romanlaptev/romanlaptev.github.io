<?php
	// Вывод всех записей о пользователях в таблицу
    function index(){
		if(!is_admin())	{	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
			?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<h1 style="margin-top:68px;">Пользователи</h1>
		<table>
			<tr>
				<th></th>
				<th>№</th>
				<th>Фамилия</th>
				<th>Имя</th>
				<th>Отчество</th>
				<th>E-mail</th>
				<th>Телефон</th>
				<!-- <th>Подразделение</th> -->
				<th>Статус</th>
				<th>Одобрено</th>
			</tr>
		<?php
		$query = "SELECT id,lastname,firstname,fname,password,email, public, phone, (SELECT name FROM department WHERE id = department_id) AS department, (SELECT name FROM userstatus WHERE id = userstatus_id) AS userstatus FROM user WHERE id <> ".$_SESSION['userid']." ORDER BY id";
		$result = mysql_query($query);
		$i = 0;
		if($result)	while ($user = mysql_fetch_assoc($result)) {
				$i++;
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=user&action=delete&id=<?php echo $user['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
						</td>
						<td><?php echo $i; ?>	</td>
						<td><?php echo $user['lastname']; ?>	</td>
						<td><?php echo $user['firstname']; ?>	</td>
						<td><?php echo $user['fname']; ?>	</td>
						<td><?php echo $user['email']; ?>	</td>
						<td><?php echo $user['phone']; ?>	</td>
						<!-- <td><?php echo $user['department']; ?>	</td> -->
						<td><?php echo $user['userstatus']; ?>	</td>
						<td>
							<?php 
							if ($user['public']) 
								  echo "<a href='admin.php?table=user&action=setPublicOff&id=".$user['id']."'><img src='images/ok.png'></a>"; 
							else  echo "<a href='admin.php?table=user&action=setPublicOn&id=".$user['id']."'><img src='images/no.png'></a>"; 
							?>							
						</td>

					</tr>
				<?php	
			}
		echo "</table>";
    }

	// Удаление записи
	function delete()	{
		if(!is_admin())	{	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		$id = 		$_GET['id'];
		$query = "DELETE FROM user WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}
	
	// Функция снятия с регистрации
	function setPublicOn($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE user SET public = 1 WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

	// Функция одобрения регистарции
	function setPublicOff($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE user SET public = NULL WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

