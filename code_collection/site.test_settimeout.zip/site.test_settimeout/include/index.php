<html>
<body>
 <div align=center>
 <script>
  function Post()
   {
    document.myform.message.value = newTextArea.document.body.innerHTML;
    myform.submit();
   }
  function EditorExecCommand(command_param)
   {
    var tr = frames.newTextArea.document.selection.createRange();
    tr.select();
    tr.execCommand(command_param);
    frames.newTextArea.focus();
   }
 </script>
 <form name="myform" method="POST">
 <input type="hidden" name="message">
 </form>
 <input type="button" onClick="EditorExecCommand('Bold');" value=" B ">
 <input type="button" onClick="EditorExecCommand('Italic');" value=" I ">
 <input type="button" onClick="EditorExecCommand('Underline');" value=" U ">
 &nbsp;
 <input type="button" onClick="EditorExecCommand('JustifyLeft');" value=" Left ">
 <input type="button" onClick="EditorExecCommand('JustifyCenter');" value=" Center ">
 &nbsp;
 <input type="button" onClick="EditorExecCommand('InsertOrderedList');" value=" OL ">
 <input type="button" onClick="EditorExecCommand('InsertUnorderedList');" value=" UL ">
 <iframe width="100%" height="80%" id="newTextArea" name="newTextArea"></iframe>
 <input type="button" onClick="Post();" value="Сохранить">
 <script>
  newTextArea.document.designMode = "on";
  newTextArea.document.open();
  newTextArea.document.writeln('Текст');
  newTextArea.document.close();
 </script>
 </div>
</body>
</html>