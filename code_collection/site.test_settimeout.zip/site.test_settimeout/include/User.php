<?php
	// Вывод всех записей в панель
    function index(){
		?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<h1>Пользователи</h1>
		<center><a href='?table=user&action=insertform'>Добавить новый</a></center>
		<table>
			<tr>
				<th></th>
				<th>№</th>
				<th>Фамилия</th>
				<th>Имя</th>
				<th>Отчество</th>
				<th>E-mail</th>
				<th>Телефон</th>
				<!-- <th>Подразделение</th> -->
				<th>Статус</th>
				<th>Одобрено</th>
			</tr>
		<?php
		$query = "SELECT id,lastname,firstname,fname,password,email, public, phone, (SELECT name FROM department WHERE id = department_id) AS department, (SELECT name FROM userstatus WHERE id = userstatus_id) AS userstatus FROM user WHERE id <> ".$_SESSION['userid']." ORDER BY id";
		$result = mysql_query($query);
		$i = 0;
		if($result)	while ($user = mysql_fetch_assoc($result)) {
				$i++;
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=user&action=delete&id=<?php echo $user['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
							<a href='?table=user&action=updateform&id=<?php echo $user['id']; ?>'><img src='images/edit.png'></a>
						</td>
						<td><?php echo $i; ?>	</td>
						<td><?php echo $user['lastname']; ?>	</td>
						<td><?php echo $user['firstname']; ?>	</td>
						<td><?php echo $user['fname']; ?>	</td>
						<td><?php echo $user['email']; ?>	</td>
						<td><?php echo $user['phone']; ?>	</td>
						<!-- <td><?php echo $user['department']; ?>	</td> -->
						<td><?php echo $user['userstatus']; ?>	</td>
						<td>
							<?php 
							if ($user['public']) 
								  echo "<a href='admin.php?table=user&action=setPublicOff&id=".$user['id']."'><img src='images/ok.png'></a>"; 
							else  echo "<a href='admin.php?table=user&action=setPublicOn&id=".$user['id']."'><img src='images/no.png'></a>"; 
							?>							
						</td>
					</tr>
				<?php	
			}
		echo "</table>";
    }

    // Вывода одной записи в вид
    function view($id)	{
		$query = "SELECT id,lastname,firstname,fname,login,password,date,email,(SELECT name FROM userstatus WHERE id = userstatus_id) AS userstatus_id,(SELECT name FROM teacher WHERE id = teacher_id) AS teacher_id FROM user WHERE id=".$id;
		$result = mysql_query($query);
			if($result)
				$user = mysql_fetch_assoc($result);
			echo 'Фамилия => '.$user['lastname'].'<br>';
			echo 'Имя => '.$user['firstname'].'<br>';
			echo 'Отчество => '.$user['fname'].'<br>';
			echo 'Логин => '.$user['login'].'<br>';
			echo 'Пароль => '.$user['password'].'<br>';
			echo 'Дата => '.$user['date'].'<br>';
			echo 'E-mail => '.$user['email'].'<br>';
			echo 'userСтатус_Номер => '.$user['userstatus_id'].'<br>';
			echo 'Преподаватель => '.$user['teacher_id'].'<br>';
		
	}
 
    // Обновления записи (форма)
     function updateform($id = NULL){
		if(!empty($id))	{
			$query = "SELECT * FROM user WHERE id=".$id." ORDER BY id";
			$result = mysql_query($query);
		if($result)
			$user = mysql_fetch_assoc($result);
		}
		else {
			$fields = "id,lastname,firstname,fname,login,password,date,email,userstatus_id,teacher_id";
			foreach(explode(",",$fields) as $f) $user[$f] = '';
		}
		if(!empty($id)) echo "<h1 class='text-center' style='margin-top:60px;'>Редактирование записи № ".$id." в таблице Пользователи</h1></center>".PHP_EOL;
		else echo "<center><h1  class='text-center' style='margin-top:60px;'>Добавление записи в таблицу Пользователи</h1></center>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">'.PHP_EOL;
		echo '			<a href="office.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?table=user' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL;
		?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Фамилия</label>
			<div>
				<input class='form-control' id='lastname' name='lastname' type='text' value='<?php echo $user['lastname']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Имя</label>
			<div>
				<input class='form-control' id='firstname' name='firstname' type='text' value='<?php echo $user['firstname']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Отчество</label>
			<div>
				<input class='form-control' id='fname' name='fname' type='text' value='<?php echo $user['fname']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>E-mail</label>
			<div>
				<input class='form-control' id='email' name='email' type='text' value='<?php echo $user['email']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Телефон</label>
			<div>
				<input class='form-control' id='phone' name='phone' type='text' value='<?php echo $user['phone']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Статус</label>
			<div>
			<select class="form-control"  id="userstatus_id"  name="userstatus_id">
				<?php
				$query = "SELECT id,name FROM userstatus WHERE 1 ORDER By name"; 
				$result = mysql_query($query); 
				while ($option = mysql_fetch_assoc($result)) 
					echo '<option value="'.$option['id'].'" '.is_sel($option['id'],$user['userstatus_id']).'>'.$option['name'].'</option>';
				?>
			</select>
			</div>
		</div>
<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'user'>".PHP_EOL;
		if(!empty($id)) echo '			<div class="text-center"><input class="submit" id="Submit" value="Сохранить изменения" type="submit" name="Submit" ></div>'.PHP_EOL;
		else echo '			<div class="text-center"><input class="submit" id="Submit" value="Добавить" type="submit" name="Submit" ></div>'.PHP_EOL;
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo "</div>".PHP_EOL;
	}

	function insertform()	{
		updateform();
	}

// Обновление записи
 	function update()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id']);
			$values = array();
			foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
			$query = "UPDATE user SET ".implode(",",$values)." WHERE id=".$id;
			$result = mysql_query($query);
			index();
	}

// Добавление записи
 	function insert()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id']);
			$values = "'".implode("','",array_values($post))."'";
			$keys = implode(",",array_keys($post));
			$query = "INSERT INTO user (".$keys.") VALUES (".$values.")";
			$result = mysql_query($query);
			index();
	}
	
	// Удаление записи
	function delete()	{
		if(!is_admin())	{	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		$id = 		$_GET['id'];
		$query = "DELETE FROM user WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}
	
	// Функция снятия с регистрации
	function setPublicOn($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE user SET public = 1 WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

	// Функция одобрения регистарции
	function setPublicOff($id)	{ 
		if(!((is_user())||(is_admin()))) {	echo "<h3 class='text-center text-danger' style='margin-top:68px;'>Нет доступа!</h3>"; return; }
		if(empty($id)) $id = $_GET['id'];
		$query = "UPDATE user SET public = NULL WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}

