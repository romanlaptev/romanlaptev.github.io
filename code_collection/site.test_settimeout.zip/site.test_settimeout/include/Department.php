<?php
	// Вывод всех записей в панель
    function index(){
		?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<h1>Подразделения</h1>
		<center><a href='?table=department&action=insertform'>Добавить новый</a></center>
		<table>
			<tr>
				<th></th>
				<th>Номер</th>
				<th>Наименование</th>
			</tr>
		<?php
		$query = "SELECT id,name FROM department WHERE 1 ORDER BY id";
		$result = mysql_query($query);
		if($result)	while ($department = mysql_fetch_assoc($result)) {
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=department&action=delete&id=<?php echo $department['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
							<a href='?table=department&action=updateform&id=<?php echo $department['id']; ?>'><img src='images/edit.png'></a>
						</td>
						<td><?php echo $department['id']; ?>	</td>
						<td><?php echo $department['name']; ?>	</td>
					</tr>
				<?php	
			}
		echo "</table>";
    }

    // Вывода одной записи в вид
    function view($id)	{
		$query = "SELECT id,name FROM department WHERE id=".$id;
		$result = mysql_query($query);
			if($result)
				$department = mysql_fetch_assoc($result);
			echo '<h1>'.$department['name'].'</h1><br>';
		
	}
 
    // Обновления записи (форма)
     function updateform($id = NULL){
		if(!empty($id))	{
			$query = "SELECT * FROM department WHERE id=".$id." ORDER BY id";
			$result = mysql_query($query);
		if($result)
			$department = mysql_fetch_assoc($result);
		}
		else {
			$fields = "id,name";
			foreach(explode(",",$fields) as $f) $department[$f] = '';
		}
		if(!empty($id)) echo "<center><h1 style='margin-top:60px;'>Редактирование записи № ".$id." в таблице Подразделения</h1></center>".PHP_EOL;
		else echo "<center><h1 style='margin-top:60px;'>Добавление записи в таблицу Подразделения</h1></center>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">'.PHP_EOL;
		echo '			<a href="office.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?table=department' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL;
		?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Наименование</label>
			<div>
				<input class='form-control' id='name' name='name' type='text' value='<?php echo $department['name']; ?>'/>
			</div>
		</div>

<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'department'>".PHP_EOL;
		if(!empty($id)) echo '			<div class="text-center"><input class="submit" id="Submit" value="Сохранить изменения" type="submit" name="Submit" ></div>'.PHP_EOL;
		else echo '			<div class="text-center"><input class="submit" id="Submit" value="Добавить" type="submit" name="Submit" ></div>'.PHP_EOL;
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo "</div>".PHP_EOL;
	}

// Обновление записи
 	function update()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id']);
			$values = array();
			foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
			$query = "UPDATE department SET ".implode(",",$values)." WHERE id=".$id;
			$result = mysql_query($query);
			index();
	}

// Добавление записи
 	function insert()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$uploadfile  = $uploaddir . basename($files[$ki]['name']);
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id']);
			$values = "'".implode("','",array_values($post))."'";
			$keys = implode(",",array_keys($post));
			$query = "INSERT INTO department (".$keys.") VALUES (".$values.")";
			$result = mysql_query($query);
			index();
	}
	
	function delete()	{
		$id = 		$_GET['id'];
		$query = "DELETE FROM department WHERE id=".$id;
		$result = mysql_query($query);
		index();
	}
	
     // Добавления записи (форма)
    function insertform(){
		updateform();
	}

