				<?php 
				include_once("open_db.php");	// Файл подключения к базе данных
				include_once("functions.php");	// Файл подключения функции
				include_once("login.php");		// Файл авторизации
				include_once("register.php");	// Файл регистрации
				include_once("user.php");		// Файл функций, относящихся к пользователям	
				$rlaction  = $_REQUEST['rlaction' ];	// название функции по авторизации и регистрации
				$rlvalue 	 = $_REQUEST['rlvalue'];		// аргумент функции по авторизации и регистрации
				if((!empty($rlaction))&&(function_exists($rlaction))) $rlaction($rlvalue); 
				if(!empty($_SESSION['error'])) {	// если есть ошибка, выводим ее
					echo "<div class='w-100 top bottom'>";
					echo '<div class="text-center text-danger">'.$_SESSION['error'].'</div>';
					unset($_SESSION['error']);
					echo "</div>";
				}
				if(!empty($_SESSION['success'])) {	// если есть сообщение об успешной авторизации, выводим
					echo "<div class='w-100 top bottom'>";
					echo '<div class="text-center text-success">'.$_SESSION['success'].'</div>';
					unset($_SESSION['success']);
					echo "</div>";
				}
				if(is_admin())		$diary_name = "Личный кабинет администратора ".$_SESSION['userName'];
				if(is_user())		$diary_name = "Личный кабинет пользователя ".$_SESSION['userName'];
				?>
    <header>
	
        <!-- ===========================
         Меню начало
         =========================== -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                           <span class="sr-only">Меню</span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                        </button>

                    <a class="navbar-brand" href="admin.php">
                        <span class="brandicon icon-grid"></span>
                        <span class="brandname"><?php echo $diary_name;?></span>
                    </a>
                </div>

                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php"><span class="btnicon icon-home"></span>Главная</a></li>
						<?php
						if (is_admin()) {  	// если текущий пользователь - администратор
	                        echo '<li><a href="admin.php?table=slide"><span class="btnicon icon-calendar"></span>Слайды</a></li>';
	                        echo '<li><a href="admin.php?table=user"><span class="btnicon icon-users"></span>Пользователи</a></li>';
	                        echo '<li><a href="admin.php?table=department"><span class="btnicon icon-map"></span>Подразделения</a></li>';
	                        echo '<li><a href="admin.php?table=bg"><span class="btnicon icon-map"></span>Фоны</a></li>';
						}
						if (is_user()) {  // если текущий пользователь - студент
	                        echo '<li><a href="admin.php?table=slide"><span class="btnicon icon-calendar"></span>Мои слайды</a></li>';
						}
						?>
						<?php login_registr(); // Функция авторизации и регистрации } ?>
                   </ul>
                </div>
            </div>
        </nav>
        <!-- конец меню -->
    </header>
