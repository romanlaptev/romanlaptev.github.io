<?php
// echo "<pre>";
// print_r ($_REQUEST);
// print_r ($_SERVER);
// echo "</pre>";
// error_reporting(E_ALL|E_STRICT);
// ini_set('display_errors', 1);

			include("open_db.php");		// Подключение базы данных
			include("functions.php");		// Подключение функций
			
			// определение номера текущего слайда
			if( !empty($_REQUEST["num_slide"]) ){
				$num_slide = $_REQUEST["num_slide"];
			} else {
				$num_slide = 0;
			}
			
			// получение общего кол-ва слайдов
			if( !empty($_REQUEST["num_slides_total"]) ){
				$num_slides_total = $_REQUEST["num_slides_total"];
			} else {
				$num_slides_total = getNumSlidesTotal();
			}
			
			// определение номера предыдущего слайда
			$num_prev_slide = $num_slide -1;
			if( $num_prev_slide < 0){
				$num_prev_slide = $num_slides_total - 1;
			}
					
			// определение номера следующего слайда
			$num_next_slide = $num_slide +1;
			if( $num_next_slide >= $num_slides_total){
				$num_next_slide = 0;
			}
			
			$num_slides = 1; // кол-во отображаемых слайдов
$query = "SELECT S.*, ST.name AS type, priority_id FROM slide AS S, type AS ST WHERE (S.type_id = ST.id) AND (starttime <= now()) AND (endtime >= now()) AND (public = 1) ORDER BY id LIMIT ".$num_slide.", ".$num_slides;
// echo "SQL:".$query;
// echo "<br>";

			$result = mysql_query($query);
			
			$slides = array();
			if(isset($_GET['department'])) $d = (int)$_GET['department'];	
			if ($result) 
				while($slide = mysql_fetch_assoc($result)) {
// echo "<pre>";
// print_r($slide);
// echo "</pre>";
					if(!empty($d))	{
						if($slide['department_id'] == $d)
							$slides[] = $slide;
					}
					else $slides[] = $slide;
				}
				$slides = setPriority($slides);
?>

<?php				
			if(sizeof($slides) > 0)	{
?>
<!DOCTYPE html>
<html lang="ru" >

<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Информационный слайдер</title>


<!-- редирект на следующий слайд -->
<?php 
$pause = 3;//длительность просмотра по умолчанию, сек.
if( !empty($slides[0]["playtime"]) ){
	$pause = $slides[0]["playtime"];
// echo "Pause: ".$pause;
// echo "<br>";
// exit();
}
//echo "<meta http-equiv='refresh' content='".$pause.";url=?num_slide=".$num_next_slide."'/>";
?>

<!-- Подключение стилей -->  
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>
<link rel='stylesheet' href='http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/slider.css">
</head>

<body>

  <!-- Блок слайдера -->
  <div style="margin-top:-20px;" id="myCarousel" class="carousel slide">
	  
 	  
        <!-- Индикаторы -->
        <ol class="carousel-indicators">
<?php
/*
			if(sizeof($slides) > 0)
			foreach($slides as $k=>$v)	
				echo '				<li data-target="#myCarousel" data-slide-to="'.$k.'"'.(($k==0)?'class="active"':'').'></li>'.PHP_EOL;
*/
			if( sizeof($slides) > 0 ){
				for( $n = 0; $n < $num_slides_total; $n++){
					if( $n == $num_slide ){
$indicator = "<li data-target='#myCarousel' data-slide-to='".$n."' class='active'></li>";
					} else {
$indicator = "<li data-target='#myCarousel' data-slide-to='".$n."'></li>";
					}
$link = "<a href='?num_slide=".$n."' >".$indicator."</a>";
					echo $link;
				}	
			}
?>
        </ol>

		<!-- Обложка для слайдов -->
		<div class="carousel-inner">
<?php  	if(sizeof($slides) > 0) foreach($slides as $k=>$s)	{ ?>
			<div class="item <?php echo (($k==0)?'active':'');?>">
<?php 			
if($s['type'] == 'image') {
	echo getImageSlide($s); // если тип слайда - картинка 
	echo "<script>
console.log('Pause: ".$pause."');
	setTimeout(function(e){
		var url = '?num_slide=".$num_next_slide."';
		window.location = url;
	}, ".$pause."*1000);
</script>
";	
}	

if($s['type'] == 'text')  {
	echo getTextSlide($s);  // если тип слайда - текст 	
	echo "<script>
console.log('Pause: ".$pause."');
	setTimeout(function(e){
		var url = '?num_slide=".$num_next_slide."';
		window.location = url;
	}, ".$pause."*1000);
</script>
";	
}

if($s['type'] == 'video') {
	echo getVideoSlide($s); // если тип слайда - видео 
echo "<script>
	var timeCounter = document.querySelector('#time-play-video');
	var _timer = 0;
	var timerId = setInterval(function() {
		_timer++;
		var msg = _timer + ' sec.';
console.log( 'time paying video: ' + msg);
		timeCounter.innerHTML = msg;
	}, 1000);
	
	var player = document.querySelector('#player1');
	player.onended = function(e){
		 clearInterval( timerId );
		var url = '?num_slide=".$num_next_slide."';
		window.location = url;
	}//end event	
</script>
";	
}
?>
            </div>
<?php 	}	?>
        </div>
        <!-- Controls -->
<!--		
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
-->
<?php
echo '
		<a class="left carousel-control" href="?num_slide='.$num_prev_slide.'" data-slide="prev">
			<span class="icon-prev"></span>
		</a>
		<a class="right carousel-control" href="?num_slide='.$num_next_slide.'" data-slide="next">
			<span class="icon-next"></span>
		</a>
';
?>

    </div>
<?php } 
	else {
		echo "<h1 class='text-center'>Нет данных для показа для данного подразделения</h1>";
	}
	
	
	// sleep(3);
	// $redirect_url = $_SERVER["SCRIPT_NAME"]."?num_slide=".$num_next_slide;
	// $redirect_script = "<script>window.location=".$redirect_url.";</script>";
	// echo $redirect_script;
	//header("Location: ".$redirect);
	?>
<!-- Подключение скриптов -->
<!--
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>
-->

<!-- Автозапуск слайдера -->
<script>
// $('.carousel').carousel({
 //interval: 4000,
 //})
 
 // if( document.querySelector("#player1") ){
// document.querySelector("#player1").play();
// }
 </script> 

</body>
</html>

<?php
function getImageSlide($s)	{	// Функция вывода слайдера-картинки
?>
                <div class="fill">
					<img src="<?php echo $s['image']; ?>">
					<div class="carousel-caption">
						 <!-- <h2 class="animated fadeInLeft"><?php echo $s['header']; ?></h2> -->
						 <h3 class="animated fadeInUp"><?php echo $s['text']; ?></h3>
						 <!-- <p class="animated fadeInUp"><a href="<?php // echo $s['url']; ?>" class="btn btn-transparent btn-rounded btn-large">Узнать больше...</a></p> -->
					</div>
				</div>
<?php
}
?>

<?php
function getVideoSlide($s)	{	// Функция вывода слайдера-видео
?>
                <div class="fill">
<!--				
					<iframe src="<?php echo $s['url']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
-->

<!--				
<iframe name="videoplayer" id="video-player" width="100%" frameborder="0"
src="<?php echo $s['image']; ?>"  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
-->
<video id="player1" width="100%" controls="controls" autoplay>
	<source  src='<?php echo $s['image']; ?>'/>
Tag <b>video</b> not support by this browser.... 
</video>
<p id="time-play-video" class="mark"></p>
				</div>
<?php
}
?>

<?php
function getTextSlide($s)	{	// Функция вывода слайдера-текста
?>
                <div style="background-color:<?php echo $s['bg']; ?>" class="fill <?php echo $s['class']; ?>"></div>
                <div class="carousel-caption">
                     <!-- <h2 class="animated fadeInLeft"><?php echo $s['header']; ?></h2> -->
                     <h3 class="animated fadeInUp"><?php echo $s['text']; ?></h3>
                     <!-- <p class="animated fadeInUp"><a href="<?php echo $s['url']; ?>" class="btn btn-transparent btn-rounded btn-large">Узнать больше...</a></p> -->
                </div>
<?php
}

function setPriority($slides)	{	// Расстановка слайдов по приоритету
	$high = array();
	foreach($slides as $slide) if($slide['priority_id'] == 2) $high[] = $slide;
		$newslides = $high;
		foreach($slides as $slide) {
			if($slide['priority_id'] == 1)	{
				$newslides[] = $slide;
				$newslides = array_merge($newslides,$high);
			}
		}

	$first = reset($newslides);
	$last  = end($newslides);
	if(($first['id'] == $last['id'])&&(sizeof($newslides)>1)) unset($newslides[0]);
	$nslides = array();
	foreach($newslides as $slide) $nslides[] = $slide;
	return $nslides;
}


function getNumSlidesTotal(){ // получение общего кол-ва слайдов
	$query = "SELECT count(id) AS num FROM slide WHERE (starttime <= now()) AND (endtime >= now()) AND (public = 1)";
	$res = mysql_query($query);
	for( $n = 0; $n < mysql_num_rows ($res); $n++){
		$row = mysql_fetch_array($res);
		return $row["num"];
	}
}

?>
