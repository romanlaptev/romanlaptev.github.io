<?php
    $HOST_DB 		= "localhost";	// Имя хоста
    $USER_DB 		= "root";		// Имя пользователя БД
    $PASSWORD_DB 	= "";			// Пароль пользователя БД	
    $NAME_DB	    = "slider";	// Имя БД
    $db = mysql_connect ($HOST_DB,$USER_DB,$PASSWORD_DB);		// Подключение к базе данных
	if (!mysql_select_db ($NAME_DB,$db)) init($NAME_DB);
        // echo ("<p>Ошибка подключения базы данных: ".mysql_error().PHP_EOL."<a href='init.php'>Исправить</a></p>");
	mysql_query("SET NAMES utf8;");
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET SESSION collation_connection = utf8_general_ci");
	mysql_query("SET lc_time_names = 'ru_RU'");
	
	function init($base)	{
			echo '<br><br><br><a href="admin.php">Вернуться на сайт</a><br>';
			$HOST_DB 		= "localhost";	// Имя хоста
			$USER_DB 		= "root";		// Имя пользователя БД
			$PASSWORD_DB 	= "";			// Пароль пользователя БД	
			$db = mysql_connect ($HOST_DB,$USER_DB,$PASSWORD_DB);		//запрос к базе данных
			
mysql_set_charset("utf8", $db);

		if (mysql_query("CREATE DATABASE IF NOT EXISTS `$base`")) {
				echo  ("<p>База данных успешно создана!".PHP_EOL."</p>");
			} else {
				echo  ("<p>Ошибка создания базы данных: ".mysql_error().PHP_EOL."</p>");
			}

		if (mysql_query("USE `$base`")) {
				echo ("<p>База данных успешно подключена!".PHP_EOL."</p>");
			} else {
				echo ("<p>Ошибка подключения базы данных: ".mysql_error().PHP_EOL."</p>");
			}

		$f = file_get_contents("_BASE/".$base.".sql");
		$tables = explode("\n\n",$f);
		foreach($tables as $table) {
			if (substr($table,0,3)<>"===") echo $table.PHP_EOL;
			$result = mysql_query($table);

			if ($result) {
				echo ("<p style='color:green;font-weight:bold;'>Запрос успешно выполнен!".PHP_EOL."</p>");
			} elseif (substr($table,0,3)<>"===") {
				echo ("<p>Ошибка запроса: ".mysql_error().PHP_EOL."</p>");
			}
			echo "<hr>";
		}
	}
?>
