<?php

function pr($value)	{				// Функция для вывода массива или значения
	echo "<pre>";
	if(gettype($value) == 'array')	print_r($value); else { echo ($value); echo "<hr>"; }
	echo "</pre>";
}

function is_sel($a, $b)
{
  if((gettype($b) == "array")&&(in_array($a,$b)))  return 'selected="selected"';	
  elseif($a == $b) return 'selected="selected"';
  elseif(in_array($a,explode(",",$b))) return 'selected="selected"';
  else return '';
}

function is_sel_arr($a, $b)
{
  if(in_array($a, explode(',', $b))) return 'selected="selected"';
}


?>
