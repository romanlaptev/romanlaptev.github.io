<?php
// =============== ПОЛЬЗОВАТЕЛИ ==================

function userID($user)	{					// Возвращает код пользователя по логину
	$query = "SELECT * FROM user WHERE email='".$user."'";
	$result = mysql_query($query);
	if ($result) {
		$myrow = mysql_fetch_array($result); 
		return $myrow['ID'];
	}
}

function userName($user) {					// Возвращает логин пользователя по его коду
	$query = "SELECT * FROM user WHERE ID='".$user."'";
	$result = mysql_query($query);
	if ($result) {
		$myrow = mysql_fetch_array($result); 
		return $myrow['email'];
	}
	return '';
}


function is_admin() { 						// Функция проверки пользователя на статус администратора
	$flag = false;
	$user=$_SESSION['userName']; 
	if(empty($user)) $user = $_SESSION['email'];
	if (!empty($user)) {
		$query = "SELECT * FROM user WHERE email='".$user."'";
		$result = mysql_query($query); 
		if (!$result) return false;
		$myrow  = mysql_fetch_assoc($result); 
		if ($myrow['userstatus_id']=='1') $flag = true;
	}
	return $flag;	  
}

function is_user() { 						// Функция проверки пользователя на статус пользователя
	$flag = false;
	$user=$_SESSION['userName']; 
	if(empty($user)) $user = $_SESSION['email'];
	if (!empty($user)) {
		$query = "SELECT * FROM user WHERE email='".$user."'";
		$result = mysql_query($query); 
		if (!$result) return false;
		$myrow  = mysql_fetch_assoc($result); 
		if ($myrow['userstatus_id']=='2') $flag = true;
	}
	return $flag;	  
}

