FireRainbow
===========

FireRainbow brings javascript syntax highlighting to Firebug

<a href="http://firerainbow.binaryage.com"><img src="http://firerainbow.binaryage.com/shared/img/firerainbow-mainshot.png"></a>

Visit [firerainbow.binaryage.com](http://firerainbow.binaryage.com)
----------


