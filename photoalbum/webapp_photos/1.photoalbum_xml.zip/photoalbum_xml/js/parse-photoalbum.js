//var a = 1;
var delimiter = " > ";
//var breadcrumbs = new Array("главная");
var node_per_page = 5;

//--- определить расположение файлов фотографий
	var test_url = window.location.href;
//console.log('test_url = ' + test_url);

	var strpos = test_url.indexOf("http://mycomp"); 
	if ( strpos !=-1 ) 
	{ 
//console.log('strpos = ' + strpos);
		var content_location = "";
	}
	else
		var content_location = "https://googledrive.com/host/0B0l5s_9HQLzzTnpfZDJGcUp5UUk/"; //google drive site, /photos
		//var content_location = "https://googledrive.com/host/0B0l5s_9HQLzzcms4SWpETElFNDg/";
		//var content_location = "../../..";
//console.log('content_location = ' + content_location);
//https://googledrive.com/host/0B0l5s_9HQLzzcms4SWpETElFNDg/photoalbum/imagecache/photo_preview/1983-85_dikson_photo26_admin_building.jpg

/*
	var strpos = test_url.indexOf("https://googledrive.com"); 
	if ( strpos !=-1 ) 
	{ 
console.log('strpos = ' + strpos);
		var content_location = "../..";
//var content_location = "https://googledrive.com/host/0B0l5s_9HQLzzMW9KU05WZFhNRGs";
	}
*/
//-----------------------------------------


	function load_xml(xml_file)
	{
//console.log('load - '+xml_file);
		
		$.get(xml_file,function(data)
		{
//x = data.documentElement.childNodes;
//document.write("Number of elements: " + x.length);
//document.write("<br>");

			var html = "";
			$(data).find('termin').each(function()
				{
					var termin = $(this);
					if (termin.attr('parent') == '0')
					{
						html += "<ul class='main-termin'>";
						html += "<li id='termin-"+ termin.attr('tid') +"' class='termin parent-" + termin.attr('parent') + "'>";
						var termin_name = termin.children('term_name');
						if (termin_name.length)
						{
							html += "<p>" + termin_name.text() + "</p>";
						}
					
	//console.log('termin.children.length = ' + termin.children('termin').length);
						if (termin.children('termin').length > 0)
						{
							html += "<div>";
							html += get_child_termins(data, termin.attr('tid')); //получить дочернии термины
							html += "</div>";
						}
					
						html += "</li>";
						html += "</ul>";
					}//------------------------------------- end if
				
				}//---------------------------------- end func
			);//----------------------------------- end each
			
			$('#taxonomy_vocabulary').empty();
			$('#taxonomy_vocabulary').append(html);
//window.b = 4;
			window.xml_data = data; //определить глобальную переменную с xml-данными для дальнейш. использования
		}//-------------------------------- end func
		);//---------------------------------- end get
		
	}

function get_child_termins(data, parent_tid)
{
//console.log('function get_child_termins('+ parent_tid +')');
//-------------------------------------------------------------
	window.scroll (0,0);
//-------------------------------------------------------------
	var html_termins = "";
	$(data).find('termin').each(
		function()
		{
			var termin = $(this);
			if (termin.attr('parent') == parent_tid)
			{
//console.log('termin tid = ' + termin.attr('tid'));
				html_termins += "<li class='termin parent-" + termin.attr('parent') + "'>";

				var termin_name = termin.children('term_name');
				if (termin_name.length)
				{
					html_termins += "<a href='view_termin.html?tid="+termin.attr('tid')+"' id='url-"+termin.attr('tid')+"' onClick='view_termin(this);return false;'>" + termin_name.text() + "</a>";
				}

//console.log('termin.children.length = ' + termin.children('termin').length);

				if (termin.children('termin').length > 0)
				{
					html_termins += get_child_termins(data, termin.attr('tid')); //получить дочернии термины
				}

				html_termins += "</li>";
			}//------------------------------------- end if

		}//---------------------------------- end func
	);//----------------------------------- end each

//console.log ('html_termins length = ' + html_termins.length);
//console.log ('html_termins = ' + html_termins);
	if (html_termins.length > 0)
	{
		var html = "<ul class='child-termins'>";
		html += html_termins;
		html += "</ul>";
	}
	else
	{
		var html = "";
	}//------------------------------------- end if

	return html;	
}//-------------------------------- end func

//-----------------------------------------
//получить get-параметры из href ссылки
//-----------------------------------------
function getenv(href,name_var)
 {
	if (!href.length) 
		return false; 

	if (!name_var.length) 
		return false; 

	strpos = href.indexOf("?"+ name_var +"=");
	if (strpos ==-1) 
	{ 
		strpos = href.indexOf("&"+ name_var +"="); 
	}

	if ( strpos == href.length || strpos ==-1 )
	{
		return false; 
	}

	val = href.substring( (strpos + name_var.length) + 2, href.length);

	strpos = val.indexOf("&");
	if ( strpos !=-1 ) 
	{ 
		val = val.substring(0, strpos ); 
	}

	if ( !val.length ) 
	{ 
		return false; 
	}
	else 
	{ 
		return val; 
	}
}

function view_termin(link)
{
//alert('a = ' + a);
//alert('xml_data = ' + xml_data);

	var html = "";

	//------------------------------- получить get-параметры из href ссылки
	//var tid = $(link).attr('id').replace("url-","");
	//var tid = $(link).attr('href').replace("view_termin.html?tid=","");

	var tid = getenv($(link).attr('href'),"tid");	
//console.log('tid = ' + tid);

	var num_page = getenv($(link).attr('href'),"num_page");
//console.log('num_page = ' + num_page);
	//-------------------------------

	html += get_child_termins(xml_data, tid); //получить дочернии термины
	if (num_page)
	{
		html += get_nodes(xml_data, tid, num_page); //получить ноды термина постранично
	}
	else
		html += get_nodes(xml_data, tid, 0); //получить все ноды термина

	$('#taxonomy_vocabulary').hide();
	//$('#nodes').empty();
	//$('#nodes').append(html);
	//$('#nodes').text(html);
	$('#nodes').html(html);
	$('#nodes').show();

//--------------------------------- breadcrumbs
	var breadcrumbs = new Array("главная");
	$(xml_data).find('termin').each(
		function()
		{
			var termin = $(this);
			if (termin.attr('tid') == tid)
			{
				var termin_name = termin.children('term_name').text();
				breadcrumbs.push (termin_name);
				//html_breadcrumbs += delimiter + termin_name;
			}//------------------------------------- end if
		}
	);//----------------------------------- end each


	var html_breadcrumbs = "";
	for (n1=0; n1 < breadcrumbs.length; n1++)
	{
		if (n1==0)
		{
			html_breadcrumbs += "<a href='#' class='home'>" + breadcrumbs[n1] + "</a>";
		}
		else
			html_breadcrumbs += delimiter + breadcrumbs[n1];
	}
	$('#breadcrumbs').html(html_breadcrumbs);
//--------------------------------------
	$('#info').show();

}//------------------------------------------- end func

function get_nodes(xml_data,tid, num_page)
{
	var html = "<div class='related-nodes'>";
	var node_count=0;
	var photos_count=0;
//---------------------------------
var start_pos = (num_page*node_per_page)+1;
/*
(0*5)+1=1
(1*5)+1=6
(2*5)+1=11
(3*5)+1=16
(4*5)+1=21
*/
//console.log('start_pos = ' + start_pos);

//var end_pos = (num_page+1) * node_per_page; 
var end_pos = (start_pos + node_per_page)-1;
/*
(0+1)*5=5
(1+1)*5=10
(2+1)*5=15
(3+1)*5=20
(4+1)*5=25
*/
//console.log('end_pos = ' + end_pos);
//---------------------------------

	$(xml_data).find('node').each(
		function()
		{
			var node = $(this);
//console.log('nid = ' + node.attr('nid'));
			var term_node = node.children('term_node');
			
//console.log('length term_node= ' + term_node.length);
//console.log('tid = ' + term_node.eq(0).attr('tid'));
//console.log('text = ' + term_node.eq(0).text());
			var view_node = 0;
			//поиск совпадения среди терминов ноды
			for (n1=0; n1 < term_node.length; n1++)
			{
				if (term_node.eq(n1).attr('tid') == tid)
				{
					view_node = 1;
				}
			}
			
			if (view_node == 1)
			{
				node_count++;

				var photos = node.children('photos').children('photo');
				var photos_length = photos.length;
				var filename = photos.eq(0).children('filename').text();
				if ( photos.length == 0 )
				{
					var files = get_photos( node.attr('nid') );
					var photos_length = files.length;
					var filename = files[0];
				}
				photos_count = photos_count + photos_length;

//console.log('2.start_pos = ' + start_pos);
//console.log('2.end_pos = ' + end_pos);

if (node_count >= start_pos)
{
	if (node_count <= end_pos)
	{
//console.log('node count = ' + node_count);
				html += "<div class='node' id='nid-" + node.attr('nid') + "'>";
				html += "	<b>альбом " + node_count + "</b> ";
				
				html += "	<a href='get_node.html?nid=" + node.attr('nid') + "' onClick='get_node(this,"+tid+");return false;'>";
				html += "		<h2>" + node.attr('title') + "</h2> ";
				html += "	</a>";
				
				html += get_related_termins(term_node,tid);

				html += "	<div class='photo' id='photo-nid-" + node.attr('nid') + "'>";

				var paths = get_paths_photo( node.attr('nid') );
				var preview_img = paths[ "preview_img" ];
				var big_img = paths[ "big_img" ];
				var original_img = paths[ "original_img" ];

html += "<a href='get_node.html?nid=" + node.attr('nid') + 
"' onClick='get_node(this," + tid + ");return false;' title='" + node.attr('title') + "'>";
html += "<img src='" + content_location + preview_img + "/" + filename + "' alt='" + node.attr('title') + "'>";
html += "</a>";

				html += "	</div>";
				html += "	<div style='clear:both'></div>";
				html += "	<p>всего фото: " + photos_length + "</p>";
				html += "</div>";

	}//----------------------- end if pager end
}//----------------------- end if pager start

			}
			
		}//---------------------------------- end func
	);//----------------------------------- end each

	$('#nodes-count').html(node_count);
	$('#photos-count').html(photos_count);

//----------------------------- pager
	if (node_count > node_per_page)
	{
//console.log ("2.node_count - " + node_count);
//console.log ("2.node_per_page - " + node_per_page);
//console.log ("2.num_page - " + num_page);
		html += get_pager(node_count,tid,num_page);
	}
//-----------------------------------
	html += "</div>";
	
	return html;	
}//------------------------------------------- end func

function get_related_termins(term_node,tid)
{
	var html = "";
	html += "<div class='related_termins term-node'>";
	html += "<span class='tag-label'>метки:</span><ul>";
	
	for (n1=0; n1 < term_node.length; n1++)
	{
		if (term_node.eq(n1).attr('tid') == tid)
		{
			var term_name = "<b>" + term_node.eq(n1).text() + "</b>";
		}
		else
			var term_name = term_node.eq(n1).text();

		html += "<li><a href='view_termin.html?tid="+term_node.eq(n1).attr('tid')+"' onClick='view_termin(this);return false;'>" + term_name + "</a></li>";
	}
	
	html += "</ul>";
	html += "</div>";
	return html;	
}//------------------------------------------- end func

function get_node(link,tid)
{
	var nid = $(link).attr('href').replace("get_node.html?nid=","");
//console.log('function get_node(),' + nid);
//console.log('xml_data = ' + xml_data);
//console.log('tid = ' + tid);

	var html = "";
	$(xml_data).find('node').each(
		function()
		{
			var node = $(this);
			if (node.attr('nid') == nid)
			{
				html += '<h2>' + node.attr('title') + '</h2>';

				var term_node = node.children('term_node');
				html += get_related_termins(term_node,tid);

				var photos = node.children('photos').children('photo');
				var photos_length = photos.length;
				if ( photos.length == 0 )
				{
					var files = get_photos( node.attr('nid') );
					var photos_length = files.length;
				}

				html += "<p>всего фото: " + photos_length + "</p>";
				for (n1=0; n1 < photos_length; n1++)
				{
					html += "<div class='photo' id='photo-nid-" + node.attr('nid') + "'>";
					if ( photos.length == 0 )
					{
						var filename = files[n1];
					}
					else
					{
						var filename = photos.eq(n1).children('filename').text();
					}

					var paths = get_paths_photo( node.attr('nid') );
					var preview_img = paths[ "preview_img" ];
					var big_img = paths[ "big_img" ];
					var original_img = paths[ "original_img" ];

//html += "<a href='#' onClick='' title='" + node.attr('title') + "'>";
//html += "<img src='" + content_location + preview_img + "/" + filename + "' alt='" + node.attr('title') + "'>";
//html += "</a>";

html += "<a href='" + content_location + big_img + "/" + filename + "' onClick='' title='" + node.attr('title') + "' ";
html += "class='pirobox'>";
html += "<img src='" + content_location + preview_img + "/" + filename + "' alt='" + node.attr('title') + "'>";
html += "</a>";
html += "<p class='resize'>";
html += "<a target='_blank' href='" + content_location + original_img + "/" + filename + "'>полный размер</a>";
html += "</p>";
					html += "</div>";
				}
				
			}//---------------------------------- end if
			
		}//---------------------------------- end func
	);//----------------------------------- end each

			
	$('#nodes').html(html);
	$('#nodes').show();

	jQuery().piroBox({
		my_speed: 300, //animation speed
		bg_alpha: 0.1, 
		slideShow : true,
		slideSpeed : 6, 
		close_all : ".piro_close,.piro_overlay" 
	});

}//------------------------------------------- end func


function get_pager(all_node_count,tid,num_page)
{
	var num_pages = Math.ceil(all_node_count / node_per_page);
//console.log ('num_pages = ' + num_pages);
//console.log ('num_page = ' + num_page);
 
	var html_pager = "";
	for (n1=0; n1 < num_pages; n1++)
	{
		var view_num_page = n1+1;
		if (n1==num_page)
		{
			html_pager += "<li><b>" + view_num_page +"</b></li>";
		}
		else
		{
html_pager += "<li><a href='view_termin.html?tid="+tid+"&num_page="+n1+"' onClick='view_termin(this);return false;'>" + view_num_page +"</a></li>";
		}
	}

//console.log ('html_pager.length = ' + html_pager.length);
	if (html_pager.length > 0)
	{
		var html = "<div class='pager'>";
		html += "	<ul>";
		html += "<b>страница: </b>";
		html += html_pager;
		html += "	</ul>";
		html += "</div>";
	}
	else
	{
		var html = "";
	}

	return html;	
}//------------------------------------------- end func


function get_paths_photo ( nid )
{
	var paths={};
	$(xml_data).find('paths').each(
		function()
		{
			if ( $(this).attr('nid') == nid)
			{
				paths["preview_img"] = $(this).children('preview_img').text();
				paths["big_img"] = $(this).children('big_img').text();
				paths["original_img"] = $(this).children('original_img').text();
			}
		}//----------- end func
	);//------------------ end each

	return paths ;
}//----------- end func

function get_photos ( nid )
{
	var files= new Array();
	$(xml_data).find('filename_photo').each(
		function()
		{
			if ( $(this).attr('nid') == nid)
			{
				files.push ( $(this).attr('value') );
			}
		}//----------- end func
	);//------------------ end each

	return files;
}//----------- end func


