(function($){
    $(function() {
       
		$(".scroll-to").on("click", function(){
			$('body').scrollTo( $(this).attr("href"), 800, {offset: -50});
			//window.scrollTo(0, 0);
			return false;
		});

		$(window).scroll(function() {
			if ($(this).scrollTop() > 100) {
				$('.to-top').show();
			} else {
				$('.to-top').hide();
			}
		});

		$('.get_m').click(function(e) {
//console.log("get_m').click(function(e)");
//console.log($(this).attr("href"));
			e.preventDefault();
			destination = $($(this).attr("href")).offset().top-100;
			$('body').animate( { scrollTop: destination },'slow');
			$('html').animate( { scrollTop: destination },'slow');
		})
		
    });
})(jQuery);

/*
	$(function(){
		var startSlide = 1;
		$('#slides').slides({
			preload: true,
			preloadImage: 'images/loading.gif',
			generatePagination: false,
			play:0,
			pause: 3500,
			hoverPause: true,
			// Get the starting slide
			start: startSlide,
			animationComplete: function(current){
				// Set the slide number as a hash
				//window.location.hash = '#' + current;
			}
		});

			
	});

*/