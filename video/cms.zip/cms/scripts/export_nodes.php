<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<style>
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	font-weight:bold;
	color:green;
}
.warning
{
	font-weight:bold;
	color:blue;
}
</style>
</head>
<body>
<?php
chdir ("../");
echo getcwd();
echo "<br>";

require_once './includes/bootstrap.inc';drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
global $base_url;

//$node_type="video";
$node_type="photogallery_image";

echo "<h1>export ".$node_type." nodes</h1>";
switch ($node_type)
{
	case "video":
		$output .= export_taxonomy_vocabulary('ФильмЫ');// словарь таксономии Фильмы
		export_video_nodes();
	break;
	case "photogallery_image":
		//$dir = "/home/vol12/500mb.net/runet_11119978/htdocs/albums/0_export";
		//$dir = "/home/u754457009/public_html/albums/0_export"; //albums.vhost.16mb.com
		$dir = "0_export";
		$output_filename = "export_".$node_type."_nodes.xml";
		$output = "";
		$output .= "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		/*$output .= "<?xml version=\"1.0\" encoding=\"windows-1251\" ?>\n";*/
		$output .= "<albums>\n";
		$output .= export_taxonomy_vocabulary('галереи изображений');
		$output .= export_nodes($node_type);
		$output .= "</albums>\n";
//-------------------------------------- write XML
		if (!empty($output))
		{
//echo $output;
			$filename = $dir."/".$output_filename;
			$num_bytes = file_put_contents ($filename, $output);
			if ($num_bytes > 0)
			{
				echo "-- <span class='ok'>Write </span>".$num_bytes." bytes  in ".$filename;
				echo "<br>";
				echo "base_url = ".$base_url;
				echo "<br>";
		
				echo "<a href='".$base_url."/0_export/".$output_filename."'>".$output_filename."</a>";
//echo "<pre>";
//readfile ($output_filename);
//echo "</pre>";
			}
			else
			{
echo getcwd();
echo "<br>";
				echo "-- <span class='error'>Write error in </span>".$filename;
				echo "<br>";
			}
		}
//--------------------------------------
	break;
}//------------------------------------- end switch

function export_taxonomy_vocabulary($vocabulary)
{
		$output .= "<taxonomy_vocabulary>\n";
//---------------------- по названию, определить vid словаря таксономии
		//D7 $query = "SELECT vid, name FROM taxonomy_vocabulary WHERE UPPER(name)=UPPER('".$vocabulary."');";
		$query = "SELECT vid, name FROM vocabulary WHERE UPPER(name)=UPPER('".$vocabulary."');";
		//$res = mysql_query($query) or die("<font color=red>Query error: </font>".mysql_error());
		$res = db_query($query);
		//if (mysql_num_rows($res) > 0)
		if ($row = db_fetch_object($res))
 		{
			//$row = mysql_fetch_assoc($res);
			//$vid = $row['vid'];
			$vid = $row->vid;
			echo "-- <font color=green>Find vocabulary ".$vocabulary."</font>, vid=".$vid;
			echo "<br>";
		}
		else 
		{
			echo "<font color=red>Error: </font>not find vocabulary ".$vocabulary;
			//exit();
		}
//---------------------- экспорт терминов
		$query = "SELECT tid, name FROM term_data WHERE vid=".$vid.";";
//echo $query;
//echo "<br>";
		//$res = mysql_query($query) or die("<font color=red>Query error: </font>".mysql_error());
		$res = db_query($query);
		//if (mysql_num_rows($res) > 0)
		//{
			//while ($row = mysql_fetch_assoc($res))
			while ($row = db_fetch_object($res))
			{
//echo "<pre>";
//print_r($row);
//echo "</pre>";
				//$output .= "<termin tid='".$row['tid']."'>";
				//$output .= $row['name'];
				$output .= "<termin tid='".$row->tid."'>";
				$output .= $row->name;
				$output .= "</termin>\n";
			}//------------------------ end while
		//}
//---------------------------------------
	$output .= "</taxonomy_vocabulary>\n";

	return $output;
}//----------------------------- end func

function export_video_nodes()
{
}//----------------------------- end func

function export_nodes($node_type)
{
//-------------------------------------- create XML
	$output="";
	$output .= "	<album>\n";
	//$query = "SELECT * FROM node WHERE type='".$node_type."';";
	$query = "
-- получить ноды с прикрепленным изображением 
SELECT 
node.nid, 
node.title, 
term_node.tid,
-- term_data.tid,
term_data.name,
node_revisions.teaser, 
node_revisions.body, 
content_type_photogallery_image.nid, 
content_type_photogallery_image.field_author_value, 
content_type_photogallery_image.field_create_date_value, 
content_type_photogallery_image.field_style_value, 
content_type_photogallery_image.field_genre_value, 
content_type_photogallery_image.field_technique_value, 
content_type_photogallery_image.field_title_value, 
content_type_photogallery_image.field_preview_img_value, 
content_type_photogallery_image.field_big_img_value, 
content_type_photogallery_image.field_original_img_value, 
content_type_photogallery_image.field_img1_gallery_fid, 
files.fid, 
files.filepath 
FROM node 
LEFT JOIN node_revisions ON node_revisions.nid=node.nid 
LEFT JOIN content_type_photogallery_image ON content_type_photogallery_image.nid=node.nid 
LEFT JOIN files ON files.fid=content_type_photogallery_image.field_img1_gallery_fid 
LEFT JOIN term_node ON term_node.nid=node.nid 
LEFT JOIN term_data ON term_data.tid=term_node.tid
WHERE node.type='".$node_type."' 
ORDER BY term_data.tid;";
echo "<pre>";
echo $query;
echo "</pre>";

	$num=0;
	$result = db_query($query);
	while ($row = db_fetch_object($result)) 
	{  
//echo "<pre>";
//print_r($row);  
//echo "</pre>";
		$num++;

		$output .= "	<node num=\"".$num."\" nid=\"".$row->nid."\">\n";

		$title = htmlspecialchars ($row->title);
		$output .= "		<title>".$title."</title>\n";

		$termin = htmlspecialchars ($row->name);
		$output .= "		<termin tid=\"".$row->tid."\">".$termin."</termin>\n";

		$author = htmlspecialchars ($row->field_author_value);
		$output .= "		<author>".$author."</author>\n";
		$field_title_value = htmlspecialchars ($row->field_title_value);
		$output .= "		<field_title_value>".$field_title_value."</field_title_value>\n";

		$body = htmlspecialchars ($row->body);
		$output .= "		<body>".$body."</body>\n";

		$output .= "		<year>".$row->field_create_date_value."</year>\n";

		$style = htmlspecialchars ($row->field_style_value);
		$output .= "		<style>".$style."</style>\n";

		$genre = htmlspecialchars ($row->field_genre_value);
		$output .= "		<genre>".$genre."</genre>\n";

		$technique = htmlspecialchars ($row->field_technique_value);
		$output .= "		<technique>".$technique."</technique>\n";

		$preview_img = htmlspecialchars ($row->field_preview_img_value);
		$output .= "		<preview_img>".$preview_img."</preview_img>\n";
		$big_img = htmlspecialchars ($row->field_big_img_value);
		$output .= "		<big_img>".$big_img."</big_img>\n";
		$original_img = htmlspecialchars ($row->field_original_img_value);
		$output .= "		<original_img>".$original_img."</original_img>\n";

//[field_img1_gallery_fid] => 
//[fid] => 
//[filepath] => 
		$output .= "	</node>\n";
	}
	$output .= "	</album>\n";

	$output = str_replace("'", "&#39;", $output); //замена апострофа его кодом
	return $output;
}//----------------------------- end func

?>
</body>
</html>
