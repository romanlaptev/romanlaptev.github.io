//https://eslint.org/docs/rules/
module.exports = {
    //"extends": "google"
	//"extends": ["google", "plugin:prettier/recommended"]
	"extends": ["react-app", "plugin:prettier/recommended"]
	//"extends": "standard",
	/*
	"rules": {
		{
			"indent": ["error", "tab"]
		}		
	}
	*/
};