it('throws an error', function() {});
