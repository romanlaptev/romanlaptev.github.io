var assert = require('assert');

describe('suite', function() {
  it('test1', function() {
    assert(true);
  });

  it('test2', function() {
    assert(true);
  });
});
