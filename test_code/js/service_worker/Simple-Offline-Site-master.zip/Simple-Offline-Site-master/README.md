Demo repo for the article [Making a Simple Site Work Offline with ServiceWorker](https://css-tricks.com/serviceworker-for-offline).

