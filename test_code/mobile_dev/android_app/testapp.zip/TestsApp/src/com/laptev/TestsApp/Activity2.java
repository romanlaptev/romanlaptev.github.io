package com.laptev.TestsApp;

import android.app.Activity;
import android.os.Bundle;

import android.widget.Button;
import android.view.View;
import android.content.Intent;


public class Activity2 extends Activity
{
    
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
    }//end onCreate()

	public void clickBtnBack( View v ){
		setContentView(R.layout.main);
        Intent intent = new Intent(this, Activity1.class);
		startActivity(intent);
	}//end clickBtnBack()

}//end class