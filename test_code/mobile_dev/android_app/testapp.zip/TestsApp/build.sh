#!/bin/sh

#ant debug
ant release
