package com.laptev.app3;

import android.app.Activity;
import android.os.Bundle;

import android.widget.Button;
import android.widget.TextView;
import android.view.View;

import android.widget.CheckBox;
import android.widget.CompoundButton;

public class MainActivity extends Activity
    implements CompoundButton.OnCheckedChangeListener {

    private TextView mText;
    CheckBox cb;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

//---------------- from App2
        mText = (TextView)findViewById(R.id.text);

        final Button button1 = (Button)findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mText.setText("Click on First Button");
            }
        });
        
        final Button button2 = (Button)findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mText.setText("Click on Second Button");
            }
        });

//---------------
        cb=(CheckBox)findViewById(R.id.CheckBox01);
        cb.setOnCheckedChangeListener(this);
//---------------

    }//end onCreate()

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) 
    {
        if (isChecked) 
            cb.setText("CheckBox ON");
        else 
            cb.setText("CheckBox OFF");
    }

}//end class MainActivity