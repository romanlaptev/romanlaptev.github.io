#!/bin/sh

#----------------------------- create project
#android -v create project \
#--target android-19 \
#--name App3 \
#--path App3 \
#--activity MainActivity \
#--package com.laptev.app3

cd App3
#ant debug
ant release
