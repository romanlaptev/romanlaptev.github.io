package com.laptev.TestsApp;

import android.app.Activity;
import android.os.Bundle;

import android.widget.Button;
import android.view.View;

public class Activity2 extends Activity
{
    
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
    }//end onCreate()

	public void clickBtnBack( View v ){
		setContentView(R.layout.main);
	}//end clickBtnBack()

}//end class