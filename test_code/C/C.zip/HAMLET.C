#include <windows.h>
#include <commdlg.h>

int main ()
{
   MessageBox(NULL,"To be or not to be ?","be-be-be",MB_OK);
   return 0;
}
