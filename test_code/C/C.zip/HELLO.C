#include <stdio.h>
//#include <conio.h>

main()
{
 int n;

 for (n=1; n<10; n++)
   {
 	printf("Hello, C world\n");
   }
 return 0;
}

