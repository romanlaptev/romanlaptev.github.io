# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_first_ruby_app_session',
  :secret      => '5f5e555c69d6f89fafb55c7174d0a46237995e9cbd9cc908857bf0d7de8a4c30510d8884c2fe0537a9f26b157867d31f52413b4814507582e42d5b230ffc03d6'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
