script/server
