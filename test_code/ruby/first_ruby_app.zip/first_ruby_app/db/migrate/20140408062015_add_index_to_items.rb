class AddIndexToItems < ActiveRecord::Migration
  def self.up
	add_index :items, :price
	add_index :items, :name
  end

  def self.down
  end
end
