class WelcomeController < ApplicationController
  def index
	$test="this is gloval variable"
	@test2="this is local variable"
	
  end

  def add_product
	#i = Item.new
	#i.price = 106
	#i.name = "product6"
	#i.real = true
	#i.weight = 106
	#i.description = "desc!!!"
	#i.save

	#i = Item.new({:price => 107, :name => "product7", :real => true, :weight => 107, :description => "desc!!!"})
	#i.save

	Item.create({:price => -1, :real => true, :weight => 110})
  end

  def list_product
	@i = Item.last
  end

  def update_product
	@i = Item.new
	@i.update_attributes({:price => 501, :name => "product1"})
  end

end
