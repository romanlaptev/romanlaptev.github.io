class Item < ActiveRecord::Base
	#attr_accessible :price, :name, :real, :weight, :description
	#err!!! validates :price, :numericality => {:greater_than => 0} 
	#err!!! validates :name, :description, :presence => true
end
