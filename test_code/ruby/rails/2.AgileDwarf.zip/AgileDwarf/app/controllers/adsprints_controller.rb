class AdsprintsController < ApplicationController
  unloadable

  before_filter :find_project, :authorize

  def list
    @backlog = SprintsTasks.get_backlog(@project)
	
    @sprints = Sprints.all_sprints(@project)
    @sprints.each{|s| s['tasks'] = SprintsTasks.get_tasks_by_sprint(@project, [s.id])}
	
    @assignables = {}
    @project.assignable_users.each{|u| @assignables[u.id] = u.firstname + ' ' + u.lastname}
    @project_id = @project.id
    @plugin_path = File.join(Redmine::Utils.relative_url_root, 'plugin_assets', 'AgileDwarf')
    @closed_status = Setting.plugin_AgileDwarf[:stclosed].to_i
#=============================================================	
	@test = Sprints.get_related_version_id(@project)
	array_values = [1,9,15,16]
	#array_values = {}
	#@test.each do |row|
	#	@array_values[]=row
	#end
	
    @sprints += Sprints.test(@project,array_values)

	# получить спринты, связанные с текущим проектом
	@related_versions = Sprints.get_related_version(@project)
	@related_versions_issues = Sprints.get_related_version_issues(@project)
	
	# создать пустой объект модели
    #@empty_sprint = Sprints.create
	#@empty_sprint.each do |sprint|
	#	sprint.update_attributes(:id => 53)
	#end

	#@sprints.each do |sprint|
	#	sprint.update_attributes(:name => "John")
	#end
	
	#@user.update_attributes(:status => 'active')
	#user.get_attribute_by_name(attribute_name) => "John"
#=============================================================	
  end

  private

  def find_project
    # @project variable must be set before calling the authorize filter
    @project = Project.find(params[:project_id])
  end
  
end