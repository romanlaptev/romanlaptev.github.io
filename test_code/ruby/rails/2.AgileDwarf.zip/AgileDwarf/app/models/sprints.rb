class Sprints < Version
  unloadable

  validate :start_and_end_dates

  class << self
    def open_sprints(project)
      scoped(:order => 'ir_start_date ASC, ir_end_date ASC', :conditions => [ "status = 'open' and project_id = ?", project.id ])
    end
    def all_sprints(project)
      scoped(:order => 'ir_start_date ASC, ir_end_date ASC', :conditions => [ "project_id = ?", project.id ])
    end
#===============================================================================================	
    def test(project,array_values)
      #scoped(:order => 'ir_start_date ASC, ir_end_date ASC', :conditions => [ "sharing = 'system'" ])
      #scoped(:conditions => [ "id = 1" ])
		#array_values = [1,9,15,16]
		where("project_id != ? AND id IN (?)", project.id, array_values)
    end
	
	def get_related_version(project)
	  #-- получить спринты, связанные с текущим проектом
		pr_id = project.id.to_s
		sql = "
SELECT 
id,
project_id,
name,
description,
effective_date,
created_on,
updated_on,
wiki_page_title,
status,
sharing,
ir_start_date,
ir_end_date
FROM versions
WHERE
versions.project_id != "+ pr_id +" AND versions.id IN
(
SELECT
DISTINCT(issues.fixed_version_id)
FROM issues
WHERE issues.project_id = "+ pr_id +" AND issues. fixed_version_id IS NOT NULL
ORDER BY issues.fixed_version_id ASC
);"
		return ActiveRecord::Base.connection.execute(sql)	
	end

	def get_related_version_id(project)
		#-- получить id связанных спринтов
		pr_id = project.id.to_s
		sql = "
SELECT
DISTINCT(issues.fixed_version_id)
FROM issues
WHERE issues.project_id = "+ pr_id +" AND issues. fixed_version_id IS NOT NULL
ORDER BY issues.fixed_version_id ASC;"
		return ActiveRecord::Base.connection.execute(sql)	
	end
	
	def get_related_version_issues(project)
	  #-- получить спринты, связанные с текущим проектом
		pr_id = project.id.to_s
		sql = "
SELECT
issues.id,
issues.project_id,	
issues.subject,
issues.fixed_version_id
FROM issues
WHERE
issues.project_id = "+ pr_id +" AND issues.fixed_version_id = 9;		
"
		return ActiveRecord::Base.connection.execute(sql)	
	end
#===============================================================================================	
	
  end

  def start_and_end_dates
    errors.add_to_base("Sprint cannot end before it starts") if self.ir_start_date && self.ir_end_date && self.ir_start_date >= self.ir_end_date
  end

  def tasks
    SprintsTasks.get_tasks_by_sprint(self.project, self.id)
  end

end