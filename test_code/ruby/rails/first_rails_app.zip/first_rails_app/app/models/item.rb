class Item < ActiveRecord::Base
	#attr_accessible :name, :price, :real, :weight, :description

	validates :price, numericality: {greater_than: 0}
	validates :name, :description, presence: true 

	#belongs_to :category
	#has_and_belongs_to_many :carts
	has_many :positions
	has_many :carts, through: :positions

	has_many :comments, as: :commentable

#callbacks
	after_initialize{ puts "Item initialize!!!!" }
	after_save 	{}
	after_create 	{}
	after_update 	{}
	after_destroy 	{}
end
