class Comment < ActiveRecord::Base
	#attr_accessible :body, :user_id, :commentable_id, :commentable_typa
	belongs_to :user
	belongs_to :commentable, polymorphic: true
end
