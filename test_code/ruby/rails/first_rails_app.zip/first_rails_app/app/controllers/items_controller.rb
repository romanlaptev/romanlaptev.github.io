class ItemsController < ApplicationController 
#RESTful controller

	before_filter :find_item, only: [:edit, :update, :destroy, :upvote]
	before_filter :check_if_admin, only: [:new, :edit, :update, :create, :destroy]

	def index
		@items = Item.all
	end

	#/items/1 GET
	def show
		@params_c = params

		#if @item = Item.where(id: params[:id]).first
		#	render "items/show"
		#else
		#	render text: "Page not found", status: 404
		#end

		unless @item = Item.where(id: params[:id]).first
			render text: "Page not found", status: 404
		end
	end

	#/items/new GET
	def new
		@item = Item.new
	end

	#/items/1/edit GET
	def edit
		#@item = Item.find(params[:id])
	end

	#/items POST
	def create
		item_params = params[:item]
		#render text: item_params[:name].inspect
=begin
		@item = Item.create(
				name: item_params[:name],
				price: item_params[:price],
				weight: item_params[:weight],
				description: item_params[:description] 
				)
=end
		@item = Item.create(items_params)
		if @item.errors.empty?
			redirect_to item_path(@item)
			flash.now[:sussess]="All done! " + @item.errors.messages.to_s
		else
			flash.now[:error]="error!!!! " + @item.errors.messages.to_s
			render "new"
			#render text: "Error!"
			#render text: params.inspect
		end
	end

	#/items/1 PUT
	def update
		#@item = Item.find(params[:id])
=begin
		item_params = params[:item]
		@item.update_attributes(
				name: item_params[:name],
				price: item_params[:price],
				weight: item_params[:weight],
				description: item_params[:description] 
				)
=end
		@item.update_attributes(items_params)
		if @item.errors.empty?
			redirect_to item_path(@item)
			flash.now[:sussess]="All done! " + @item.errors.messages.to_s
		else
			flash.now[:error]="error!!!! " + @item.errors.messages.to_s
			render "edit"
		end
	end

#use strong parameters, define correct fields
	def items_params
		#params.require(:item).permit(:price, :weight, :real, :name, :description)
		params.require(:item).permit!
	end

	#/items/1 DELETE
	def destroy
		#@item = Item.find(params[:id])
		@item.destroy
		redirect_to action:"index"
	end

	def upvote
		@item.increment!(:votes_count)#увеличить значение и схранить в таблице
		redirect_to action: :index
	end

	def expensive
		@items = Item.where("price > 1000")
		render "index"
	end

	private
		#before filter method
		def find_item
			#@item = Item.find(params[:id])
			@item = Item.where(id: params[:id]).first
			render_404 unless @item
		end

end
