class WelcomeController < ApplicationController
  def index
  end

  def add_product
	#@i = Item.new
	#@i.name = "product1"
	#@i.price = 101
	#@i.real = true
	#@i.weight = 101
	#@i.save

	#@i = Item.new({:price => -1, :name => "product2", :real => true, :weight => 102})
	@i = Item.new({:price => 103, :name => "product3", :real => true, :weight => 103, :description => "desc!!!"})
	@i.save
  end

  def list_product
	#@first_item = Item.first
	#@last_item = Item.last

	@items = Item.all
	#render text: @items.map { |i| "#{i.name}: #{i.price}" }.join("<br/>")
  end

	def update_product
		@upd_rec = Item.find(3)
		@upd_rec.update_attributes({:price => 501})
		@upd_rec.save
	end

	def find_product
		@find_result = Item.find(3)
	end


	def delete_product
		@del_rec = Item.find(1)
		@del_rec.destroy
	end


	#/welcome POST
	def create
		#render text: "<h2>create action</h2>"
		@params_c = params

		#@item = Item.new( 
		@item = Item.create( 
				name: params[:name],
				price: params[:price],
				real: params[:real],
				weight: params[:weight],
				description: params[:description] 
		)
		#@item.save
	end

	def test_ar
		#@items = Item.where(price: 1500, weight: 100)
		#@items = Item.where("price = 1500 OR weight = 100")
		@items = Item.where("price >= ?",params[:price_from]).order("votes_count DESC").limit(10)
		
		#@items = Item.where("created_at >= ?", 1.day.ago)
		
		#выборка из результатов предыдущего запроса		
		@items = @items.where("name = 'product6'")
	end

end
