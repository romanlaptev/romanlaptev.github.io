module ApplicationHelper

	def urls_to_images(s)
		#s.gsub! /\s(http:\/\/.*?)\s/, '<img src="\1"/>'
		s1 = s.gsub! "http://", "<img src='http://"
		if s1
			s2 = s1.to_s + "'/>" 
			s2.html_safe
		else
			s
		end
	end

	def urls_to_links(s)
	end

end
