# Be sure to restart your server when you modify this file.

FirstRailsApp::Application.config.session_store :cookie_store, key: '_first_rails_app_session'
