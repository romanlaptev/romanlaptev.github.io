# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 0) do

  create_table "actions", primary_key: "aid", force: true do |t|
    t.string "type",       limit: 32, default: "",  null: false
    t.string "callback",              default: "",  null: false
    t.binary "parameters",                          null: false
    t.string "label",                 default: "0", null: false
  end

  add_index "actions", ["aid"], name: "sqlite_autoindex_actions_1", unique: true

  create_table "authmap", primary_key: "aid", force: true do |t|
    t.integer "uid",                  default: 0,  null: false
    t.string  "authname", limit: 128, default: "", null: false
    t.string  "module",   limit: 128, default: "", null: false
  end

  add_index "authmap", ["authname"], name: "authmap_authname", unique: true

  create_table "batch", primary_key: "bid", force: true do |t|
    t.string  "token",     limit: 64, null: false
    t.integer "timestamp",            null: false
    t.binary  "batch"
  end

  add_index "batch", ["token"], name: "batch_token"

  create_table "block", primary_key: "bid", force: true do |t|
    t.string  "module",     limit: 64, default: "",  null: false
    t.string  "delta",      limit: 32, default: "0", null: false
    t.string  "theme",      limit: 64, default: "",  null: false
    t.integer "status",                default: 0,   null: false
    t.integer "weight",                default: 0,   null: false
    t.string  "region",     limit: 64, default: "",  null: false
    t.integer "custom",                default: 0,   null: false
    t.integer "visibility",            default: 0,   null: false
    t.text    "pages",                               null: false
    t.string  "title",      limit: 64, default: "",  null: false
    t.integer "cache",                 default: 1,   null: false
  end

  add_index "block", ["theme", "module", "delta"], name: "block_tmd", unique: true
  add_index "block", ["theme", "status", "region", "weight", "module"], name: "block_list"

  create_table "block_custom", primary_key: "bid", force: true do |t|
    t.text   "body"
    t.string "info",   limit: 128, default: "", null: false
    t.string "format"
  end

  add_index "block_custom", ["info"], name: "block_custom_info", unique: true

  create_table "block_node_type", primary_key: "module", force: true do |t|
    t.string "delta", limit: 32, null: false
    t.string "type",  limit: 32, null: false
  end

  add_index "block_node_type", ["module", "delta", "type"], name: "sqlite_autoindex_block_node_type_1", unique: true
  add_index "block_node_type", ["type"], name: "block_node_type_type"

  create_table "block_role", primary_key: "module", force: true do |t|
    t.string  "delta", limit: 32, null: false
    t.integer "rid",              null: false
  end

  add_index "block_role", ["module", "delta", "rid"], name: "sqlite_autoindex_block_role_1", unique: true
  add_index "block_role", ["rid"], name: "block_role_rid"

  create_table "blocked_ips", primary_key: "iid", force: true do |t|
    t.string "ip", limit: 40, default: "", null: false
  end

  add_index "blocked_ips", ["ip"], name: "blocked_ips_blocked_ip"

  create_table "book", primary_key: "mlid", force: true do |t|
    t.integer "nid", default: 0, null: false
    t.integer "bid", default: 0, null: false
  end

  add_index "book", ["bid"], name: "book_bid"
  add_index "book", ["nid"], name: "book_nid", unique: true

  create_table "cache", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache", ["cid"], name: "sqlite_autoindex_cache_1", unique: true
  add_index "cache", ["expire"], name: "cache_expire"

  create_table "cache_block", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_block", ["cid"], name: "sqlite_autoindex_cache_block_1", unique: true
  add_index "cache_block", ["expire"], name: "cache_block_expire"

  create_table "cache_bootstrap", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_bootstrap", ["cid"], name: "sqlite_autoindex_cache_bootstrap_1", unique: true
  add_index "cache_bootstrap", ["expire"], name: "cache_bootstrap_expire"

  create_table "cache_field", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_field", ["cid"], name: "sqlite_autoindex_cache_field_1", unique: true
  add_index "cache_field", ["expire"], name: "cache_field_expire"

  create_table "cache_filter", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_filter", ["cid"], name: "sqlite_autoindex_cache_filter_1", unique: true
  add_index "cache_filter", ["expire"], name: "cache_filter_expire"

  create_table "cache_form", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_form", ["cid"], name: "sqlite_autoindex_cache_form_1", unique: true
  add_index "cache_form", ["expire"], name: "cache_form_expire"

  create_table "cache_image", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_image", ["cid"], name: "sqlite_autoindex_cache_image_1", unique: true
  add_index "cache_image", ["expire"], name: "cache_image_expire"

  create_table "cache_menu", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_menu", ["cid"], name: "sqlite_autoindex_cache_menu_1", unique: true
  add_index "cache_menu", ["expire"], name: "cache_menu_expire"

  create_table "cache_page", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_page", ["cid"], name: "sqlite_autoindex_cache_page_1", unique: true
  add_index "cache_page", ["expire"], name: "cache_page_expire"

  create_table "cache_path", primary_key: "cid", force: true do |t|
    t.binary  "data"
    t.integer "expire",     default: 0, null: false
    t.integer "created",    default: 0, null: false
    t.integer "serialized", default: 0, null: false
  end

  add_index "cache_path", ["cid"], name: "sqlite_autoindex_cache_path_1", unique: true
  add_index "cache_path", ["expire"], name: "cache_path_expire"

  create_table "ckeditor_input_format", primary_key: "name", force: true do |t|
    t.string "format", limit: 128, default: "", null: false
  end

  add_index "ckeditor_input_format", ["name", "format"], name: "sqlite_autoindex_ckeditor_input_format_1", unique: true

  create_table "ckeditor_settings", primary_key: "name", force: true do |t|
    t.text "settings"
  end

  add_index "ckeditor_settings", ["name"], name: "sqlite_autoindex_ckeditor_settings_1", unique: true

  create_table "comment", primary_key: "cid", force: true do |t|
    t.integer "pid",                  default: 0,  null: false
    t.integer "nid",                  default: 0,  null: false
    t.integer "uid",                  default: 0,  null: false
    t.string  "subject",  limit: 64,  default: "", null: false
    t.string  "hostname", limit: 128, default: "", null: false
    t.integer "created",              default: 0,  null: false
    t.integer "changed",              default: 0,  null: false
    t.integer "status",               default: 1,  null: false
    t.string  "thread",                            null: false
    t.string  "name",     limit: 60
    t.string  "mail",     limit: 64
    t.string  "homepage"
    t.string  "language", limit: 12,  default: "", null: false
  end

  add_index "comment", ["created"], name: "comment_comment_created"
  add_index "comment", ["nid", "language"], name: "comment_comment_nid_language"
  add_index "comment", ["nid", "status", "created", "cid", "thread"], name: "comment_comment_num_new"
  add_index "comment", ["pid", "status"], name: "comment_comment_status_pid"
  add_index "comment", ["uid"], name: "comment_comment_uid"

  create_table "date_format_locale", primary_key: "type", force: true do |t|
    t.string "format",   limit: 100, null: false
    t.string "language", limit: 12,  null: false
  end

  add_index "date_format_locale", ["type", "language"], name: "sqlite_autoindex_date_format_locale_1", unique: true

  create_table "date_format_type", primary_key: "type", force: true do |t|
    t.string  "title",              null: false
    t.integer "locked", default: 0, null: false
  end

  add_index "date_format_type", ["title"], name: "date_format_type_title"
  add_index "date_format_type", ["type"], name: "sqlite_autoindex_date_format_type_1", unique: true

  create_table "date_formats", primary_key: "dfid", force: true do |t|
    t.string  "format", limit: 100,             null: false
    t.string  "type",   limit: 64,              null: false
    t.integer "locked",             default: 0, null: false
  end

  add_index "date_formats", ["format", "type"], name: "date_formats_formats", unique: true

  create_table "field_config", force: true do |t|
    t.string  "field_name",     limit: 32,               null: false
    t.string  "type",           limit: 128,              null: false
    t.string  "module",         limit: 128, default: "", null: false
    t.integer "active",                     default: 0,  null: false
    t.string  "storage_type",   limit: 128,              null: false
    t.string  "storage_module", limit: 128, default: "", null: false
    t.integer "storage_active",             default: 0,  null: false
    t.integer "locked",                     default: 0,  null: false
    t.binary  "data",                                    null: false
    t.integer "cardinality",                default: 0,  null: false
    t.integer "translatable",               default: 0,  null: false
    t.integer "deleted",                    default: 0,  null: false
  end

  add_index "field_config", ["active"], name: "field_config_active"
  add_index "field_config", ["deleted"], name: "field_config_deleted"
  add_index "field_config", ["field_name"], name: "field_config_field_name"
  add_index "field_config", ["module"], name: "field_config_module"
  add_index "field_config", ["storage_active"], name: "field_config_storage_active"
  add_index "field_config", ["storage_module"], name: "field_config_storage_module"
  add_index "field_config", ["storage_type"], name: "field_config_storage_type"
  add_index "field_config", ["type"], name: "field_config_type"

  create_table "field_config_instance", force: true do |t|
    t.integer "field_id",                             null: false
    t.string  "field_name",  limit: 32,  default: "", null: false
    t.string  "entity_type", limit: 32,  default: "", null: false
    t.string  "bundle",      limit: 128, default: "", null: false
    t.binary  "data",                                 null: false
    t.integer "deleted",                 default: 0,  null: false
  end

  add_index "field_config_instance", ["deleted"], name: "field_config_instance_deleted"
  add_index "field_config_instance", ["field_name", "entity_type", "bundle"], name: "field_config_instance_field_name_bundle"

  create_table "field_data_body", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",       limit: 128, default: "", null: false
    t.integer "deleted",                  default: 0,  null: false
    t.integer "entity_id",                             null: false
    t.integer "revision_id"
    t.string  "language",     limit: 32,  default: "", null: false
    t.integer "delta",                                 null: false
    t.text    "body_value"
    t.text    "body_summary"
    t.string  "body_format"
  end

  add_index "field_data_body", ["body_format"], name: "field_data_body_body_format"
  add_index "field_data_body", ["bundle"], name: "field_data_body_bundle"
  add_index "field_data_body", ["deleted"], name: "field_data_body_deleted"
  add_index "field_data_body", ["entity_id"], name: "field_data_body_entity_id"
  add_index "field_data_body", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_body_1", unique: true
  add_index "field_data_body", ["entity_type"], name: "field_data_body_entity_type"
  add_index "field_data_body", ["language"], name: "field_data_body_language"
  add_index "field_data_body", ["revision_id"], name: "field_data_body_revision_id"

  create_table "field_data_comment_body", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",              limit: 128, default: "", null: false
    t.integer "deleted",                         default: 0,  null: false
    t.integer "entity_id",                                    null: false
    t.integer "revision_id"
    t.string  "language",            limit: 32,  default: "", null: false
    t.integer "delta",                                        null: false
    t.text    "comment_body_value"
    t.string  "comment_body_format"
  end

  add_index "field_data_comment_body", ["bundle"], name: "field_data_comment_body_bundle"
  add_index "field_data_comment_body", ["comment_body_format"], name: "field_data_comment_body_comment_body_format"
  add_index "field_data_comment_body", ["deleted"], name: "field_data_comment_body_deleted"
  add_index "field_data_comment_body", ["entity_id"], name: "field_data_comment_body_entity_id"
  add_index "field_data_comment_body", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_comment_body_1", unique: true
  add_index "field_data_comment_body", ["entity_type"], name: "field_data_comment_body_entity_type"
  add_index "field_data_comment_body", ["language"], name: "field_data_comment_body_language"
  add_index "field_data_comment_body", ["revision_id"], name: "field_data_comment_body_revision_id"

  create_table "field_data_field_book_author", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id"
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.string  "field_book_author_value",  limit: 60
    t.string  "field_book_author_format"
  end

  add_index "field_data_field_book_author", ["bundle"], name: "field_data_field_book_author_bundle"
  add_index "field_data_field_book_author", ["deleted"], name: "field_data_field_book_author_deleted"
  add_index "field_data_field_book_author", ["entity_id"], name: "field_data_field_book_author_entity_id"
  add_index "field_data_field_book_author", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_book_author_1", unique: true
  add_index "field_data_field_book_author", ["entity_type"], name: "field_data_field_book_author_entity_type"
  add_index "field_data_field_book_author", ["field_book_author_format"], name: "field_data_field_book_author_field_book_author_format"
  add_index "field_data_field_book_author", ["language"], name: "field_data_field_book_author_language"
  add_index "field_data_field_book_author", ["revision_id"], name: "field_data_field_book_author_revision_id"

  create_table "field_data_field_book_file", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                      limit: 128, default: "", null: false
    t.integer "deleted",                                 default: 0,  null: false
    t.integer "entity_id",                                            null: false
    t.integer "revision_id"
    t.string  "language",                    limit: 32,  default: "", null: false
    t.integer "delta",                                                null: false
    t.integer "field_book_file_fid"
    t.integer "field_book_file_display",                 default: 1,  null: false
    t.text    "field_book_file_description"
  end

  add_index "field_data_field_book_file", ["bundle"], name: "field_data_field_book_file_bundle"
  add_index "field_data_field_book_file", ["deleted"], name: "field_data_field_book_file_deleted"
  add_index "field_data_field_book_file", ["entity_id"], name: "field_data_field_book_file_entity_id"
  add_index "field_data_field_book_file", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_book_file_1", unique: true
  add_index "field_data_field_book_file", ["entity_type"], name: "field_data_field_book_file_entity_type"
  add_index "field_data_field_book_file", ["field_book_file_fid"], name: "field_data_field_book_file_field_book_file_fid"
  add_index "field_data_field_book_file", ["language"], name: "field_data_field_book_file_language"
  add_index "field_data_field_book_file", ["revision_id"], name: "field_data_field_book_file_revision_id"

  create_table "field_data_field_book_filename", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                     limit: 128, default: "", null: false
    t.integer "deleted",                                default: 0,  null: false
    t.integer "entity_id",                                           null: false
    t.integer "revision_id"
    t.string  "language",                   limit: 32,  default: "", null: false
    t.integer "delta",                                               null: false
    t.string  "field_book_filename_value"
    t.string  "field_book_filename_format"
  end

  add_index "field_data_field_book_filename", ["bundle"], name: "field_data_field_book_filename_bundle"
  add_index "field_data_field_book_filename", ["deleted"], name: "field_data_field_book_filename_deleted"
  add_index "field_data_field_book_filename", ["entity_id"], name: "field_data_field_book_filename_entity_id"
  add_index "field_data_field_book_filename", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_book_filename_1", unique: true
  add_index "field_data_field_book_filename", ["entity_type"], name: "field_data_field_book_filename_entity_type"
  add_index "field_data_field_book_filename", ["field_book_filename_format"], name: "field_data_field_book_filename_field_book_filename_format"
  add_index "field_data_field_book_filename", ["language"], name: "field_data_field_book_filename_language"
  add_index "field_data_field_book_filename", ["revision_id"], name: "field_data_field_book_filename_revision_id"

  create_table "field_data_field_book_img", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                limit: 128,  default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id"
    t.string  "language",              limit: 32,   default: "", null: false
    t.integer "delta",                                           null: false
    t.integer "field_book_img_fid"
    t.string  "field_book_img_alt",    limit: 512
    t.string  "field_book_img_title",  limit: 1024
    t.integer "field_book_img_width"
    t.integer "field_book_img_height"
  end

  add_index "field_data_field_book_img", ["bundle"], name: "field_data_field_book_img_bundle"
  add_index "field_data_field_book_img", ["deleted"], name: "field_data_field_book_img_deleted"
  add_index "field_data_field_book_img", ["entity_id"], name: "field_data_field_book_img_entity_id"
  add_index "field_data_field_book_img", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_book_img_1", unique: true
  add_index "field_data_field_book_img", ["entity_type"], name: "field_data_field_book_img_entity_type"
  add_index "field_data_field_book_img", ["field_book_img_fid"], name: "field_data_field_book_img_field_book_img_fid"
  add_index "field_data_field_book_img", ["language"], name: "field_data_field_book_img_language"
  add_index "field_data_field_book_img", ["revision_id"], name: "field_data_field_book_img_revision_id"

  create_table "field_data_field_book_name", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id"
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.string  "field_book_name_value"
    t.string  "field_book_name_format"
  end

  add_index "field_data_field_book_name", ["bundle"], name: "field_data_field_book_name_bundle"
  add_index "field_data_field_book_name", ["deleted"], name: "field_data_field_book_name_deleted"
  add_index "field_data_field_book_name", ["entity_id"], name: "field_data_field_book_name_entity_id"
  add_index "field_data_field_book_name", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_book_name_1", unique: true
  add_index "field_data_field_book_name", ["entity_type"], name: "field_data_field_book_name_entity_type"
  add_index "field_data_field_book_name", ["field_book_name_format"], name: "field_data_field_book_name_field_book_name_format"
  add_index "field_data_field_book_name", ["language"], name: "field_data_field_book_name_language"
  add_index "field_data_field_book_name", ["revision_id"], name: "field_data_field_book_name_revision_id"

  create_table "field_data_field_code", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",            limit: 128, default: "", null: false
    t.integer "deleted",                       default: 0,  null: false
    t.integer "entity_id",                                  null: false
    t.integer "revision_id"
    t.string  "language",          limit: 32,  default: "", null: false
    t.integer "delta",                                      null: false
    t.text    "field_code_value"
    t.string  "field_code_format"
  end

  add_index "field_data_field_code", ["bundle"], name: "field_data_field_code_bundle"
  add_index "field_data_field_code", ["deleted"], name: "field_data_field_code_deleted"
  add_index "field_data_field_code", ["entity_id"], name: "field_data_field_code_entity_id"
  add_index "field_data_field_code", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_code_1", unique: true
  add_index "field_data_field_code", ["entity_type"], name: "field_data_field_code_entity_type"
  add_index "field_data_field_code", ["field_code_format"], name: "field_data_field_code_field_code_format"
  add_index "field_data_field_code", ["language"], name: "field_data_field_code_language"
  add_index "field_data_field_code", ["revision_id"], name: "field_data_field_code_revision_id"

  create_table "field_data_field_content_files", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                     limit: 128, default: "", null: false
    t.integer "deleted",                                default: 0,  null: false
    t.integer "entity_id",                                           null: false
    t.integer "revision_id"
    t.string  "language",                   limit: 32,  default: "", null: false
    t.integer "delta",                                               null: false
    t.string  "field_content_files_value"
    t.string  "field_content_files_format"
  end

  add_index "field_data_field_content_files", ["bundle"], name: "field_data_field_content_files_bundle"
  add_index "field_data_field_content_files", ["deleted"], name: "field_data_field_content_files_deleted"
  add_index "field_data_field_content_files", ["entity_id"], name: "field_data_field_content_files_entity_id"
  add_index "field_data_field_content_files", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_content_files_1", unique: true
  add_index "field_data_field_content_files", ["entity_type"], name: "field_data_field_content_files_entity_type"
  add_index "field_data_field_content_files", ["field_content_files_format"], name: "field_data_field_content_files_field_content_files_format"
  add_index "field_data_field_content_files", ["language"], name: "field_data_field_content_files_language"
  add_index "field_data_field_content_files", ["revision_id"], name: "field_data_field_content_files_revision_id"

  create_table "field_data_field_content_location", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                        limit: 128, default: "", null: false
    t.integer "deleted",                                   default: 0,  null: false
    t.integer "entity_id",                                              null: false
    t.integer "revision_id"
    t.string  "language",                      limit: 32,  default: "", null: false
    t.integer "delta",                                                  null: false
    t.string  "field_content_location_value"
    t.string  "field_content_location_format"
  end

  add_index "field_data_field_content_location", ["bundle"], name: "field_data_field_content_location_bundle"
  add_index "field_data_field_content_location", ["deleted"], name: "field_data_field_content_location_deleted"
  add_index "field_data_field_content_location", ["entity_id"], name: "field_data_field_content_location_entity_id"
  add_index "field_data_field_content_location", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_content_location_1", unique: true
  add_index "field_data_field_content_location", ["entity_type"], name: "field_data_field_content_location_entity_type"
  add_index "field_data_field_content_location", ["field_content_location_format"], name: "field_data_field_content_location_field_content_location_format"
  add_index "field_data_field_content_location", ["language"], name: "field_data_field_content_location_language"
  add_index "field_data_field_content_location", ["revision_id"], name: "field_data_field_content_location_revision_id"

  create_table "field_data_field_description", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id"
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.text    "field_description_value"
    t.string  "field_description_format"
  end

  add_index "field_data_field_description", ["bundle"], name: "field_data_field_description_bundle"
  add_index "field_data_field_description", ["deleted"], name: "field_data_field_description_deleted"
  add_index "field_data_field_description", ["entity_id"], name: "field_data_field_description_entity_id"
  add_index "field_data_field_description", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_description_1", unique: true
  add_index "field_data_field_description", ["entity_type"], name: "field_data_field_description_entity_type"
  add_index "field_data_field_description", ["field_description_format"], name: "field_data_field_description_field_description_format"
  add_index "field_data_field_description", ["language"], name: "field_data_field_description_language"
  add_index "field_data_field_description", ["revision_id"], name: "field_data_field_description_revision_id"

  create_table "field_data_field_image", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128,  default: "", null: false
    t.integer "deleted",                         default: 0,  null: false
    t.integer "entity_id",                                    null: false
    t.integer "revision_id"
    t.string  "language",           limit: 32,   default: "", null: false
    t.integer "delta",                                        null: false
    t.integer "field_image_fid"
    t.string  "field_image_alt",    limit: 512
    t.string  "field_image_title",  limit: 1024
    t.integer "field_image_width"
    t.integer "field_image_height"
  end

  add_index "field_data_field_image", ["bundle"], name: "field_data_field_image_bundle"
  add_index "field_data_field_image", ["deleted"], name: "field_data_field_image_deleted"
  add_index "field_data_field_image", ["entity_id"], name: "field_data_field_image_entity_id"
  add_index "field_data_field_image", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_image_1", unique: true
  add_index "field_data_field_image", ["entity_type"], name: "field_data_field_image_entity_type"
  add_index "field_data_field_image", ["field_image_fid"], name: "field_data_field_image_field_image_fid"
  add_index "field_data_field_image", ["language"], name: "field_data_field_image_language"
  add_index "field_data_field_image", ["revision_id"], name: "field_data_field_image_revision_id"

  create_table "field_data_field_img_cover", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                      limit: 128, default: "", null: false
    t.integer "deleted",                                 default: 0,  null: false
    t.integer "entity_id",                                            null: false
    t.integer "revision_id"
    t.string  "language",                    limit: 32,  default: "", null: false
    t.integer "delta",                                                null: false
    t.integer "field_img_cover_fid"
    t.integer "field_img_cover_display",                 default: 1,  null: false
    t.text    "field_img_cover_description"
  end

  add_index "field_data_field_img_cover", ["bundle"], name: "field_data_field_img_cover_bundle"
  add_index "field_data_field_img_cover", ["deleted"], name: "field_data_field_img_cover_deleted"
  add_index "field_data_field_img_cover", ["entity_id"], name: "field_data_field_img_cover_entity_id"
  add_index "field_data_field_img_cover", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_img_cover_1", unique: true
  add_index "field_data_field_img_cover", ["entity_type"], name: "field_data_field_img_cover_entity_type"
  add_index "field_data_field_img_cover", ["field_img_cover_fid"], name: "field_data_field_img_cover_field_img_cover_fid"
  add_index "field_data_field_img_cover", ["language"], name: "field_data_field_img_cover_language"
  add_index "field_data_field_img_cover", ["revision_id"], name: "field_data_field_img_cover_revision_id"

  create_table "field_data_field_img_title", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id"
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.text    "field_img_title_value"
    t.string  "field_img_title_format"
  end

  add_index "field_data_field_img_title", ["bundle"], name: "field_data_field_img_title_bundle"
  add_index "field_data_field_img_title", ["deleted"], name: "field_data_field_img_title_deleted"
  add_index "field_data_field_img_title", ["entity_id"], name: "field_data_field_img_title_entity_id"
  add_index "field_data_field_img_title", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_img_title_1", unique: true
  add_index "field_data_field_img_title", ["entity_type"], name: "field_data_field_img_title_entity_type"
  add_index "field_data_field_img_title", ["field_img_title_format"], name: "field_data_field_img_title_field_img_title_format"
  add_index "field_data_field_img_title", ["language"], name: "field_data_field_img_title_language"
  add_index "field_data_field_img_title", ["revision_id"], name: "field_data_field_img_title_revision_id"

  create_table "field_data_field_keywords", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                limit: 128, default: "", null: false
    t.integer "deleted",                           default: 0,  null: false
    t.integer "entity_id",                                      null: false
    t.integer "revision_id"
    t.string  "language",              limit: 32,  default: "", null: false
    t.integer "delta",                                          null: false
    t.text    "field_keywords_value"
    t.string  "field_keywords_format"
  end

  add_index "field_data_field_keywords", ["bundle"], name: "field_data_field_keywords_bundle"
  add_index "field_data_field_keywords", ["deleted"], name: "field_data_field_keywords_deleted"
  add_index "field_data_field_keywords", ["entity_id"], name: "field_data_field_keywords_entity_id"
  add_index "field_data_field_keywords", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_keywords_1", unique: true
  add_index "field_data_field_keywords", ["entity_type"], name: "field_data_field_keywords_entity_type"
  add_index "field_data_field_keywords", ["field_keywords_format"], name: "field_data_field_keywords_field_keywords_format"
  add_index "field_data_field_keywords", ["language"], name: "field_data_field_keywords_language"
  add_index "field_data_field_keywords", ["revision_id"], name: "field_data_field_keywords_revision_id"

  create_table "field_data_field_links", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128, default: "", null: false
    t.integer "deleted",                        default: 0,  null: false
    t.integer "entity_id",                                   null: false
    t.integer "revision_id"
    t.string  "language",           limit: 32,  default: "", null: false
    t.integer "delta",                                       null: false
    t.text    "field_links_value"
    t.string  "field_links_format"
  end

  add_index "field_data_field_links", ["bundle"], name: "field_data_field_links_bundle"
  add_index "field_data_field_links", ["deleted"], name: "field_data_field_links_deleted"
  add_index "field_data_field_links", ["entity_id"], name: "field_data_field_links_entity_id"
  add_index "field_data_field_links", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_links_1", unique: true
  add_index "field_data_field_links", ["entity_type"], name: "field_data_field_links_entity_type"
  add_index "field_data_field_links", ["field_links_format"], name: "field_data_field_links_field_links_format"
  add_index "field_data_field_links", ["language"], name: "field_data_field_links_language"
  add_index "field_data_field_links", ["revision_id"], name: "field_data_field_links_revision_id"

  create_table "field_data_field_ocr", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",           limit: 128, default: "", null: false
    t.integer "deleted",                      default: 0,  null: false
    t.integer "entity_id",                                 null: false
    t.integer "revision_id"
    t.string  "language",         limit: 32,  default: "", null: false
    t.integer "delta",                                     null: false
    t.text    "field_ocr_value"
    t.string  "field_ocr_format"
  end

  add_index "field_data_field_ocr", ["bundle"], name: "field_data_field_ocr_bundle"
  add_index "field_data_field_ocr", ["deleted"], name: "field_data_field_ocr_deleted"
  add_index "field_data_field_ocr", ["entity_id"], name: "field_data_field_ocr_entity_id"
  add_index "field_data_field_ocr", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_ocr_1", unique: true
  add_index "field_data_field_ocr", ["entity_type"], name: "field_data_field_ocr_entity_type"
  add_index "field_data_field_ocr", ["field_ocr_format"], name: "field_data_field_ocr_field_ocr_format"
  add_index "field_data_field_ocr", ["language"], name: "field_data_field_ocr_language"
  add_index "field_data_field_ocr", ["revision_id"], name: "field_data_field_ocr_revision_id"

  create_table "field_data_field_subfolder", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id"
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.string  "field_subfolder_value"
    t.string  "field_subfolder_format"
  end

  add_index "field_data_field_subfolder", ["bundle"], name: "field_data_field_subfolder_bundle"
  add_index "field_data_field_subfolder", ["deleted"], name: "field_data_field_subfolder_deleted"
  add_index "field_data_field_subfolder", ["entity_id"], name: "field_data_field_subfolder_entity_id"
  add_index "field_data_field_subfolder", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_subfolder_1", unique: true
  add_index "field_data_field_subfolder", ["entity_type"], name: "field_data_field_subfolder_entity_type"
  add_index "field_data_field_subfolder", ["field_subfolder_format"], name: "field_data_field_subfolder_field_subfolder_format"
  add_index "field_data_field_subfolder", ["language"], name: "field_data_field_subfolder_language"
  add_index "field_data_field_subfolder", ["revision_id"], name: "field_data_field_subfolder_revision_id"

  create_table "field_data_field_tags", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",         limit: 128, default: "", null: false
    t.integer "deleted",                    default: 0,  null: false
    t.integer "entity_id",                               null: false
    t.integer "revision_id"
    t.string  "language",       limit: 32,  default: "", null: false
    t.integer "delta",                                   null: false
    t.integer "field_tags_tid"
  end

  add_index "field_data_field_tags", ["bundle"], name: "field_data_field_tags_bundle"
  add_index "field_data_field_tags", ["deleted"], name: "field_data_field_tags_deleted"
  add_index "field_data_field_tags", ["entity_id"], name: "field_data_field_tags_entity_id"
  add_index "field_data_field_tags", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_tags_1", unique: true
  add_index "field_data_field_tags", ["entity_type"], name: "field_data_field_tags_entity_type"
  add_index "field_data_field_tags", ["field_tags_tid"], name: "field_data_field_tags_field_tags_tid"
  add_index "field_data_field_tags", ["language"], name: "field_data_field_tags_language"
  add_index "field_data_field_tags", ["revision_id"], name: "field_data_field_tags_revision_id"

  create_table "field_data_field_taxonomy", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128, default: "", null: false
    t.integer "deleted",                        default: 0,  null: false
    t.integer "entity_id",                                   null: false
    t.integer "revision_id"
    t.string  "language",           limit: 32,  default: "", null: false
    t.integer "delta",                                       null: false
    t.integer "field_taxonomy_tid"
  end

  add_index "field_data_field_taxonomy", ["bundle"], name: "field_data_field_taxonomy_bundle"
  add_index "field_data_field_taxonomy", ["deleted"], name: "field_data_field_taxonomy_deleted"
  add_index "field_data_field_taxonomy", ["entity_id"], name: "field_data_field_taxonomy_entity_id"
  add_index "field_data_field_taxonomy", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_taxonomy_1", unique: true
  add_index "field_data_field_taxonomy", ["entity_type"], name: "field_data_field_taxonomy_entity_type"
  add_index "field_data_field_taxonomy", ["field_taxonomy_tid"], name: "field_data_field_taxonomy_field_taxonomy_tid"
  add_index "field_data_field_taxonomy", ["language"], name: "field_data_field_taxonomy_language"
  add_index "field_data_field_taxonomy", ["revision_id"], name: "field_data_field_taxonomy_revision_id"

  create_table "field_data_field_taxonomy_alpha", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id"
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.integer "field_taxonomy_alpha_tid"
  end

  add_index "field_data_field_taxonomy_alpha", ["bundle"], name: "field_data_field_taxonomy_alpha_bundle"
  add_index "field_data_field_taxonomy_alpha", ["deleted"], name: "field_data_field_taxonomy_alpha_deleted"
  add_index "field_data_field_taxonomy_alpha", ["entity_id"], name: "field_data_field_taxonomy_alpha_entity_id"
  add_index "field_data_field_taxonomy_alpha", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_taxonomy_alpha_1", unique: true
  add_index "field_data_field_taxonomy_alpha", ["entity_type"], name: "field_data_field_taxonomy_alpha_entity_type"
  add_index "field_data_field_taxonomy_alpha", ["field_taxonomy_alpha_tid"], name: "field_data_field_taxonomy_alpha_field_taxonomy_alpha_tid"
  add_index "field_data_field_taxonomy_alpha", ["language"], name: "field_data_field_taxonomy_alpha_language"
  add_index "field_data_field_taxonomy_alpha", ["revision_id"], name: "field_data_field_taxonomy_alpha_revision_id"

  create_table "field_data_field_taxonomy_book", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                  limit: 128, default: "", null: false
    t.integer "deleted",                             default: 0,  null: false
    t.integer "entity_id",                                        null: false
    t.integer "revision_id"
    t.string  "language",                limit: 32,  default: "", null: false
    t.integer "delta",                                            null: false
    t.integer "field_taxonomy_book_tid"
  end

  add_index "field_data_field_taxonomy_book", ["bundle"], name: "field_data_field_taxonomy_book_bundle"
  add_index "field_data_field_taxonomy_book", ["deleted"], name: "field_data_field_taxonomy_book_deleted"
  add_index "field_data_field_taxonomy_book", ["entity_id"], name: "field_data_field_taxonomy_book_entity_id"
  add_index "field_data_field_taxonomy_book", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_taxonomy_book_1", unique: true
  add_index "field_data_field_taxonomy_book", ["entity_type"], name: "field_data_field_taxonomy_book_entity_type"
  add_index "field_data_field_taxonomy_book", ["field_taxonomy_book_tid"], name: "field_data_field_taxonomy_book_field_taxonomy_book_tid"
  add_index "field_data_field_taxonomy_book", ["language"], name: "field_data_field_taxonomy_book_language"
  add_index "field_data_field_taxonomy_book", ["revision_id"], name: "field_data_field_taxonomy_book_revision_id"

  create_table "field_data_field_url", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",           limit: 128, default: "", null: false
    t.integer "deleted",                      default: 0,  null: false
    t.integer "entity_id",                                 null: false
    t.integer "revision_id"
    t.string  "language",         limit: 32,  default: "", null: false
    t.integer "delta",                                     null: false
    t.string  "field_url_value"
    t.string  "field_url_format"
  end

  add_index "field_data_field_url", ["bundle"], name: "field_data_field_url_bundle"
  add_index "field_data_field_url", ["deleted"], name: "field_data_field_url_deleted"
  add_index "field_data_field_url", ["entity_id"], name: "field_data_field_url_entity_id"
  add_index "field_data_field_url", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_url_1", unique: true
  add_index "field_data_field_url", ["entity_type"], name: "field_data_field_url_entity_type"
  add_index "field_data_field_url", ["field_url_format"], name: "field_data_field_url_field_url_format"
  add_index "field_data_field_url", ["language"], name: "field_data_field_url_language"
  add_index "field_data_field_url", ["revision_id"], name: "field_data_field_url_revision_id"

  create_table "field_data_field_year", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",            limit: 128, default: "", null: false
    t.integer "deleted",                       default: 0,  null: false
    t.integer "entity_id",                                  null: false
    t.integer "revision_id"
    t.string  "language",          limit: 32,  default: "", null: false
    t.integer "delta",                                      null: false
    t.string  "field_year_value",  limit: 10
    t.string  "field_year_format"
  end

  add_index "field_data_field_year", ["bundle"], name: "field_data_field_year_bundle"
  add_index "field_data_field_year", ["deleted"], name: "field_data_field_year_deleted"
  add_index "field_data_field_year", ["entity_id"], name: "field_data_field_year_entity_id"
  add_index "field_data_field_year", ["entity_type", "entity_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_data_field_year_1", unique: true
  add_index "field_data_field_year", ["entity_type"], name: "field_data_field_year_entity_type"
  add_index "field_data_field_year", ["field_year_format"], name: "field_data_field_year_field_year_format"
  add_index "field_data_field_year", ["language"], name: "field_data_field_year_language"
  add_index "field_data_field_year", ["revision_id"], name: "field_data_field_year_revision_id"

  create_table "field_revision_body", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",       limit: 128, default: "", null: false
    t.integer "deleted",                  default: 0,  null: false
    t.integer "entity_id",                             null: false
    t.integer "revision_id",                           null: false
    t.string  "language",     limit: 32,  default: "", null: false
    t.integer "delta",                                 null: false
    t.text    "body_value"
    t.text    "body_summary"
    t.string  "body_format"
  end

  add_index "field_revision_body", ["body_format"], name: "field_revision_body_body_format"
  add_index "field_revision_body", ["bundle"], name: "field_revision_body_bundle"
  add_index "field_revision_body", ["deleted"], name: "field_revision_body_deleted"
  add_index "field_revision_body", ["entity_id"], name: "field_revision_body_entity_id"
  add_index "field_revision_body", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_body_1", unique: true
  add_index "field_revision_body", ["entity_type"], name: "field_revision_body_entity_type"
  add_index "field_revision_body", ["language"], name: "field_revision_body_language"
  add_index "field_revision_body", ["revision_id"], name: "field_revision_body_revision_id"

  create_table "field_revision_comment_body", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",              limit: 128, default: "", null: false
    t.integer "deleted",                         default: 0,  null: false
    t.integer "entity_id",                                    null: false
    t.integer "revision_id",                                  null: false
    t.string  "language",            limit: 32,  default: "", null: false
    t.integer "delta",                                        null: false
    t.text    "comment_body_value"
    t.string  "comment_body_format"
  end

  add_index "field_revision_comment_body", ["bundle"], name: "field_revision_comment_body_bundle"
  add_index "field_revision_comment_body", ["comment_body_format"], name: "field_revision_comment_body_comment_body_format"
  add_index "field_revision_comment_body", ["deleted"], name: "field_revision_comment_body_deleted"
  add_index "field_revision_comment_body", ["entity_id"], name: "field_revision_comment_body_entity_id"
  add_index "field_revision_comment_body", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_comment_body_1", unique: true
  add_index "field_revision_comment_body", ["entity_type"], name: "field_revision_comment_body_entity_type"
  add_index "field_revision_comment_body", ["language"], name: "field_revision_comment_body_language"
  add_index "field_revision_comment_body", ["revision_id"], name: "field_revision_comment_body_revision_id"

  create_table "field_revision_field_book_author", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id",                                       null: false
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.string  "field_book_author_value",  limit: 60
    t.string  "field_book_author_format"
  end

  add_index "field_revision_field_book_author", ["bundle"], name: "field_revision_field_book_author_bundle"
  add_index "field_revision_field_book_author", ["deleted"], name: "field_revision_field_book_author_deleted"
  add_index "field_revision_field_book_author", ["entity_id"], name: "field_revision_field_book_author_entity_id"
  add_index "field_revision_field_book_author", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_book_author_1", unique: true
  add_index "field_revision_field_book_author", ["entity_type"], name: "field_revision_field_book_author_entity_type"
  add_index "field_revision_field_book_author", ["field_book_author_format"], name: "field_revision_field_book_author_field_book_author_format"
  add_index "field_revision_field_book_author", ["language"], name: "field_revision_field_book_author_language"
  add_index "field_revision_field_book_author", ["revision_id"], name: "field_revision_field_book_author_revision_id"

  create_table "field_revision_field_book_file", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                      limit: 128, default: "", null: false
    t.integer "deleted",                                 default: 0,  null: false
    t.integer "entity_id",                                            null: false
    t.integer "revision_id",                                          null: false
    t.string  "language",                    limit: 32,  default: "", null: false
    t.integer "delta",                                                null: false
    t.integer "field_book_file_fid"
    t.integer "field_book_file_display",                 default: 1,  null: false
    t.text    "field_book_file_description"
  end

  add_index "field_revision_field_book_file", ["bundle"], name: "field_revision_field_book_file_bundle"
  add_index "field_revision_field_book_file", ["deleted"], name: "field_revision_field_book_file_deleted"
  add_index "field_revision_field_book_file", ["entity_id"], name: "field_revision_field_book_file_entity_id"
  add_index "field_revision_field_book_file", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_book_file_1", unique: true
  add_index "field_revision_field_book_file", ["entity_type"], name: "field_revision_field_book_file_entity_type"
  add_index "field_revision_field_book_file", ["field_book_file_fid"], name: "field_revision_field_book_file_field_book_file_fid"
  add_index "field_revision_field_book_file", ["language"], name: "field_revision_field_book_file_language"
  add_index "field_revision_field_book_file", ["revision_id"], name: "field_revision_field_book_file_revision_id"

  create_table "field_revision_field_book_filename", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                     limit: 128, default: "", null: false
    t.integer "deleted",                                default: 0,  null: false
    t.integer "entity_id",                                           null: false
    t.integer "revision_id",                                         null: false
    t.string  "language",                   limit: 32,  default: "", null: false
    t.integer "delta",                                               null: false
    t.string  "field_book_filename_value"
    t.string  "field_book_filename_format"
  end

  add_index "field_revision_field_book_filename", ["bundle"], name: "field_revision_field_book_filename_bundle"
  add_index "field_revision_field_book_filename", ["deleted"], name: "field_revision_field_book_filename_deleted"
  add_index "field_revision_field_book_filename", ["entity_id"], name: "field_revision_field_book_filename_entity_id"
  add_index "field_revision_field_book_filename", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_book_filename_1", unique: true
  add_index "field_revision_field_book_filename", ["entity_type"], name: "field_revision_field_book_filename_entity_type"
  add_index "field_revision_field_book_filename", ["field_book_filename_format"], name: "field_revision_field_book_filename_field_book_filename_format"
  add_index "field_revision_field_book_filename", ["language"], name: "field_revision_field_book_filename_language"
  add_index "field_revision_field_book_filename", ["revision_id"], name: "field_revision_field_book_filename_revision_id"

  create_table "field_revision_field_book_img", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                limit: 128,  default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id",                                     null: false
    t.string  "language",              limit: 32,   default: "", null: false
    t.integer "delta",                                           null: false
    t.integer "field_book_img_fid"
    t.string  "field_book_img_alt",    limit: 512
    t.string  "field_book_img_title",  limit: 1024
    t.integer "field_book_img_width"
    t.integer "field_book_img_height"
  end

  add_index "field_revision_field_book_img", ["bundle"], name: "field_revision_field_book_img_bundle"
  add_index "field_revision_field_book_img", ["deleted"], name: "field_revision_field_book_img_deleted"
  add_index "field_revision_field_book_img", ["entity_id"], name: "field_revision_field_book_img_entity_id"
  add_index "field_revision_field_book_img", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_book_img_1", unique: true
  add_index "field_revision_field_book_img", ["entity_type"], name: "field_revision_field_book_img_entity_type"
  add_index "field_revision_field_book_img", ["field_book_img_fid"], name: "field_revision_field_book_img_field_book_img_fid"
  add_index "field_revision_field_book_img", ["language"], name: "field_revision_field_book_img_language"
  add_index "field_revision_field_book_img", ["revision_id"], name: "field_revision_field_book_img_revision_id"

  create_table "field_revision_field_book_name", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id",                                     null: false
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.string  "field_book_name_value"
    t.string  "field_book_name_format"
  end

  add_index "field_revision_field_book_name", ["bundle"], name: "field_revision_field_book_name_bundle"
  add_index "field_revision_field_book_name", ["deleted"], name: "field_revision_field_book_name_deleted"
  add_index "field_revision_field_book_name", ["entity_id"], name: "field_revision_field_book_name_entity_id"
  add_index "field_revision_field_book_name", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_book_name_1", unique: true
  add_index "field_revision_field_book_name", ["entity_type"], name: "field_revision_field_book_name_entity_type"
  add_index "field_revision_field_book_name", ["field_book_name_format"], name: "field_revision_field_book_name_field_book_name_format"
  add_index "field_revision_field_book_name", ["language"], name: "field_revision_field_book_name_language"
  add_index "field_revision_field_book_name", ["revision_id"], name: "field_revision_field_book_name_revision_id"

  create_table "field_revision_field_code", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",            limit: 128, default: "", null: false
    t.integer "deleted",                       default: 0,  null: false
    t.integer "entity_id",                                  null: false
    t.integer "revision_id",                                null: false
    t.string  "language",          limit: 32,  default: "", null: false
    t.integer "delta",                                      null: false
    t.text    "field_code_value"
    t.string  "field_code_format"
  end

  add_index "field_revision_field_code", ["bundle"], name: "field_revision_field_code_bundle"
  add_index "field_revision_field_code", ["deleted"], name: "field_revision_field_code_deleted"
  add_index "field_revision_field_code", ["entity_id"], name: "field_revision_field_code_entity_id"
  add_index "field_revision_field_code", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_code_1", unique: true
  add_index "field_revision_field_code", ["entity_type"], name: "field_revision_field_code_entity_type"
  add_index "field_revision_field_code", ["field_code_format"], name: "field_revision_field_code_field_code_format"
  add_index "field_revision_field_code", ["language"], name: "field_revision_field_code_language"
  add_index "field_revision_field_code", ["revision_id"], name: "field_revision_field_code_revision_id"

  create_table "field_revision_field_content_files", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                     limit: 128, default: "", null: false
    t.integer "deleted",                                default: 0,  null: false
    t.integer "entity_id",                                           null: false
    t.integer "revision_id",                                         null: false
    t.string  "language",                   limit: 32,  default: "", null: false
    t.integer "delta",                                               null: false
    t.string  "field_content_files_value"
    t.string  "field_content_files_format"
  end

  add_index "field_revision_field_content_files", ["bundle"], name: "field_revision_field_content_files_bundle"
  add_index "field_revision_field_content_files", ["deleted"], name: "field_revision_field_content_files_deleted"
  add_index "field_revision_field_content_files", ["entity_id"], name: "field_revision_field_content_files_entity_id"
  add_index "field_revision_field_content_files", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_content_files_1", unique: true
  add_index "field_revision_field_content_files", ["entity_type"], name: "field_revision_field_content_files_entity_type"
  add_index "field_revision_field_content_files", ["field_content_files_format"], name: "field_revision_field_content_files_field_content_files_format"
  add_index "field_revision_field_content_files", ["language"], name: "field_revision_field_content_files_language"
  add_index "field_revision_field_content_files", ["revision_id"], name: "field_revision_field_content_files_revision_id"

  create_table "field_revision_field_content_location", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                        limit: 128, default: "", null: false
    t.integer "deleted",                                   default: 0,  null: false
    t.integer "entity_id",                                              null: false
    t.integer "revision_id",                                            null: false
    t.string  "language",                      limit: 32,  default: "", null: false
    t.integer "delta",                                                  null: false
    t.string  "field_content_location_value"
    t.string  "field_content_location_format"
  end

  add_index "field_revision_field_content_location", ["bundle"], name: "field_revision_field_content_location_bundle"
  add_index "field_revision_field_content_location", ["deleted"], name: "field_revision_field_content_location_deleted"
  add_index "field_revision_field_content_location", ["entity_id"], name: "field_revision_field_content_location_entity_id"
  add_index "field_revision_field_content_location", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_content_location_1", unique: true
  add_index "field_revision_field_content_location", ["entity_type"], name: "field_revision_field_content_location_entity_type"
  add_index "field_revision_field_content_location", ["field_content_location_format"], name: "field_revision_field_content_location_field_content_location_format"
  add_index "field_revision_field_content_location", ["language"], name: "field_revision_field_content_location_language"
  add_index "field_revision_field_content_location", ["revision_id"], name: "field_revision_field_content_location_revision_id"

  create_table "field_revision_field_description", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id",                                       null: false
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.text    "field_description_value"
    t.string  "field_description_format"
  end

  add_index "field_revision_field_description", ["bundle"], name: "field_revision_field_description_bundle"
  add_index "field_revision_field_description", ["deleted"], name: "field_revision_field_description_deleted"
  add_index "field_revision_field_description", ["entity_id"], name: "field_revision_field_description_entity_id"
  add_index "field_revision_field_description", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_description_1", unique: true
  add_index "field_revision_field_description", ["entity_type"], name: "field_revision_field_description_entity_type"
  add_index "field_revision_field_description", ["field_description_format"], name: "field_revision_field_description_field_description_format"
  add_index "field_revision_field_description", ["language"], name: "field_revision_field_description_language"
  add_index "field_revision_field_description", ["revision_id"], name: "field_revision_field_description_revision_id"

  create_table "field_revision_field_image", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128,  default: "", null: false
    t.integer "deleted",                         default: 0,  null: false
    t.integer "entity_id",                                    null: false
    t.integer "revision_id",                                  null: false
    t.string  "language",           limit: 32,   default: "", null: false
    t.integer "delta",                                        null: false
    t.integer "field_image_fid"
    t.string  "field_image_alt",    limit: 512
    t.string  "field_image_title",  limit: 1024
    t.integer "field_image_width"
    t.integer "field_image_height"
  end

  add_index "field_revision_field_image", ["bundle"], name: "field_revision_field_image_bundle"
  add_index "field_revision_field_image", ["deleted"], name: "field_revision_field_image_deleted"
  add_index "field_revision_field_image", ["entity_id"], name: "field_revision_field_image_entity_id"
  add_index "field_revision_field_image", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_image_1", unique: true
  add_index "field_revision_field_image", ["entity_type"], name: "field_revision_field_image_entity_type"
  add_index "field_revision_field_image", ["field_image_fid"], name: "field_revision_field_image_field_image_fid"
  add_index "field_revision_field_image", ["language"], name: "field_revision_field_image_language"
  add_index "field_revision_field_image", ["revision_id"], name: "field_revision_field_image_revision_id"

  create_table "field_revision_field_img_cover", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                      limit: 128, default: "", null: false
    t.integer "deleted",                                 default: 0,  null: false
    t.integer "entity_id",                                            null: false
    t.integer "revision_id",                                          null: false
    t.string  "language",                    limit: 32,  default: "", null: false
    t.integer "delta",                                                null: false
    t.integer "field_img_cover_fid"
    t.integer "field_img_cover_display",                 default: 1,  null: false
    t.text    "field_img_cover_description"
  end

  add_index "field_revision_field_img_cover", ["bundle"], name: "field_revision_field_img_cover_bundle"
  add_index "field_revision_field_img_cover", ["deleted"], name: "field_revision_field_img_cover_deleted"
  add_index "field_revision_field_img_cover", ["entity_id"], name: "field_revision_field_img_cover_entity_id"
  add_index "field_revision_field_img_cover", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_img_cover_1", unique: true
  add_index "field_revision_field_img_cover", ["entity_type"], name: "field_revision_field_img_cover_entity_type"
  add_index "field_revision_field_img_cover", ["field_img_cover_fid"], name: "field_revision_field_img_cover_field_img_cover_fid"
  add_index "field_revision_field_img_cover", ["language"], name: "field_revision_field_img_cover_language"
  add_index "field_revision_field_img_cover", ["revision_id"], name: "field_revision_field_img_cover_revision_id"

  create_table "field_revision_field_img_title", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id",                                     null: false
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.text    "field_img_title_value"
    t.string  "field_img_title_format"
  end

  add_index "field_revision_field_img_title", ["bundle"], name: "field_revision_field_img_title_bundle"
  add_index "field_revision_field_img_title", ["deleted"], name: "field_revision_field_img_title_deleted"
  add_index "field_revision_field_img_title", ["entity_id"], name: "field_revision_field_img_title_entity_id"
  add_index "field_revision_field_img_title", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_img_title_1", unique: true
  add_index "field_revision_field_img_title", ["entity_type"], name: "field_revision_field_img_title_entity_type"
  add_index "field_revision_field_img_title", ["field_img_title_format"], name: "field_revision_field_img_title_field_img_title_format"
  add_index "field_revision_field_img_title", ["language"], name: "field_revision_field_img_title_language"
  add_index "field_revision_field_img_title", ["revision_id"], name: "field_revision_field_img_title_revision_id"

  create_table "field_revision_field_keywords", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                limit: 128, default: "", null: false
    t.integer "deleted",                           default: 0,  null: false
    t.integer "entity_id",                                      null: false
    t.integer "revision_id",                                    null: false
    t.string  "language",              limit: 32,  default: "", null: false
    t.integer "delta",                                          null: false
    t.text    "field_keywords_value"
    t.string  "field_keywords_format"
  end

  add_index "field_revision_field_keywords", ["bundle"], name: "field_revision_field_keywords_bundle"
  add_index "field_revision_field_keywords", ["deleted"], name: "field_revision_field_keywords_deleted"
  add_index "field_revision_field_keywords", ["entity_id"], name: "field_revision_field_keywords_entity_id"
  add_index "field_revision_field_keywords", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_keywords_1", unique: true
  add_index "field_revision_field_keywords", ["entity_type"], name: "field_revision_field_keywords_entity_type"
  add_index "field_revision_field_keywords", ["field_keywords_format"], name: "field_revision_field_keywords_field_keywords_format"
  add_index "field_revision_field_keywords", ["language"], name: "field_revision_field_keywords_language"
  add_index "field_revision_field_keywords", ["revision_id"], name: "field_revision_field_keywords_revision_id"

  create_table "field_revision_field_links", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128, default: "", null: false
    t.integer "deleted",                        default: 0,  null: false
    t.integer "entity_id",                                   null: false
    t.integer "revision_id",                                 null: false
    t.string  "language",           limit: 32,  default: "", null: false
    t.integer "delta",                                       null: false
    t.text    "field_links_value"
    t.string  "field_links_format"
  end

  add_index "field_revision_field_links", ["bundle"], name: "field_revision_field_links_bundle"
  add_index "field_revision_field_links", ["deleted"], name: "field_revision_field_links_deleted"
  add_index "field_revision_field_links", ["entity_id"], name: "field_revision_field_links_entity_id"
  add_index "field_revision_field_links", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_links_1", unique: true
  add_index "field_revision_field_links", ["entity_type"], name: "field_revision_field_links_entity_type"
  add_index "field_revision_field_links", ["field_links_format"], name: "field_revision_field_links_field_links_format"
  add_index "field_revision_field_links", ["language"], name: "field_revision_field_links_language"
  add_index "field_revision_field_links", ["revision_id"], name: "field_revision_field_links_revision_id"

  create_table "field_revision_field_ocr", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",           limit: 128, default: "", null: false
    t.integer "deleted",                      default: 0,  null: false
    t.integer "entity_id",                                 null: false
    t.integer "revision_id",                               null: false
    t.string  "language",         limit: 32,  default: "", null: false
    t.integer "delta",                                     null: false
    t.text    "field_ocr_value"
    t.string  "field_ocr_format"
  end

  add_index "field_revision_field_ocr", ["bundle"], name: "field_revision_field_ocr_bundle"
  add_index "field_revision_field_ocr", ["deleted"], name: "field_revision_field_ocr_deleted"
  add_index "field_revision_field_ocr", ["entity_id"], name: "field_revision_field_ocr_entity_id"
  add_index "field_revision_field_ocr", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_ocr_1", unique: true
  add_index "field_revision_field_ocr", ["entity_type"], name: "field_revision_field_ocr_entity_type"
  add_index "field_revision_field_ocr", ["field_ocr_format"], name: "field_revision_field_ocr_field_ocr_format"
  add_index "field_revision_field_ocr", ["language"], name: "field_revision_field_ocr_language"
  add_index "field_revision_field_ocr", ["revision_id"], name: "field_revision_field_ocr_revision_id"

  create_table "field_revision_field_subfolder", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                 limit: 128, default: "", null: false
    t.integer "deleted",                            default: 0,  null: false
    t.integer "entity_id",                                       null: false
    t.integer "revision_id",                                     null: false
    t.string  "language",               limit: 32,  default: "", null: false
    t.integer "delta",                                           null: false
    t.string  "field_subfolder_value"
    t.string  "field_subfolder_format"
  end

  add_index "field_revision_field_subfolder", ["bundle"], name: "field_revision_field_subfolder_bundle"
  add_index "field_revision_field_subfolder", ["deleted"], name: "field_revision_field_subfolder_deleted"
  add_index "field_revision_field_subfolder", ["entity_id"], name: "field_revision_field_subfolder_entity_id"
  add_index "field_revision_field_subfolder", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_subfolder_1", unique: true
  add_index "field_revision_field_subfolder", ["entity_type"], name: "field_revision_field_subfolder_entity_type"
  add_index "field_revision_field_subfolder", ["field_subfolder_format"], name: "field_revision_field_subfolder_field_subfolder_format"
  add_index "field_revision_field_subfolder", ["language"], name: "field_revision_field_subfolder_language"
  add_index "field_revision_field_subfolder", ["revision_id"], name: "field_revision_field_subfolder_revision_id"

  create_table "field_revision_field_tags", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",         limit: 128, default: "", null: false
    t.integer "deleted",                    default: 0,  null: false
    t.integer "entity_id",                               null: false
    t.integer "revision_id",                             null: false
    t.string  "language",       limit: 32,  default: "", null: false
    t.integer "delta",                                   null: false
    t.integer "field_tags_tid"
  end

  add_index "field_revision_field_tags", ["bundle"], name: "field_revision_field_tags_bundle"
  add_index "field_revision_field_tags", ["deleted"], name: "field_revision_field_tags_deleted"
  add_index "field_revision_field_tags", ["entity_id"], name: "field_revision_field_tags_entity_id"
  add_index "field_revision_field_tags", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_tags_1", unique: true
  add_index "field_revision_field_tags", ["entity_type"], name: "field_revision_field_tags_entity_type"
  add_index "field_revision_field_tags", ["field_tags_tid"], name: "field_revision_field_tags_field_tags_tid"
  add_index "field_revision_field_tags", ["language"], name: "field_revision_field_tags_language"
  add_index "field_revision_field_tags", ["revision_id"], name: "field_revision_field_tags_revision_id"

  create_table "field_revision_field_taxonomy", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",             limit: 128, default: "", null: false
    t.integer "deleted",                        default: 0,  null: false
    t.integer "entity_id",                                   null: false
    t.integer "revision_id",                                 null: false
    t.string  "language",           limit: 32,  default: "", null: false
    t.integer "delta",                                       null: false
    t.integer "field_taxonomy_tid"
  end

  add_index "field_revision_field_taxonomy", ["bundle"], name: "field_revision_field_taxonomy_bundle"
  add_index "field_revision_field_taxonomy", ["deleted"], name: "field_revision_field_taxonomy_deleted"
  add_index "field_revision_field_taxonomy", ["entity_id"], name: "field_revision_field_taxonomy_entity_id"
  add_index "field_revision_field_taxonomy", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_taxonomy_1", unique: true
  add_index "field_revision_field_taxonomy", ["entity_type"], name: "field_revision_field_taxonomy_entity_type"
  add_index "field_revision_field_taxonomy", ["field_taxonomy_tid"], name: "field_revision_field_taxonomy_field_taxonomy_tid"
  add_index "field_revision_field_taxonomy", ["language"], name: "field_revision_field_taxonomy_language"
  add_index "field_revision_field_taxonomy", ["revision_id"], name: "field_revision_field_taxonomy_revision_id"

  create_table "field_revision_field_taxonomy_alpha", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                   limit: 128, default: "", null: false
    t.integer "deleted",                              default: 0,  null: false
    t.integer "entity_id",                                         null: false
    t.integer "revision_id",                                       null: false
    t.string  "language",                 limit: 32,  default: "", null: false
    t.integer "delta",                                             null: false
    t.integer "field_taxonomy_alpha_tid"
  end

  add_index "field_revision_field_taxonomy_alpha", ["bundle"], name: "field_revision_field_taxonomy_alpha_bundle"
  add_index "field_revision_field_taxonomy_alpha", ["deleted"], name: "field_revision_field_taxonomy_alpha_deleted"
  add_index "field_revision_field_taxonomy_alpha", ["entity_id"], name: "field_revision_field_taxonomy_alpha_entity_id"
  add_index "field_revision_field_taxonomy_alpha", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_taxonomy_alpha_1", unique: true
  add_index "field_revision_field_taxonomy_alpha", ["entity_type"], name: "field_revision_field_taxonomy_alpha_entity_type"
  add_index "field_revision_field_taxonomy_alpha", ["field_taxonomy_alpha_tid"], name: "field_revision_field_taxonomy_alpha_field_taxonomy_alpha_tid"
  add_index "field_revision_field_taxonomy_alpha", ["language"], name: "field_revision_field_taxonomy_alpha_language"
  add_index "field_revision_field_taxonomy_alpha", ["revision_id"], name: "field_revision_field_taxonomy_alpha_revision_id"

  create_table "field_revision_field_taxonomy_book", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",                  limit: 128, default: "", null: false
    t.integer "deleted",                             default: 0,  null: false
    t.integer "entity_id",                                        null: false
    t.integer "revision_id",                                      null: false
    t.string  "language",                limit: 32,  default: "", null: false
    t.integer "delta",                                            null: false
    t.integer "field_taxonomy_book_tid"
  end

  add_index "field_revision_field_taxonomy_book", ["bundle"], name: "field_revision_field_taxonomy_book_bundle"
  add_index "field_revision_field_taxonomy_book", ["deleted"], name: "field_revision_field_taxonomy_book_deleted"
  add_index "field_revision_field_taxonomy_book", ["entity_id"], name: "field_revision_field_taxonomy_book_entity_id"
  add_index "field_revision_field_taxonomy_book", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_taxonomy_book_1", unique: true
  add_index "field_revision_field_taxonomy_book", ["entity_type"], name: "field_revision_field_taxonomy_book_entity_type"
  add_index "field_revision_field_taxonomy_book", ["field_taxonomy_book_tid"], name: "field_revision_field_taxonomy_book_field_taxonomy_book_tid"
  add_index "field_revision_field_taxonomy_book", ["language"], name: "field_revision_field_taxonomy_book_language"
  add_index "field_revision_field_taxonomy_book", ["revision_id"], name: "field_revision_field_taxonomy_book_revision_id"

  create_table "field_revision_field_url", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",           limit: 128, default: "", null: false
    t.integer "deleted",                      default: 0,  null: false
    t.integer "entity_id",                                 null: false
    t.integer "revision_id",                               null: false
    t.string  "language",         limit: 32,  default: "", null: false
    t.integer "delta",                                     null: false
    t.string  "field_url_value"
    t.string  "field_url_format"
  end

  add_index "field_revision_field_url", ["bundle"], name: "field_revision_field_url_bundle"
  add_index "field_revision_field_url", ["deleted"], name: "field_revision_field_url_deleted"
  add_index "field_revision_field_url", ["entity_id"], name: "field_revision_field_url_entity_id"
  add_index "field_revision_field_url", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_url_1", unique: true
  add_index "field_revision_field_url", ["entity_type"], name: "field_revision_field_url_entity_type"
  add_index "field_revision_field_url", ["field_url_format"], name: "field_revision_field_url_field_url_format"
  add_index "field_revision_field_url", ["language"], name: "field_revision_field_url_language"
  add_index "field_revision_field_url", ["revision_id"], name: "field_revision_field_url_revision_id"

  create_table "field_revision_field_year", primary_key: "entity_type", force: true do |t|
    t.string  "bundle",            limit: 128, default: "", null: false
    t.integer "deleted",                       default: 0,  null: false
    t.integer "entity_id",                                  null: false
    t.integer "revision_id",                                null: false
    t.string  "language",          limit: 32,  default: "", null: false
    t.integer "delta",                                      null: false
    t.string  "field_year_value",  limit: 10
    t.string  "field_year_format"
  end

  add_index "field_revision_field_year", ["bundle"], name: "field_revision_field_year_bundle"
  add_index "field_revision_field_year", ["deleted"], name: "field_revision_field_year_deleted"
  add_index "field_revision_field_year", ["entity_id"], name: "field_revision_field_year_entity_id"
  add_index "field_revision_field_year", ["entity_type", "entity_id", "revision_id", "deleted", "delta", "language"], name: "sqlite_autoindex_field_revision_field_year_1", unique: true
  add_index "field_revision_field_year", ["entity_type"], name: "field_revision_field_year_entity_type"
  add_index "field_revision_field_year", ["field_year_format"], name: "field_revision_field_year_field_year_format"
  add_index "field_revision_field_year", ["language"], name: "field_revision_field_year_language"
  add_index "field_revision_field_year", ["revision_id"], name: "field_revision_field_year_revision_id"

  create_table "file_managed", primary_key: "fid", force: true do |t|
    t.integer "uid",       default: 0,  null: false
    t.string  "filename",  default: "", null: false
    t.string  "uri",       default: "", null: false
    t.string  "filemime",  default: "", null: false
    t.integer "filesize",  default: 0,  null: false
    t.integer "status",    default: 0,  null: false
    t.integer "timestamp", default: 0,  null: false
  end

  add_index "file_managed", ["status"], name: "file_managed_status"
  add_index "file_managed", ["timestamp"], name: "file_managed_timestamp"
  add_index "file_managed", ["uid"], name: "file_managed_uid"
  add_index "file_managed", ["uri"], name: "file_managed_uri", unique: true

  create_table "file_usage", primary_key: "fid", force: true do |t|
    t.string  "module",            default: "", null: false
    t.string  "type",   limit: 64, default: "", null: false
    t.integer "id",                default: 0,  null: false
    t.integer "count",             default: 0,  null: false
  end

  add_index "file_usage", ["fid", "count"], name: "file_usage_fid_count"
  add_index "file_usage", ["fid", "module"], name: "file_usage_fid_module"
  add_index "file_usage", ["fid", "type", "id", "module"], name: "sqlite_autoindex_file_usage_1", unique: true
  add_index "file_usage", ["type", "id"], name: "file_usage_type_id"

  create_table "filter", primary_key: "format", force: true do |t|
    t.string  "module",   limit: 64, default: "", null: false
    t.string  "name",     limit: 32, default: "", null: false
    t.integer "weight",              default: 0,  null: false
    t.integer "status",              default: 0,  null: false
    t.binary  "settings"
  end

  add_index "filter", ["format", "name"], name: "sqlite_autoindex_filter_1", unique: true
  add_index "filter", ["weight", "module", "name"], name: "filter_list"

  create_table "filter_format", primary_key: "format", force: true do |t|
    t.string  "name",   default: "", null: false
    t.integer "cache",  default: 0,  null: false
    t.integer "status", default: 1,  null: false
    t.integer "weight", default: 0,  null: false
  end

  add_index "filter_format", ["format"], name: "sqlite_autoindex_filter_format_1", unique: true
  add_index "filter_format", ["name"], name: "filter_format_name", unique: true
  add_index "filter_format", ["status", "weight"], name: "filter_format_status_weight"

  create_table "flood", primary_key: "fid", force: true do |t|
    t.string  "event",      limit: 64,  default: "", null: false
    t.string  "identifier", limit: 128, default: "", null: false
    t.integer "timestamp",              default: 0,  null: false
    t.integer "expiration",             default: 0,  null: false
  end

  create_table "history", primary_key: "uid", force: true do |t|
    t.integer "nid",       default: 0, null: false
    t.integer "timestamp", default: 0, null: false
  end

  add_index "history", ["uid", "nid"], name: "sqlite_autoindex_history_1", unique: true

  create_table "image_effects", primary_key: "ieid", force: true do |t|
    t.integer "isid",   default: 0, null: false
    t.integer "weight", default: 0, null: false
    t.string  "name",               null: false
    t.binary  "data",               null: false
  end

  add_index "image_effects", ["isid"], name: "image_effects_isid"
  add_index "image_effects", ["weight"], name: "image_effects_weight"

  create_table "image_styles", primary_key: "isid", force: true do |t|
    t.string "name",               null: false
    t.string "label", default: "", null: false
  end

  add_index "image_styles", ["name"], name: "image_styles_name", unique: true

  create_table "languages", primary_key: "language", force: true do |t|
    t.string  "name",       limit: 64,  default: "", null: false
    t.string  "native",     limit: 64,  default: "", null: false
    t.integer "direction",              default: 0,  null: false
    t.integer "enabled",                default: 0,  null: false
    t.integer "plurals",                default: 0,  null: false
    t.string  "formula",                default: "", null: false
    t.string  "domain",     limit: 128, default: "", null: false
    t.string  "prefix",     limit: 128, default: "", null: false
    t.integer "weight",                 default: 0,  null: false
    t.string  "javascript", limit: 64,  default: "", null: false
  end

  add_index "languages", ["language"], name: "sqlite_autoindex_languages_1", unique: true
  add_index "languages", ["weight", "name"], name: "languages_list"

  create_table "locales_source", primary_key: "lid", force: true do |t|
    t.text   "location"
    t.string "textgroup",            default: "default", null: false
    t.text   "source",                                   null: false
    t.string "context",              default: "",        null: false
    t.string "version",   limit: 20, default: "none",    null: false
  end

  add_index "locales_source", ["source", "context"], name: "locales_source_source_context"

  create_table "locales_target", primary_key: "lid", force: true do |t|
    t.text    "translation",                         null: false
    t.string  "language",    limit: 12, default: "", null: false
    t.integer "plid",                   default: 0,  null: false
    t.integer "plural",                 default: 0,  null: false
  end

  add_index "locales_target", ["language", "lid", "plural"], name: "sqlite_autoindex_locales_target_1", unique: true
  add_index "locales_target", ["lid"], name: "locales_target_lid"
  add_index "locales_target", ["plid"], name: "locales_target_plid"
  add_index "locales_target", ["plural"], name: "locales_target_plural"

  create_table "menu_custom", primary_key: "menu_name", force: true do |t|
    t.string "title",       default: "", null: false
    t.text   "description"
  end

  add_index "menu_custom", ["menu_name"], name: "sqlite_autoindex_menu_custom_1", unique: true

  create_table "menu_links", primary_key: "mlid", force: true do |t|
    t.string  "menu_name",    limit: 32, default: "",       null: false
    t.integer "plid",                    default: 0,        null: false
    t.string  "link_path",               default: "",       null: false
    t.string  "router_path",             default: "",       null: false
    t.string  "link_title",              default: "",       null: false
    t.binary  "options"
    t.string  "module",                  default: "system", null: false
    t.integer "hidden",                  default: 0,        null: false
    t.integer "external",                default: 0,        null: false
    t.integer "has_children",            default: 0,        null: false
    t.integer "expanded",                default: 0,        null: false
    t.integer "weight",                  default: 0,        null: false
    t.integer "depth",                   default: 0,        null: false
    t.integer "customized",              default: 0,        null: false
    t.integer "p1",                      default: 0,        null: false
    t.integer "p2",                      default: 0,        null: false
    t.integer "p3",                      default: 0,        null: false
    t.integer "p4",                      default: 0,        null: false
    t.integer "p5",                      default: 0,        null: false
    t.integer "p6",                      default: 0,        null: false
    t.integer "p7",                      default: 0,        null: false
    t.integer "p8",                      default: 0,        null: false
    t.integer "p9",                      default: 0,        null: false
    t.integer "updated",                 default: 0,        null: false
  end

  add_index "menu_links", ["link_path", "menu_name"], name: "menu_links_path_menu"
  add_index "menu_links", ["menu_name", "p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9"], name: "menu_links_menu_parents"
  add_index "menu_links", ["menu_name", "plid", "expanded", "has_children"], name: "menu_links_menu_plid_expand_child"
  add_index "menu_links", ["router_path"], name: "menu_links_router_path"

  create_table "menu_router", primary_key: "path", force: true do |t|
    t.binary  "load_functions",                 null: false
    t.binary  "to_arg_functions",               null: false
    t.string  "access_callback",   default: "", null: false
    t.binary  "access_arguments"
    t.string  "page_callback",     default: "", null: false
    t.binary  "page_arguments"
    t.string  "delivery_callback", default: "", null: false
    t.integer "fit",               default: 0,  null: false
    t.integer "number_parts",      default: 0,  null: false
    t.integer "context",           default: 0,  null: false
    t.string  "tab_parent",        default: "", null: false
    t.string  "tab_root",          default: "", null: false
    t.string  "title",             default: "", null: false
    t.string  "title_callback",    default: "", null: false
    t.string  "title_arguments",   default: "", null: false
    t.string  "theme_callback",    default: "", null: false
    t.string  "theme_arguments",   default: "", null: false
    t.integer "type",              default: 0,  null: false
    t.text    "description",                    null: false
    t.string  "position",          default: "", null: false
    t.integer "weight",            default: 0,  null: false
    t.text    "include_file"
  end

  add_index "menu_router", ["fit"], name: "menu_router_fit"
  add_index "menu_router", ["path"], name: "sqlite_autoindex_menu_router_1", unique: true
  add_index "menu_router", ["tab_parent", "weight", "title"], name: "menu_router_tab_parent"
  add_index "menu_router", ["tab_root", "weight", "title"], name: "menu_router_tab_root_weight_title"

  create_table "node", primary_key: "nid", force: true do |t|
    t.integer "vid"
    t.string  "type",      limit: 32, default: "", null: false
    t.string  "language",  limit: 12, default: "", null: false
    t.string  "title",                default: "", null: false
    t.integer "uid",                  default: 0,  null: false
    t.integer "status",               default: 1,  null: false
    t.integer "created",              default: 0,  null: false
    t.integer "changed",              default: 0,  null: false
    t.integer "comment",              default: 0,  null: false
    t.integer "promote",              default: 0,  null: false
    t.integer "sticky",               default: 0,  null: false
    t.integer "tnid",                 default: 0,  null: false
    t.integer "translate",            default: 0,  null: false
  end

  add_index "node", ["changed"], name: "node_node_changed"
  add_index "node", ["created"], name: "node_node_created"
  add_index "node", ["promote", "status", "sticky", "created"], name: "node_node_frontpage"
  add_index "node", ["status", "type", "nid"], name: "node_node_status_type"
  add_index "node", ["title", "type"], name: "node_node_title_type"
  add_index "node", ["tnid"], name: "node_tnid"
  add_index "node", ["translate"], name: "node_translate"
  add_index "node", ["type"], name: "node_node_type"
  add_index "node", ["uid"], name: "node_uid"
  add_index "node", ["vid"], name: "node_vid", unique: true

  create_table "node_access", primary_key: "nid", force: true do |t|
    t.integer "gid",          default: 0,  null: false
    t.string  "realm",        default: "", null: false
    t.integer "grant_view",   default: 0,  null: false
    t.integer "grant_update", default: 0,  null: false
    t.integer "grant_delete", default: 0,  null: false
  end

  add_index "node_access", ["nid", "gid", "realm"], name: "sqlite_autoindex_node_access_1", unique: true

  create_table "node_comment_statistics", primary_key: "nid", force: true do |t|
    t.integer "cid",                               default: 0, null: false
    t.integer "last_comment_timestamp",            default: 0, null: false
    t.string  "last_comment_name",      limit: 60
    t.integer "last_comment_uid",                  default: 0, null: false
    t.integer "comment_count",                     default: 0, null: false
  end

  add_index "node_comment_statistics", ["comment_count"], name: "node_comment_statistics_comment_count"
  add_index "node_comment_statistics", ["last_comment_timestamp"], name: "node_comment_statistics_node_comment_timestamp"
  add_index "node_comment_statistics", ["last_comment_uid"], name: "node_comment_statistics_last_comment_uid"

  create_table "node_revision", primary_key: "vid", force: true do |t|
    t.integer "nid",       default: 0,  null: false
    t.integer "uid",       default: 0,  null: false
    t.string  "title",     default: "", null: false
    t.text    "log",                    null: false
    t.integer "timestamp", default: 0,  null: false
    t.integer "status",    default: 1,  null: false
    t.integer "comment",   default: 0,  null: false
    t.integer "promote",   default: 0,  null: false
    t.integer "sticky",    default: 0,  null: false
  end

  add_index "node_revision", ["nid"], name: "node_revision_nid"
  add_index "node_revision", ["uid"], name: "node_revision_uid"

  create_table "node_type", primary_key: "type", force: true do |t|
    t.string  "name",        default: "", null: false
    t.string  "base",                     null: false
    t.string  "module",                   null: false
    t.text    "description",              null: false
    t.text    "help",                     null: false
    t.integer "has_title",                null: false
    t.string  "title_label", default: "", null: false
    t.integer "custom",      default: 0,  null: false
    t.integer "modified",    default: 0,  null: false
    t.integer "locked",      default: 0,  null: false
    t.integer "disabled",    default: 0,  null: false
    t.string  "orig_type",   default: "", null: false
  end

  add_index "node_type", ["type"], name: "sqlite_autoindex_node_type_1", unique: true

  create_table "queue", primary_key: "item_id", force: true do |t|
    t.string  "name",    default: "", null: false
    t.binary  "data"
    t.integer "expire",  default: 0,  null: false
    t.integer "created", default: 0,  null: false
  end

  add_index "queue", ["expire"], name: "queue_expire"
  add_index "queue", ["name", "created"], name: "queue_name_created"

  create_table "rdf_mapping", primary_key: "type", force: true do |t|
    t.string "bundle",  limit: 128, null: false
    t.binary "mapping"
  end

  add_index "rdf_mapping", ["type", "bundle"], name: "sqlite_autoindex_rdf_mapping_1", unique: true

  create_table "registry", primary_key: "name", force: true do |t|
    t.string  "type",     limit: 9, default: "", null: false
    t.string  "filename",                        null: false
    t.string  "module",             default: "", null: false
    t.integer "weight",             default: 0,  null: false
  end

  add_index "registry", ["name", "type"], name: "sqlite_autoindex_registry_1", unique: true
  add_index "registry", ["type", "weight", "module"], name: "registry_hook"

  create_table "registry_file", primary_key: "filename", force: true do |t|
    t.string "hash", limit: 64, null: false
  end

  add_index "registry_file", ["filename"], name: "sqlite_autoindex_registry_file_1", unique: true

  create_table "role", primary_key: "rid", force: true do |t|
    t.string  "name",   limit: 64, default: "", null: false
    t.integer "weight",            default: 0,  null: false
  end

  add_index "role", ["name", "weight"], name: "role_name_weight"
  add_index "role", ["name"], name: "role_name", unique: true

  create_table "role_permission", primary_key: "rid", force: true do |t|
    t.string "permission", limit: 128, default: "", null: false
    t.string "module",                 default: "", null: false
  end

  add_index "role_permission", ["permission"], name: "role_permission_permission"
  add_index "role_permission", ["rid", "permission"], name: "sqlite_autoindex_role_permission_1", unique: true

  create_table "search_dataset", primary_key: "sid", force: true do |t|
    t.string  "type",    limit: 16,             null: false
    t.text    "data",                           null: false
    t.integer "reindex",            default: 0, null: false
  end

  add_index "search_dataset", ["sid", "type"], name: "sqlite_autoindex_search_dataset_1", unique: true

  create_table "search_index", primary_key: "word", force: true do |t|
    t.integer "sid",              default: 0, null: false
    t.string  "type",  limit: 16,             null: false
    t.float   "score"
  end

  add_index "search_index", ["sid", "type"], name: "search_index_sid_type"
  add_index "search_index", ["word", "sid", "type"], name: "sqlite_autoindex_search_index_1", unique: true

  create_table "search_node_links", primary_key: "sid", force: true do |t|
    t.string  "type",    limit: 16, default: "", null: false
    t.integer "nid",                default: 0,  null: false
    t.text    "caption"
  end

  add_index "search_node_links", ["nid"], name: "search_node_links_nid"
  add_index "search_node_links", ["sid", "type", "nid"], name: "sqlite_autoindex_search_node_links_1", unique: true

  create_table "search_total", primary_key: "word", force: true do |t|
    t.float "count"
  end

  add_index "search_total", ["word"], name: "sqlite_autoindex_search_total_1", unique: true

  create_table "semaphore", primary_key: "name", force: true do |t|
    t.string "value",  default: "", null: false
    t.float  "expire",              null: false
  end

  add_index "semaphore", ["expire"], name: "semaphore_expire"
  add_index "semaphore", ["name"], name: "sqlite_autoindex_semaphore_1", unique: true
  add_index "semaphore", ["value"], name: "semaphore_value"

  create_table "sequences", primary_key: "value", force: true do |t|
  end

  create_table "sessions", primary_key: "sid", force: true do |t|
    t.integer "uid",                                null: false
    t.string  "ssid",      limit: 128, default: "", null: false
    t.string  "hostname",  limit: 128, default: "", null: false
    t.integer "timestamp",             default: 0,  null: false
    t.integer "cache",                 default: 0,  null: false
    t.binary  "session"
  end

  add_index "sessions", ["sid", "ssid"], name: "sqlite_autoindex_sessions_1", unique: true
  add_index "sessions", ["ssid"], name: "sessions_ssid"
  add_index "sessions", ["timestamp"], name: "sessions_timestamp"
  add_index "sessions", ["uid"], name: "sessions_uid"

  create_table "shortcut_set", primary_key: "set_name", force: true do |t|
    t.string "title", default: "", null: false
  end

  add_index "shortcut_set", ["set_name"], name: "sqlite_autoindex_shortcut_set_1", unique: true

  create_table "shortcut_set_users", primary_key: "uid", force: true do |t|
    t.string "set_name", limit: 32, default: "", null: false
  end

  add_index "shortcut_set_users", ["set_name"], name: "shortcut_set_users_set_name"

  create_table "system", primary_key: "filename", force: true do |t|
    t.string  "name",                      default: "", null: false
    t.string  "type",           limit: 12, default: "", null: false
    t.string  "owner",                     default: "", null: false
    t.integer "status",                    default: 0,  null: false
    t.integer "bootstrap",                 default: 0,  null: false
    t.integer "schema_version",            default: -1, null: false
    t.integer "weight",                    default: 0,  null: false
    t.binary  "info"
  end

  add_index "system", ["filename"], name: "sqlite_autoindex_system_1", unique: true
  add_index "system", ["status", "bootstrap", "type", "weight", "name"], name: "system_system_list"
  add_index "system", ["type", "name"], name: "system_type_name"

  create_table "taxonomy_index", id: false, force: true do |t|
    t.integer "nid",     default: 0, null: false
    t.integer "tid",     default: 0, null: false
    t.integer "sticky",  default: 0
    t.integer "created", default: 0, null: false
  end

  add_index "taxonomy_index", ["nid"], name: "taxonomy_index_nid"
  add_index "taxonomy_index", ["tid", "sticky", "created"], name: "taxonomy_index_term_node"

  create_table "taxonomy_term_data", primary_key: "tid", force: true do |t|
    t.integer "vid",         default: 0,  null: false
    t.string  "name",        default: "", null: false
    t.text    "description"
    t.string  "format"
    t.integer "weight",      default: 0,  null: false
  end

  add_index "taxonomy_term_data", ["name"], name: "taxonomy_term_data_name"
  add_index "taxonomy_term_data", ["vid", "name"], name: "taxonomy_term_data_vid_name"
  add_index "taxonomy_term_data", ["vid", "weight", "name"], name: "taxonomy_term_data_taxonomy_tree"

  create_table "taxonomy_term_hierarchy", primary_key: "tid", force: true do |t|
    t.integer "parent", default: 0, null: false
  end

  add_index "taxonomy_term_hierarchy", ["parent"], name: "taxonomy_term_hierarchy_parent"
  add_index "taxonomy_term_hierarchy", ["tid", "parent"], name: "sqlite_autoindex_taxonomy_term_hierarchy_1", unique: true

  create_table "taxonomy_vocabulary", primary_key: "vid", force: true do |t|
    t.string  "name",         default: "", null: false
    t.string  "machine_name", default: "", null: false
    t.text    "description"
    t.integer "hierarchy",    default: 0,  null: false
    t.string  "module",       default: "", null: false
    t.integer "weight",       default: 0,  null: false
  end

  add_index "taxonomy_vocabulary", ["machine_name"], name: "taxonomy_vocabulary_machine_name", unique: true
  add_index "taxonomy_vocabulary", ["weight", "name"], name: "taxonomy_vocabulary_list"

  create_table "url_alias", primary_key: "pid", force: true do |t|
    t.string "source",              default: "", null: false
    t.string "alias",               default: "", null: false
    t.string "language", limit: 12, default: "", null: false
  end

  add_index "url_alias", ["alias", "language", "pid"], name: "url_alias_alias_language_pid"
  add_index "url_alias", ["source", "language", "pid"], name: "url_alias_source_language_pid"

  create_table "users", primary_key: "uid", force: true do |t|
    t.string  "name",             limit: 60,  default: "", null: false
    t.string  "pass",             limit: 128, default: "", null: false
    t.string  "mail",             limit: 254, default: ""
    t.string  "theme",                        default: "", null: false
    t.string  "signature",                    default: "", null: false
    t.string  "signature_format"
    t.integer "created",                      default: 0,  null: false
    t.integer "access",                       default: 0,  null: false
    t.integer "login",                        default: 0,  null: false
    t.integer "status",                       default: 0,  null: false
    t.string  "timezone",         limit: 32
    t.string  "language",         limit: 12,  default: "", null: false
    t.integer "picture",                      default: 0,  null: false
    t.string  "init",             limit: 254, default: ""
    t.binary  "data"
  end

  add_index "users", ["access"], name: "users_access"
  add_index "users", ["created"], name: "users_created"
  add_index "users", ["mail"], name: "users_mail"
  add_index "users", ["name"], name: "users_name", unique: true
  add_index "users", ["picture"], name: "users_picture"

  create_table "users_roles", primary_key: "uid", force: true do |t|
    t.integer "rid", default: 0, null: false
  end

  add_index "users_roles", ["rid"], name: "users_roles_rid"
  add_index "users_roles", ["uid", "rid"], name: "sqlite_autoindex_users_roles_1", unique: true

  create_table "variable", primary_key: "name", force: true do |t|
    t.binary "value", null: false
  end

  add_index "variable", ["name"], name: "sqlite_autoindex_variable_1", unique: true

  create_table "watchdog", primary_key: "wid", force: true do |t|
    t.integer "uid",                   default: 0,  null: false
    t.string  "type",      limit: 64,  default: "", null: false
    t.text    "message",                            null: false
    t.binary  "variables",                          null: false
    t.integer "severity",              default: 0,  null: false
    t.string  "link",                  default: ""
    t.text    "location",                           null: false
    t.text    "referer"
    t.string  "hostname",  limit: 128, default: "", null: false
    t.integer "timestamp",             default: 0,  null: false
  end

  add_index "watchdog", ["severity"], name: "watchdog_severity"
  add_index "watchdog", ["type"], name: "watchdog_type"
  add_index "watchdog", ["uid"], name: "watchdog_uid"

end
