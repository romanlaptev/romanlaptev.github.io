require 'test_helper'

class BaseHelperTest < ActionView::TestCase
end
