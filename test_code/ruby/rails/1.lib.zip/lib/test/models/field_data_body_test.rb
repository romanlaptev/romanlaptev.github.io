require 'test_helper'

class FieldDataBodyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
