class CreateMenuLinks < ActiveRecord::Migration
  def change
    create_table :menu_links do |t|

      t.timestamps
    end
  end
end
