class FieldDataBody < ActiveRecord::Base
	self.table_name = 'field_data_body'
end
