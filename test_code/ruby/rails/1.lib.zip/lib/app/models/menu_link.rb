class MenuLink < ActiveRecord::Base
end
