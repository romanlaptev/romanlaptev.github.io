class Node < ActiveRecord::Base
	self.table_name = 'node'
	#set_inheritance_column :ruby_type
	self.inheritance_column = nil

=begin
 # getter for the "type" column
 def node_type
  self[:type]
 end

 # setter for the "type" column
 def node_type=(s)
  self[:type] = s
 end
=end

end
