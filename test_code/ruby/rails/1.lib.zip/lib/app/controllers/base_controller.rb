class BaseController < ApplicationController

  def index
	#@all_node = Node.all
	#@all_node = Node.new
	#@all_node.title = "First node"
	#@all_node.save

	#render text:"all_node = " + @all_node.inspect
  end

	def content_book
		#@book = Node.where(type: "book")

		sql = "
SELECT node.nid, node.title FROM node WHERE node.nid IN 
(
	SELECT book.nid FROM book WHERE book.mlid IN 
	(
		SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid IN
			(SELECT menu_links.mlid FROM menu_links WHERE menu_links.link_title='Ruby')
	)
);"
		@content_book = ActiveRecord::Base.connection.execute(sql)	

		sql = "
SELECT field_data_body.body_value FROM field_data_body WHERE field_data_body.entity_id IN 
(SELECT node.nid FROM node WHERE node.title ='Ruby');"
		@content_node = ActiveRecord::Base.connection.execute(sql)	

	end

	def content_book_ar
		root_mlid = MenuLink.where(link_title: "Ruby").select("mlid")

		res1 = MenuLink.where(plid: root_mlid ).select("mlid")
		res2 = Book.where( mlid: res1 ).select("nid")
		res3 = Node.where( nid: res2 ).select("nid, title")

		@content_book = res3

		root_nid = Node.where(title: "Ruby").select("nid")
		@content_node = FieldDataBody.where( entity_id: root_nid ).select("body_value")

	end


end
