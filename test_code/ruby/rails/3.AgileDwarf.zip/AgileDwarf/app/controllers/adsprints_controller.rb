class AdsprintsController < ApplicationController
  unloadable

  before_filter :find_project, :authorize

  def list
    @backlog = SprintsTasks.get_backlog(@project)
	
    @sprints = Sprints.all_sprints(@project)
#=============================================================	
	# получить id связанных спринтов
	@mysql_res = Sprints.get_related_versions_id(@project)
	array_values = []
	@mysql_res.each do |row|
		array_values.push(row[0])
	end
	# получить спринты, связанные с текущим проектом и добавить их к  имеющимся версиям проекта
    @sprints += Sprints.get_related_versions(@project,array_values)

	#@test = "test!"
	#@test = A.new
	#@test = Object.new
	
	#@test = Project.new
	#@test.update_attributes(:id => 8)
	#@test.save	
	
	@test = @project.dup
#=============================================================	
    #@sprints.each{|s| s['tasks'] = SprintsTasks.get_tasks_by_sprint(@project, [s.id])}
    @sprints.each{|s| s['tasks'] = SprintsTasks.get_tasks_by_sprint(@test, [s.id])}
	
    @assignables = {}
    @project.assignable_users.each{|u| @assignables[u.id] = u.firstname + ' ' + u.lastname}
    @project_id = @project.id
    @plugin_path = File.join(Redmine::Utils.relative_url_root, 'plugin_assets', 'AgileDwarf')
    @closed_status = Setting.plugin_AgileDwarf[:stclosed].to_i
  end

  private

  def find_project
    # @project variable must be set before calling the authorize filter
    @project = Project.find(params[:project_id])
  end
  
end

#class A
#    def initialize
#        @id = 3
#    end	
#end
