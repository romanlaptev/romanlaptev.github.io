CREATE DATABASE [BillingSystem]  
GO

CREATE TABLE [Log] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[username] [nvarchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[remote_ip] [nvarchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[path] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[method] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[timestamp] [datetime] NOT NULL ,
	CONSTRAINT [PK_Log] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

CREATE Procedure LogAccess
	@user_name	nvarchar(30),
	@path		nvarchar(255),
	@method		nvarchar(10),
	@remote_ip	nvarchar(15)
As
	INSERT INTO [Log] 
		(username, path, method, remote_ip, timestamp)
	VALUES     
		(@user_name, @path, @method, @remote_ip, GETDATE())
RETURN
