CREATE DATABASE SamsBook
GO
USE SamsBook
GO
CREATE TABLE [Logins] (
	[UserID] [int] IDENTITY (1, 1) NOT NULL ,
 	[EmailAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 	[Password] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 	CONSTRAINT [PK_Logins] PRIMARY KEY  CLUSTERED 
 	(
 		[UserID]
 	)  ON [PRIMARY] 
) ON [PRIMARY]
GO