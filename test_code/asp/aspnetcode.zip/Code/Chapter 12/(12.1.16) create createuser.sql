CREATE PROCEDURE CreateUser
	@Email nvarchar(50),
	@Password nvarchar(50),
	@UserID int = 0 OUTPUT
 AS
	SELECT 
		UserID from Logins
	WHERE 
		EmailAddress = @Email 

	IF @@ROWCOUNT > 0 
		SELECT @UserID = 0
	ELSE
		BEGIN
		INSERT INTO Logins 
			(EmailAddress, Password)
		VALUES
			(@Email, @Password)

		SELECT @UserID = @@IDENTITY
		END
GO
