
CREATE PROCEDURE ValidateUser
	@Email nvarchar(50),
	@Password nvarchar(50),
	@LoginID int = 0 OUTPUT
 AS

	SELECT @LoginID = UserID From Logins
	WHERE EmailAddress = @Email And Password = @Password

If @@RowCount < 1 
	SELECT @LoginID = 0


GO

