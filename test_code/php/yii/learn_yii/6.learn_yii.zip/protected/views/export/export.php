<style>
.ok
{
color:green;
font-size:150%;
}
.error
{
color:red;
font-size:150%;
}
</style>

<h2>Export</h2>
<div>
	<span class='ok'><?php echo $messages;?></span> 
</div>

<div>
	<span class='error'><?php echo $errors; ?></span> 
</div>

