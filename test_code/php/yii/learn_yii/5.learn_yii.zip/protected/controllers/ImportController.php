<?php
class ImportController extends Controller
{
	public function actionIndex()
	{

//echo "<pre>";
//print_r($_REQUEST);
//print_r($_FILES);
//echo "</pre>";
		$data['messages'] = "";
		$data['errors'] = "";

		$model = new Import;

		if ( isset( $_POST['Import'] ) )
		{
			$model->attributes = $_POST['Import'];
			if ( !empty($_FILES['Import']['tmp_name']['upload_file']) )
			{
				if ( $_FILES['Import']['type']['upload_file']  == 'text/xml' )
				{
					$file = CUploadedFile::getInstance( $model, 'upload_file' );

					$upload_filename = $_FILES['Import']['name']['upload_file'];
					$file->saveAs( Yii::getPathofAlias("webroot") ."/upload/".$upload_filename);

					$xml_file = Yii::getPathofAlias("webroot") ."/upload/". $_FILES['Import']['name']['upload_file'];
					$data['messages'] = $xml_file . " was sucсessfuly uploaded ";

					$this->processImport( $xml_file );//strat import
				}
				else
				{
					$data['errors']  = "Wrong filetype, only XML allowed.";
				}
			}
			else
			{
				$data['errors'] = "Error uploaded ".$_FILES['Import']['name']['upload_file'];
			}
		}

		$params=array(
			"model"=>$model,
			'messages'=>$data['messages'],
			'errors'=>$data['errors'],
		);
		$this->render("index", $params );

	}

	private function processImport( $xml_file )
	{
		if (file_exists($xml_file)) 
		{
		    $xml = simplexml_load_file( $xml_file );

		    //transforming the object in xml format
		    //$xmlFormat=$xml->asXML();
//echo "xmlFormat = <pre>";
//print_r ($xmlFormat);
//echo "</pre>";
// echo '<pre>'.htmlentities($xmlFormat, ENT_COMPAT | ENT_HTML401, "ISO-8859-1").'</pre>';
		} 
		else 
		{
		    exit('Failed to open '.$xml_file);
		}
	}

}
?>
