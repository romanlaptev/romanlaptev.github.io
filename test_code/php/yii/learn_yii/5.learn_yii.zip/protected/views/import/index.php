<h1>import</h1>
<?php 
//echo CHtml::form('','post',array('enctype'=>'multipart/form-data'));
//echo CHtml::activeFileField( $model, 'image' );
//echo CHtml::endForm(); 
/*
$form = $this->beginWidget('GxActiveForm', array(
    'id' => 'form-id',
    'enableAjaxValidation' => false,
    'htmlOptions' => array(
        'enctype' => 'multipart/form-data',
    ),
));
echo $form->fileField($model, 'filename', array('size' => 48)); 
*/
?>

<!--
<div class="form">11111
<?php
	$form=$this->beginWidget('CActiveForm');
	//echo $form->errorSummary($model);
?>
	<div class="row">
<?php
	//echo CHtml::activeLabel( $model, 'username' );
	//echo CHtml::activeTextField( $model, 'username' );
?>
	</div>
	<div class="row">
<?php
	//echo CHtml::activeLabel( $model, 'password' );
	//echo CHtml::activePasswordField( $model, 'password' );
?>
	</div>
	<div class="row remember">
<?php
	//echo CHtml::activeCheckBox ( $model, 'rememder' );
	//echo CHtml::activeLabel( $model, 'remember' );
?>
	</div>
	<div class="row submit">
<?php
	echo CHtml::submitButton ( 'Enter' );
?>
	</div>
<?php
	$this->endWidget();
?>
</div>
-->

<?php
       $form=$this->beginWidget('CActiveForm', array(
        'id'=>'upload-form',
         'enableAjaxValidation'=>true,
             'htmlOptions' => array('enctype' => 'multipart/form-data'),
        )); 
?>
	<div>
        <?php echo $form->labelEx($model,'upload_file'); ?>
        <?php echo $form->fileField($model,'upload_file'); ?>
        <?php echo $form->error($model, 'upload_file'); ?>
	</div>
        <hr>
        <?php  echo CHtml::submitButton('Upload XML',array("class"=>"")); ?>
        <?php echo $form->errorSummary($model); ?>
    </div>

<?php
        $this->endWidget();
?>

<style>
.ok
{
color:green;
font-size:150%;
}
.error
{
color:red;
font-size:150%;
}
</style>

<div>
	<span class='ok'><?php echo $messages;?></span> 
</div>

<div>
	<span class='error'><?php echo $errors; ?></span> 
</div>


