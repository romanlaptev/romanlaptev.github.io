<?
//***************************************************************
// Формирование HTML-страницы с ссылками на статьи
// кодировка полученной страницы UTF8
//***************************************************************
function create_html_page($xml, $html_page,$charset, $page_content_start)
{
	global $url1,$url2,$url3,$url4;
	//--------------------------------------------------------------
	// Открыть файл для записи сформированной HTML-страницы
	//--------------------------------------------------------------
	if (!$file_out = fopen($html_page, 'w'))
	  {
	 	print "Cannot open file ($html_page)";
	 	return;
	  }

	fwrite($file_out, $page_content_start);

	fwrite($file_out, "<div>\n");
	for ($n1=0; $n1 < sizeof($xml->articles->article); $n1++)
		{
			//fwrite($file_out, $n1.".");
			//fwrite($file_out, "<a href=\"".$xml->articles->article[$n1]->a['href']."\" target=_blank>");
			//fwrite($file_out, $xml->articles->article[$n1]->a."</a><br/>\n");

			fwrite($file_out,"<div class=\"article\">\n");

				fwrite($file_out, "<div class=\"article_num\">\n");
				fwrite($file_out, ($n1+1).".");
				fwrite($file_out,"</div>\n");

				fwrite($file_out, "<div class=\"article_title\">\n");
				fwrite($file_out, $xml->articles->article[$n1]->section."<br>\n");
				fwrite($file_out, $xml->articles->article[$n1]->journal."<br>\n");
				fwrite($file_out, $xml->articles->article[$n1]->author."<br>\n");
				fwrite($file_out, $xml->articles->article[$n1]->a."\n");
				fwrite($file_out, "</div>\n");

				fwrite($file_out, "<div  class=\"article_links\">\n");
				if (isset($url1))
				  {
					$url11=$url1."/".$xml->articles->article[$n1]->a['href'];
					fwrite($file_out,"<a href=\"".$url11."\" target=_blank> url1 </a>\n");
				  }

				if (isset($url2))
				  {
					$url21=$url2."/".$xml->articles->article[$n1]->a['href'];
					fwrite($file_out,"<a href=\"".$url21."\" target=_blank> url2 </a>\n");
				  }

				if (isset($url3))
				  {
					$url31=$url3."/".$xml->articles->article[$n1]->a['href'];
					fwrite($file_out, "<a href=\"".$url31."\" target=_blank> url3 </a>\n");
				  }

				if (isset($url4))
				  {
					$url41=$url4."/".$xml->articles->article[$n1]->a['href'];
					fwrite($file_out, "<a href=\"".$url41."\" target=_blank> url4 </a>\n");
				  }

				fwrite($file_out, "</div>\n");

			fwrite($file_out,"</div>\n");

		} //--------------------------- end for
	$today = date("H:i:s, d.m.Y");
	fwrite($file_out, "<div class=\"date\">\n");
	fwrite($file_out,"Last modified: <b>" . $today."</b></br>\n");
	fwrite($file_out, "</div>\n");

	fwrite($file_out, "</div>\n");


	$page_content_end = "</body></html>";
	fwrite($file_out, $page_content_end);
   
	print "Success, wrote to file $html_page";
	fclose($file_out);
}//----------------------------------- end func

function view_xml ($xml)
  {
	global $url1,$url2,$url3,$url4;

	echo "<div>\n";
	for ($n1=0; $n1 < sizeof($xml->articles->article); $n1++)
		{
			//echo $n1."<br>\n";
			echo "<div class=\"article\">\n";

				echo "<div class=\"article_num\">\n";
				echo ($n1+1).".";
				echo "</div>\n";

				echo "<div class=\"article_title\">\n";
				echo $xml->articles->article[$n1]->section."<br>\n";
				echo $xml->articles->article[$n1]->journal."<br>\n";
				echo $xml->articles->article[$n1]->author."<br>\n";
				echo $xml->articles->article[$n1]->a."\n";
				echo "</div>\n";

				echo "<div  class=\"article_links\">\n";
				if (isset($url1))
				  {
					$url11=$url1."/".$xml->articles->article[$n1]->a['href'];
					echo "<a href=\"".$url11."\" target=_blank> url1 </a>\n";
				  }

				if (isset($url2))
				  {
					$url21=$url2."/".$xml->articles->article[$n1]->a['href'];
					echo "<a href=\"".$url21."\" target=_blank> url2 </a>\n";
				  }

				if (isset($url3))
				  {
					$url31=$url3."/".$xml->articles->article[$n1]->a['href'];
					echo "<a href=\"".$url31."\" target=_blank> url3 </a>\n";
				  }

				if (isset($url4))
				  {
					$url41=$url4."/".$xml->articles->article[$n1]->a['href'];
					echo "<a href=\"".$url41."\" target=_blank> url4 </a>\n";
				  }
				echo "</div>\n";

			echo "</div>\n";
		} //--------------------------- end for
	echo "</div>\n";
  }
//-----------------------------------------------------end func


//****************************
// MAIN
//****************************
//echo "<pre>";
//print_r ($_REQUEST);
//print_r ($_POST);
//print_r ($_SERVER);
//echo "</pre>";

// Извлекаем параметры из запроса
if (!isset($_REQUEST['action']))
  {
	echo "<font color=red> Need action...... </font>";
	echo "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?action =\"save\" or \"view\"";
	exit();
  }
if (!isset($_REQUEST['charset']))
  {
	echo "<font color=red> Need CHARSET...... </font>";
	echo "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?charset =\"utf-8\" or \"windows-1251\"";
	exit();
  }
$charset = $_REQUEST['charset'];
//$charset = "utf-8";
//$charset = "";

$tpl_p1 = "<html>\n<head>\n<meta http-equiv=Content-Type content=text/html; charset=$charset>\n
<title>Статьи из журналов</title>
<link rel=stylesheet href=\"css/list_articles.css\" type=text/css>
</head>\n<body>\n";

$tpl_p2 = "</body>\n</html>\n";

echo $tpl_p1;

$url1="http://12nov.co.cc/ext/lib/comp/articles";
$url2="http://roman-laptev.ucoz.ru/articles";
//$url3="http://roman-laptev.hut1.ru/lib/articles";
$url4="http://roman-laptev.narod.ru/lib/articles";

//-----------------------------------------------------
// Считать из XML-файла данные 
//-----------------------------------------------------
$xml_file = "http://12nov.co.cc/www/xml/mydb.xml";
$xml = simplexml_load_file($xml_file);
if ($xml == FALSE) 
  {
	exit("Failed to open ".$xml_file);
  }

if (isset($_REQUEST['action']))
  {
	$action=$_REQUEST['action']; 
  }

if  ($action == "view")
  {
	//$result = $xml->xpath('//article'); 
	//$num =  sizeof($result);
	//echo "<pre>";
	//print_r ($result);
	//echo "</pre>";
	view_xml ($xml);
  }

//**********************************************
// Записать результаты запроса в файл
//**********************************************
if  ($action == "save")
   {
	$html_page="../pages/list_articles.html";
	create_html_page($xml, $html_page,$charset,$tpl_p1);

//**********************************************
// перекодировка файла страницы в windows-1251
// и запись потд тем же именем
//**********************************************
	if  ($charset == "windows-1251")
	   {
		if (!$file_utf8 = fopen($html_page, 'r'))
		  {
		 	print "Cannot open file ($html_page) for reading";
		 	exit;
		  }

		$html_page_utf8  = fread ($file_utf8, filesize ($html_page));
		fclose($file_utf8);

		$html_page_win = iconv("UTF-8", "windows-1251",$html_page_utf8);
		//echo $html_page_win;
		echo "<br>";
		echo "convert source page UTF-8 in windows-1251 charset<br>";

		// запись страницы в кодировке windows-1251 в тот же файл
		if (!$file = fopen($html_page, 'w'))
		  {
		 	print "Cannot open file ($html_page) for writing";
		 	exit;
		  }
		fwrite($file, $html_page_win);
		fclose($file);

		echo "Save content in ".$html_page;
	   }// -------------------- end if
	readfile ($html_page);
   }
// -------------------- end action

echo $tpl_p2;

?>

