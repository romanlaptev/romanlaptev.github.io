<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
echo "<pre>";
//print_r($_SERVER['REQUEST_URI']);
print_r($_REQUEST);
echo "</pre>";

class Parser_lib extends CI_Controller {
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index

http://..../codeigniter/index.php/export_db

	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
//echo "class Parser_lib CI_Controller, ./application/controllers/parser_lib.php";
//echo "<br>";
		$data['errors']="";
/*
		//if (!isset($_REQUEST['thumbnail_img']))
		if (empty($_REQUEST['thumbnail_img']))
		{
			$data['errors'] .= "<span class='error'>var thumbnail_img is empty...</span>";
			$data['errors'] .= "<br>";
		}
		if (empty($_REQUEST['small_img']))
		{
			$data['errors'] .= "<span class='error'>var small_img is empty...</span>";
			$data['errors'] .= "<br>";
		}

		$test="medium_img";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		$test="original_img";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
*/
		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}

		$test="url_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$url_path=$_REQUEST['url_path'];
		}

		$test="site";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$site=$_SERVER['SERVER_NAME'];
		}
		else
		{
			$site=$_REQUEST['site'];
		}

		$test="charset";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$charset="utf-8";
		}
		else
		{
			$charset=$_REQUEST['charset'];
		}

		if (!empty($_REQUEST['fs_path']))
		{
			$fs_path = $_REQUEST['fs_path'];
			$url_path = $_REQUEST['url_path'];

			$config['hostname'] = 'localhost';
			$config['username'] = 'root';
			$config['password'] = 'master';
			$config['database'] = 'lib';

			//$config['hostname'] = 'sql306.500mb.net';
			//$config['username'] = 'runet_11119978';
			//$config['password'] = 'w0rdpasss';
			//$config['database'] = 'runet_11119978_gravura';

			$config['dbdriver'] = "mysql";
			$config['dbprefix'] = "";
			$config['pconnect'] = FALSE;
			$config['db_debug'] = TRUE;
			$this->load->model('Parser_lib_model', '', $config);

//------------------------------ получить страницы с изображениями для вложенной книги
			$img_pages = $this->Parser_lib_model->get_list_img_pages();

//---------------------------------- Write pages in HTML files
			$data['messages'] = $this->write_pages($img_pages, 
								$site, 
								$url_path, 
								$charset);
		}//---------------------------------- end if
//echo "data = <pre>";
//print_r($data);
//echo "</pre>";
		$this->load->view('parser_lib',$data);

	}//----------------------------------- end func
	
	public function write_pages($img_pages, 
					$site, 
					$url_path,
					$charset)
	{
/*
    [0] => stdClass Object
        (
            [nid] => 856
            [title] => page_000
            [body_value] => 
            [filename] => cover.jpg
            [filemime] => image/jpeg
            [filesize] => 5040936
            [field_book_img_alt] => иллюстрация к пьесе О. Уайльда «Саломея» и фрагмент иллюстрации к повести Лукиана «Правдивая история»
            [field_book_img_title] => 
            [alias] => cover
            [page_title] => Шедевры графики. Обри Бердслей. иллюстрация к пьесе О. Уайльда «Саломея» и фрагмент иллюстрации к повести Лукиана «Правдивая история»
        )
*/

//$string = 'cup';
//$name = 'coffee';
//$str = 'This is a $string with my $name in it.<br>';
//echo $str;
//eval ("\$str = \"$str\";");
//echo $str;
//include ('./tpl/page.tpl.php');
		$message="";

		$page_tpl = file_get_contents('./tpl/page.tpl.php'); // Считать в переменную шаблон страницы

		$n1=0;
		//while ($n1<44)
		while ($n1<count($img_pages))
		{
			$page = $page_tpl;

			$page = str_replace ('{CHARSET}', $charset, $page); // Заменить теги шаблона, данными
//$page = str_replace ('{TITLE}', $title, $page);
//$page = str_replace ('{KEYWORDS}', $meta_keywords, $page);
//$page = str_replace ('{DESCRIPTION}', $meta_description, $page);

			$page = str_replace ('{SITE}', "http://".$site, $page);
			$page = str_replace ('{URL_PATH}', $url_path, $page);

			//вставка первой страницы разворота
			$page = str_replace ('{TITLE1}', $img_pages[$n1]->title, $page);
			$page = str_replace ('{ALT1}', $img_pages[$n1]->field_book_img_alt, $page);
			$page = str_replace ('{FILENAME1}', $img_pages[$n1]->filename, $page);
			$n1++;
		
			//вставка второй страницы разворота
			$page = str_replace ('{TITLE2}', $img_pages[$n1]->title, $page);
			$page = str_replace ('{ALT2}', $img_pages[$n1]->field_book_img_alt, $page);
			$page = str_replace ('{FILENAME2}', $img_pages[$n1]->filename, $page);
			$n1++;

			//-------------- форм. пейджера для страницы
			$pager = "
<form method='post' name='form_pager' action=''>перейти к странице:
	<select name='page' onChange='load_page();'>
		<option value='' selected='selected'></option>";
//echo "count(img_pages) = ".count($img_pages);
//echo "<br>";
			$n2=0;
			//while ($n2<44)
			while ($n2<count($img_pages))
			{
				$pager .= "<option value='Aubrey_Beardsley_".$img_pages[$n2]->title.".html'>"
.$img_pages[$n2]->title." - ".$img_pages[$n2+1]->title."</option>\n";
				$n2=$n2+2;
			}
		$pager .= "
	</select>
</form>";
			$page = str_replace ('{PAGER}', $pager, $page);
			//------------------------------------------
			if ($charset == "windows-1251")
			  {
				$page = iconv("UTF-8", "windows-1251",$page);
			  }

			//-------------------------------------- write HTML
			if (!empty($page))
			{
//echo $page;
				if (isset($_REQUEST['save']))
				{
					if ($_REQUEST['save'] == 'on')
					{
						//директория с файлами страниц
						if (!empty($_REQUEST['fs_path']))
						{
							$fs_path = $_REQUEST['fs_path'];
							$url_path = $_REQUEST['url_path'];
						}
						else
						{
							$fs_path = getcwd();
							$url_path = '';
						}

						$filename = "Aubrey_Beardsley_".$img_pages[$n1-2]->title.".html";
						$num_bytes = file_put_contents ($fs_path."/".$filename, $page);
						if ($num_bytes > 0)
						{
$message .= "<span class='ok'>Write </span>".$num_bytes." bytes  in ";
$message .= "<a href='".$url_path."/".$filename."'>".$filename."</a>";
$message .= "<br>";
						}
						else
						{
$message .= getcwd();
$message .= "<br>";
$message .= "<span class='error'>Write error in </span>".$filename;
$message .= "<br>";
						}
					}//------------------------ end if save on
				}//------------------------ end if save
			}//------------------------ end if empty page
//$message .= "<br>";
		}//------------------------ end while

		return $message;
	}//---------------------- end func

}//--------------- end class
