<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//echo "<pre>";
//print_r($_SERVER['REQUEST_URI']);
//print_r($_REQUEST);
//echo "</pre>";

class Export_mydb extends CI_Controller {

	public function index()
	{
		$data['errors']="";
		$data['messages']="";
$data['messages'] .= "<span class='ok'>Test...</span>";
$data['messages'] .= "<br>";
		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}

		if (!empty($_REQUEST['fs_path']))
		{
			$fs_path = $_REQUEST['fs_path'];
			$url_path = $_REQUEST['url_path'];

			$config['hostname'] = 'localhost';
			$config['username'] = 'root';
			$config['password'] = 'master';
			$config['database'] = 'mydb';

			$config['dbdriver'] = "mysql";
			$config['dbprefix'] = "";
			$config['pconnect'] = FALSE;
			$config['db_debug'] = TRUE;

/*
			$config['hostname'] = '';
			$config['username'] = '';
			$config['password'] = '';
			$config['database'] = 'sqlite:/mnt/disk2/documents/0_sites/0_db/sqlite/mydb.sqlite';
			$config['dbdriver'] = "pdo";
			$config['dbprefix'] = "";
			$config['pconnect'] = FALSE;
			$config['db_debug'] = TRUE;
*/

			$this->load->model('Export_mydb_model', '', $config);

			$book=array();
			//$content=array();
			//$chapters=array();
			//$pages=array();
			
//------------------------ получить главную страницу (0) книги
			$main_page = $this->Export_mydb_model->get_main_page();
//echo "main_page = <pre>";
//print_r($main_page);
//echo "</pre>";
//------------------------ получить menu_links.mlid страниц книги 1-го уровня (список глав)
			$book = $this->Export_mydb_model->get_content();
/*
    [0] => stdClass Object
        (
            [mlid] => 1587
            [nid] => 672
            [plid] => 1585
            [weight] => -15
            [title] => про сайт
        )

*/

//------------------------------ 
			for ($n1=0; $n1 < count($book); $n1++)
			{
//echo "n1 = ".$n1;
//echo ", ".$book[$n1]->mlid;
//echo "<br>";
//$book[$n1]->сhild_pages = 'сhild_pages';
				// получить все страницы (2) глав (1)
				$book[$n1]->сhild_pages = $this->Export_mydb_model->get_child_pages_2($book[$n1]->mlid);
				// получить все дочернии страницы (3)
				for ($n2=0; $n2 < count($book[$n1]->сhild_pages); $n2++)
				{
//$book[$n1]->сhild_pages[$n2]->сhild_pages = 'сhild_pages_3';
	$page = $this->Export_mydb_model->get_child_pages_3($book[$n1]->сhild_pages[$n2]->mlid);
					$book[$n1]->сhild_pages[$n2]->сhild_pages = $page;
				}
			}
//echo "book = <pre>";
//print_r($book);
//echo "</pre>";
			if (count($book)>0)
			{
				$data=$this->write_xml($main_page,$book);
			}

/*
echo "book[0] = <pre>";
print_r($book[0]);
echo "</pre>";


echo "title:".$book[0]->title;
echo "<br>";

echo "title2:".$book[0]->сhild_pages[0]->title;
echo "<br>";

echo "count:".count($book[0]->сhild_pages;
echo "<br>";


foreach ($book[0] as $key=>$item)
{
echo $key;
echo "<br>";
	if ($key == 'сhild_pages')
	{
echo "item = <pre>";
print_r($item);
echo "</pre>";

	}
}
*/

		}//---------------------------------- end if
		$this->load->view('export_mydb_view',$data);

	}//----------------------------------- end func
	

	public function write_xml($main_page,$book)
	{
//echo "public function write_xml(book)";
//echo "<br>";
//echo "book = <pre>";
//print_r($book);
//echo "</pre>";
//echo "this = <pre>";
//print_r($this);
//echo "</pre>";
		$data['errors']="";
		$data['messages']="";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";
		
		$xml = "";
		$xml .= "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		$xml .=  "<book title=\"".htmlspecialchars($main_page[0]->title)."\" ";
		$xml .=  "nid=\"".$main_page[0]->nid."\" ";
		$xml .=  "mlid=\"".$main_page[0]->mlid."\" ";
		$xml .=  "plid=\"".$main_page[0]->plid."\">\n";
		if (!empty($main_page[0]->body))
		{
			$body = htmlspecialchars ($main_page[0]->body);
			$xml .=  "<body>\n";
			$xml .=  $body."\n";
			$xml .=  "</body>\n";
		}

//echo "book[0] = <pre>";
//print_r($book[0]);
//echo "</pre>";

//echo "title:".$book[0]->title;
//echo "<br>";

//echo "title2:".$book[0]->сhild_pages[0]->title;
//echo "<br>";
//echo "count:".count($book[3]->сhild_pages);
//echo "<br>";
		for ($n1 = 0; $n1 < count($book); $n1++)
		{
//echo $n1.", ".$book[$n1]->title;
//echo "<br>";
			$xml .=  "<page title=\"".htmlspecialchars($book[$n1]->title)."\" ";
			$xml .=  "nid=\"".$book[$n1]->nid."\" ";
			$xml .=  "mlid=\"".$book[$n1]->mlid."\" ";
			$xml .=  "plid=\"".$book[$n1]->plid."\">\n";
			if (!empty($book[$n1]->body))
			{
				$body = htmlspecialchars ($book[$n1]->body);
				$xml .=  "<body>\n";
				$xml .=  $body."\n";
				$xml .=  "</body>\n";
			}

			if (count($book[$n1]->сhild_pages)>0)
			{
//echo "<ul>";
//echo "count:".count($book[$n1]->сhild_pages);
//echo "<br>";
				for ($n2=0; $n2 < count($book[$n1]->сhild_pages); $n2++)
				{
//echo $n2.", ".$book[$n1]->сhild_pages[$n2]->title;
//echo "<br>";
			$xml .=  "\t<page title=\"".htmlspecialchars($book[$n1]->сhild_pages[$n2]->title)."\" ";
			$xml .=  "nid=\"".$book[$n1]->сhild_pages[$n2]->nid."\" ";
			$xml .=  "mlid=\"".$book[$n1]->сhild_pages[$n2]->mlid."\" ";
			$xml .=  "plid=\"".$book[$n1]->сhild_pages[$n2]->plid."\">\n";
					if (!empty($book[$n1]->сhild_pages[$n2]->body))
					{
			$body = htmlspecialchars ($book[$n1]->сhild_pages[$n2]->body);
			$xml .=  "<body>\n";
			$xml .=  $body."\n";
			$xml .=  "</body>\n";
					}

					if (count($book[$n1]->сhild_pages[$n2]->сhild_pages)>0)
					{
//echo "	<ul>";
//echo "count:".count($book[$n1]->сhild_pages[$n2]->сhild_pages);
//echo "<br>";
						for ($n3=0; $n3 < count($book[$n1]->сhild_pages[$n2]->сhild_pages); $n3++)
						{
//echo $n3.", ".$book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->title;
//echo "<br>";
	$xml .=  "\t\t<page title=\"".htmlspecialchars($book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->title)."\" ";
	$xml .=  "nid=\"".$book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->nid."\" ";
	$xml .=  "mlid=\"".$book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->mlid."\" ";
	$xml .=  "plid=\"".$book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->plid."\">\n";
							if (!empty($book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->body))
							{
	$body = htmlspecialchars ($book[$n1]->сhild_pages[$n2]->сhild_pages[$n3]->body);
	$xml .=  "<body>\n";
	$xml .=  $body."\n";
	$xml .=  "</body>\n";
							}
	$xml .=  "\t\t</page>\n";
						}//------------------------- end for
//echo "	</ul>";
					}//------------------------- end if

/*
				if ($num==0)
				{
					$xml .=  "<page chapter_title=\"".htmlspecialchars($page->title)."\" ";
					$xml .=  "nid=\"".$page->nid."\" ";
					$xml .=  "mlid=\"".$page->mlid."\" ";
					$xml .=  "plid=\"".$page->plid."\">\n";
//echo $page->title;
//echo "<br>";
				}
				else
				{
					$xml .=  "<page title=\"".htmlspecialchars($page->title)."\" ";
					$xml .=  "nid=\"".$page->nid."\" ";
					$xml .=  "mlid=\"".$page->mlid."\" ";
					$xml .=  "plid=\"".$page->plid."\">\n";
				}

				if (!empty($page->body_value))
				{
					$body = htmlspecialchars ($page->body_value);
					$xml .=  "<body_value>\n";
					$xml .=  $body."\n";
					$xml .=  "</body_value>\n";
				}
				if (!empty($page->filename))
				{
					$xml .=  "<filename>\n";
					$xml .=  $page->filename."\n";
					$xml .=  "</filename>\n";
				}

				if (!empty($page->field_content_files_value))
				{
					$xml .=  "<filename>\n";
					$xml .=  $page->field_content_files_value."\n";
					$xml .=  "</filename>\n";
				}

				if ($num>0)
				{
					if ($num<(count($chapter)))
					{
						$xml .=  "</page>\n";
					}
				}

				if ($num==(count($chapter)-1))
				{
					//$xml .=  "</chapter>\n";
					$xml .=  "</page>\n";
				}
*/
				//$num2++;
					$xml .=  "\t</page>\n";
				}//--------------------------- end for
//echo "</ul>";
			}//------------------------- end if
			$xml .=  "</page>\n";
		}//--------------------------- end for


		$xml .= "</book>\n";
//echo "<pre>";
//echo htmlspecialchars($xml);
//echo "</pre>";

//-------------------------------------- write XML
		$test="url_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$url_path=$_REQUEST[$test];
		}

		$test="filename";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$filename=$_REQUEST[$test];
		}

		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$fs_path=$_REQUEST[$test];
		}

		if (isset($_REQUEST['save']))
		{
			if ($_REQUEST['save']=='on')
			{
//echo "on!";
//echo "<br>";
				$num_bytes = file_put_contents ($fs_path."/".$filename, $xml);
				if ($num_bytes > 0)
				{
$data['messages'] .= "<span class='ok'>Write </span>".$num_bytes." bytes  in ".$filename;
$data['messages'] .= "<br>";
$data['messages'] .= "<a href='".$url_path."/".$filename."'>".$filename."</a>";
//echo "<pre>";
//readfile ($output_filename);
//echo "</pre>";
				}
				else
				{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Write error in </span>".$filename;
$data['errors'] .= "<br>";
				}
			}
		}
//--------------------------------------
		return $data;
	}//---------------------- end func

}//--------------- end class
