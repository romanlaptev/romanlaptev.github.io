<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
echo "<pre>";
//print_r($_SERVER['REQUEST_URI']);
print_r($_REQUEST);
echo "</pre>";

class Export_rods extends CI_Controller {

	public function index()
	{
		$data['errors']="";
		$data['messages']="";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";

		$test="action";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$action="";
		}
		else
			$action=$_REQUEST[$test];

//echo "action = ".$action;
//echo "<br>";
if ($action=='xml_export')
{
		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}

		if (!empty($_REQUEST['fs_path']))
		{
			$fs_path = $_REQUEST['fs_path'];
			$url_path = $_REQUEST['url_path'];

			$config['hostname'] = 'localhost';
			$config['username'] = 'root';
			$config['password'] = 'master';
			$config['database'] = 'lib';

			//$config['hostname'] = 'sql306.500mb.net';
			//$config['username'] = 'runet_11119978';
			//$config['password'] = 'w0rdpasss';
			//$config['database'] = 'runet_11119978_gravura';

			$config['dbdriver'] = "mysql";
			$config['dbprefix'] = "";
			$config['pconnect'] = FALSE;
			$config['db_debug'] = TRUE;
			$this->load->model('Export_rods_model', '', $config);

			$book=array();
			$content=array();
			$chapters=array();
			$pages=array();
			
//------------------------ получить menu_links.mlid страниц книги 1-го уровня (список глав)
			$content = $this->Export_rods_model->get_content();

//------------------------------ получить страницы глав
			for ($n1=0; $n1 < count($content); $n1++)
			{
				$book['chapters'][] = $this->Export_rods_model->get_chapter($content[$n1]->mlid);
			}
//echo "chapters = <pre>";
//print_r($chapters);
//echo "</pre>";
			$book['title']="Родс Э. Пропаганда. Плакаты, карикатуры и кинофильмы Второй Мировой Войны 1939-1945";
			if (count($book['chapters'])>0)
			{
				$data=$this->write_xml($book);
			}

		}//---------------------------------- end if
}//-------------------------- end if

if ($action=='html_export')
{
		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$fs_path = $_REQUEST['fs_path'];
		}

		$test="url_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$url_path=$_REQUEST['url_path'];
		}

		$test="xml_file";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$xml_file=$_REQUEST['xml_file'];
		}

		$test="site";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$site=$_SERVER['SERVER_NAME'];
		}
		else
		{
			$site=$_REQUEST['site'];
		}

		$test="content_location";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$site=$_SERVER['SERVER_NAME'];
		}
		else
		{
			$content_location=$_REQUEST['content_location'];
		}

		$test="charset";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$charset="utf-8";
		}
		else
		{
			$charset=$_REQUEST['charset'];
		}


		$save=0;
		if (isset($_REQUEST['save']))
		{
			if ($_REQUEST['save'] == 'on')
			{
				$save=1;
			}
		}

		$test="file_content_tpl";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$charset="utf-8";
		}
		else
		{
			$file_content_tpl=$_REQUEST['file_content_tpl'];
		}

		$test="file_page_tpl";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
			$charset="utf-8";
		}
		else
		{
			$file_page_tpl=$_REQUEST['file_page_tpl'];
		}


		//if (!empty($fs_path))
		if (empty($data['errors']))
		{

			//---------------------------------- получить страницы книги
			$xml = simplexml_load_file($xml_file);
			if ($xml == FALSE) 
			  {
				exit("Failed to open ".$xml_file);
			  }
//echo "<pre>";
//print_r ($xml);
//echo "</pre>";

			//---------------------------------- Write pages in HTML files
			$data = $this->write_html_pages($xml, 
						$fs_path, 
						$url_path, 
						$site, 
						$content_location,
						$save,
						$charset,
						$file_content_tpl,$file_page_tpl);

		}//-------------------------- end if

}//-------------------------- end if

		$this->load->view('export_rods_view',$data);

	}//----------------------------------- end func
	

	public function write_xml($book)
	{
//echo "public function write_xml(book)";
//echo "<br>";
//echo "book = <pre>";
//print_r($book);
//print_r($book['chapters'][1][0]->title);
//echo "</pre>";
/*
[1] => Array
                (
                    [0] => stdClass Object
                        (
                            [nid] => 1097
                            [title] => ГЛАВА I.Разрастание рейха 1933-1945
                            [body_value] => ГЛАВА I.Разрастание рейха 1933-1945
9
                            [filename] => rods_p0007.jpg
                        )

                    [1] => stdClass Object
                        (
                            [nid] => 1108
                            [title] => p11
                            [body_value] => 
                            [filename] => rods_p0008.jpg
                        )
*/
//echo "this = <pre>";
//print_r($this);
//echo "</pre>";
		$data['errors']="";
		$data['messages']="";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";
		
		$xml = "";
		$xml .= "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		$xml .= "<book>\n";
		$xml .= "<title>".$book['title']."</title>\n";
		foreach ($book['chapters'] as $key => $chapter)
		{
			$num=0;
			foreach ($chapter as $key => $page)
			{
				if ($num==0)
				{
					$xml .=  "<page chapter_title=\"".htmlspecialchars($page->title)."\" ";
					$xml .=  "nid=\"".$page->nid."\" ";
					$xml .=  "mlid=\"".$page->mlid."\" ";
					$xml .=  "plid=\"".$page->plid."\">\n";
//echo $page->title;
//echo "<br>";
				}
				else
				{
					$xml .=  "<page title=\"".htmlspecialchars($page->title)."\" ";
					$xml .=  "nid=\"".$page->nid."\" ";
					$xml .=  "mlid=\"".$page->mlid."\" ";
					$xml .=  "plid=\"".$page->plid."\">\n";
				}

				if (!empty($page->body_value))
				{
					//$body = htmlspecialchars ($page->body_value);
					$body = $page->body_value;
//-------------------------------
	$body = str_replace('[notes]', '<span class="notes">', $body);
	$body = str_replace('[/notes]', '</span>', $body);

	$body = str_replace('[picture_text]', '<span class="picture_text">', $body);
	$body = str_replace('[/picture_text]', '</span>', $body);

	$body = str_replace('[name]', '<span class="name">', $body);
	$body = str_replace('[/name]', '</span>', $body);

	$body = str_replace('[term]', '<span class="termin">', $body);
	$body = str_replace('[/term]', '</span>', $body);
//-------------------------------
					$body = htmlspecialchars ($body);
//echo $body;
//echo "<br>";

					$xml .=  "<body_value>\n";
					$xml .=  $body."\n";
					$xml .=  "</body_value>\n";
				}
				if (!empty($page->filename))
				{
					$xml .=  "<filename>\n";
					$xml .=  $page->filename."\n";
					$xml .=  "</filename>\n";
				}

				if (!empty($page->field_content_files_value))
				{
					$xml .=  "<filename>\n";
					$xml .=  $page->field_content_files_value."\n";
					$xml .=  "</filename>\n";
				}

				if ($num>0)
				{
					if ($num<(count($chapter)))
					{
						$xml .=  "</page>\n";
					}
				}

				if ($num==(count($chapter)-1))
				{
					//$xml .=  "</chapter>\n";
					$xml .=  "</page>\n";
				}

				$num++;
			}//--------------------------- end foreach
		}//--------------------------- end foreach


		$xml .= "</book>\n";
//echo "<pre>";
//echo htmlspecialchars($xml);
//echo "</pre>";

//-------------------------------------- write XML
		$test="url_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$url_path=$_REQUEST[$test];
		}

		$test="filename";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$filename=$_REQUEST[$test];
		}

		$test="fs_path";
		if (empty($_REQUEST[$test]))
		{
			$data['errors'] .= "<span class='error'>var $test is empty...</span>";
			$data['errors'] .= "<br>";
		}
		else
		{
			$fs_path=$_REQUEST[$test];
		}

		if (isset($_REQUEST['save']))
		{
			if ($_REQUEST['save']=='on')
			{
//echo "on!";
//echo "<br>";
				$num_bytes = file_put_contents ($fs_path."/".$filename, $xml);
				if ($num_bytes > 0)
				{
$data['messages'] .= "<span class='ok'>Write </span>".$num_bytes." bytes  in ".$filename;
$data['messages'] .= "<br>";
$data['messages'] .= "<a href='".$url_path."/".$filename."'>".$filename."</a>";
//echo "<pre>";
//readfile ($output_filename);
//echo "</pre>";
				}
				else
				{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Write error in </span>".$filename;
$data['errors'] .= "<br>";
				}
			}
		}
//--------------------------------------
		return $data;
	}//---------------------- end func

//####################################################################################################

	//-------------------------------------- Write pages in HTML files
	public function write_html_pages($xml, 
					$fs_path, 
					$url_path, 
					$site, 
					$content_location,
					$save,
					$charset,
					$file_content_tpl,$file_page_tpl)
	{
//echo "public function write_html_pages()";
//echo "<br>";
		$data['errors']="";
		$data['messages']="";
//$data['errors'] .= "<span class='error'>Test...</span>";
//$data['errors'] .= "<br>";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";
//echo "<pre>";
//print_r ($xml);
//echo "</pre>";
//echo $xml->title;
//echo "<br>";
//echo count($xml->page);
//echo "<br>";

		// Считать в переменную шаблон страницы
		//$content_tpl = file_get_contents('./tpl/content_book_Rods.tpl.php'); 
		//$content_tpl = file_get_contents($file_content_tpl); 
		$file = fopen($file_content_tpl,"r");
		if ($file)
		{
			$content_tpl = fread($file, filesize($file_content_tpl));
			$num_bytes = strlen($content_tpl);
			if ($num_bytes > 0)
			{
$data['messages'] .= "<span class='ok'>Read </span>".$num_bytes." bytes from ".$file_content_tpl;
$data['messages'] .= "<br>";
			}
			else
			{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Read error in </span>".$file_content_tpl;
$data['errors'] .= "<br>";
			}
		}
		fclose ($file); 

		// Заменить теги шаблона, данными
		$content_tpl = str_replace ('{CHARSET}', $charset, $content_tpl); 
		$content_tpl = str_replace ('{TITLE}', $xml->title, $content_tpl); 
//$page = str_replace ('{KEYWORDS}', $meta_keywords, $page);
//$page = str_replace ('{DESCRIPTION}', $meta_description, $page);
		$content_tpl = str_replace ('{SITE}', $site, $content_tpl); 
		$content_tpl = str_replace ('{URL}', $url_path, $content_tpl); 
		$content_tpl = str_replace ('{CONTENT_LOCATION}', $content_location, $content_tpl); 

//========================================= создание индексной html-страницы
		$content="";
		$num_all_pages=0;
		//$num_first_page_chapter=1;
		for ($n1=0; $n1<count($xml->page); $n1++)
		{
//echo $n1.". ".$xml->page[$n1]['chapter_title'];
//echo $n1.". ".$xml->page[$n1]->filename;
//echo "<br>";
			//$content .= $n1.". ";
			$num_all_pages++;

			$content .= "<li>";
			$content .= "<a href='".$xml->page[$n1]['nid'].".html'>";
			$content .= $xml->page[$n1]['chapter_title'];
			$content .= "</a>";
			$content .= " c.".$num_all_pages;
			$content .= "</li>";

			if (count($xml->page[$n1]->page)>0)
			{
				$num_all_pages=$num_all_pages+count($xml->page[$n1]->page);
			}
			//$num_first_page_chapter=$num_all_pages;

		}//------------------------ end for
//echo "num_all_pages = ".$num_all_pages;
//echo "<br>";
		$content_page = str_replace ('{CONTENT}', $content, $content_tpl); 
		$content_page = str_replace ('{NUM_PAGES}',$num_all_pages, $content_page); 
		$content_page = str_replace ('{PAGE_IMG}',$xml->page[0]->filename, $content_page); 

		//------------------------------------------
		if ($charset == "windows-1251")
		  {
			$content_page = iconv("UTF-8", "windows-1251",$content_page);
		  }
		//------------------------------------------

//-------------------------------------- write HTML
		if (!empty($content_page))
		{
			if (isset($_REQUEST['save']))
			{
				if ($_REQUEST['save'] == 'on')
				{
					//$filename = "content.html";
					$filename = "index.html";
	$file = fopen ($fs_path."/".$filename,"w");
	if ( $file )
	  {
		$num_bytes = fwrite ($file, $content_page);
					//$num_bytes = file_put_contents ($fs_path."/".$filename, $content_page);
					if ($num_bytes > 0)
					{
$data['messages'] .= "<span class='ok'>Write </span>".$num_bytes." bytes  in ";
$data['messages'] .= "<a href='".$url_path."/".$filename."'>".$filename."</a>";
$data['messages'] .= "<br>";
					}
					else
					{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Write error in </span>".$filename;
$data['errors'] .= "<br>";
	  }
	fclose ($file); 
					}
				}//------------------------ end if save on
			}//------------------------ end if save
		}//------------------------ end if empty page
//-------------------------------------- end write HTML
//==========================================================================

//================================================================================== создание html-страниц книги
		// Считать в переменную шаблон страницы
		//$page_tpl = file_get_contents('./tpl/page_book_Rods.tpl.php'); 
		//$page_tpl = file_get_contents($file_page_tpl); 
		$file = fopen ($file_page_tpl,"r");
		if ( $file )
		{
			$page_tpl = fread($file, filesize($file_page_tpl));
			$num_bytes = strlen($page_tpl);
			if ($num_bytes > 0)
			{
$data['messages'] .= "<span class='ok'>Read </span>".$num_bytes." bytes from ".$file_page_tpl;
$data['messages'] .= "<br>";
			}
			else
			{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Read error in </span>".$file_page_tpl;
$data['errors'] .= "<br>";
			}
		}
		fclose ($file); 

		// Заменить теги шаблона, данными
		$page_tpl = str_replace ('{CHARSET}', $charset, $page_tpl); 

		$page_tpl = str_replace ('{TITLE}', $xml->title, $page_tpl); 
//$page = str_replace ('{KEYWORDS}', $meta_keywords, $page);
//$page = str_replace ('{DESCRIPTION}', $meta_description, $page);
		$page_tpl = str_replace ('{SITE}', $site, $page_tpl); 
		$page_tpl = str_replace ('{URL}', $url_path, $page_tpl); 
		$page_tpl = str_replace ('{CONTENT_LOCATION}', $content_location, $page_tpl); 

		//global $total_num_pages;
		//$num_all_pages=0;
		//$total_num_pages=0;
		
		$num_pages=count($xml->page);
		//$num_pages=3;
		//$page_tpl = str_replace ('{NUM_PAGES}', $num_pages, $page_tpl); 
		//$page_tpl = str_replace ('{NUM_PAGES}', $num_all_pages, $page_tpl); 

		for ($n1=0; $n1<$num_pages; $n1++)
		{
			$page = $page_tpl;
//echo "<pre>";
//echo htmlspecialchars($page);
//echo "</pre>";
//echo "<hr>";
			//$num_all_pages++;
//echo $n1.". num_all_pages = ".$num_all_pages;
//echo "<br>";
//---------------------------------------- PAGER
			//$total_num_pages++;
//echo $n1.". total_num_pages = ".$total_num_pages;
//echo "<br>";
			$current_page=$n1+1;
			//$current_page=$num_all_pages;
			//$current_page=$total_num_pages;
			
			$prev_page=$current_page-1;
			if ($prev_page>0)
			{
				if (!empty($xml->page[$prev_page-1]['title']))
				{
		$prev_page_link = "<a href='".$xml->page[$prev_page-1]['title'].".html'><|| previous page</a>";
				}
				else
				{
		$prev_page_link = "<a href='".$xml->page[$prev_page-1]['nid'].".html'><|| previous page</a>";
				}

			}
			else
				$prev_page_link = "";
			
			$next_page=$current_page+1;
			if ($next_page<=$num_pages)
			{
				if (!empty($xml->page[$next_page-1]['title']))
				{
		$next_page_link = "<a href='".$xml->page[$next_page-1]['title'].".html'>next page ||></a>";
				}
				else
				{
		$next_page_link = "<a href='".$xml->page[$next_page-1]['nid'].".html'>next page ||></a>";
				}
			}
			else
				$next_page_link = "";
				
			if (count($xml->page[$n1]->page)>0)//следующая страница - дочерняя
			{
				if (!empty($xml->page[$n1]->page[0]['title']))
				{
		$next_page_link = "<a href='".$xml->page[$n1]->page[0]['title'].".html'>next page ||></a>";
				}
				else
				{
		$next_page_link = "<a href='".$xml->page[$n1]->page[0]['nid'].".html'>next page ||></a>";
				}
				$return_prev_page_link = "<a href='".$xml->page[$n1]['nid'].".html'><|| previous page</a>";
				$return_next_page_link = "<a href='".$xml->page[$next_page-1]['nid'].".html'>next page ||></a>";
			}
//-----------------------------------------------
			$data2 = $this->create_page($xml,
						$fs_path, 
						$url_path, 
						$n1,
						$num_pages,
						//$num_all_pages,
						$page,
						$save,
						$charset,
						$current_page,$prev_page_link,$next_page_link);
						
//echo "data2 =<pre>";
//print_r($data2);
//echo "</pre>";
			if (!empty($data2['errors']))
			{
				$data['errors'] .= $data2['errors'];
				$data['errors'] .= "<br>";
			}

			if (!empty($data2['messages']))
			{
				$data['messages'] .= $data2['messages'];
				$data['messages'] .= "<br>";
			}
//----------------------------------------------------------------------------------
//echo $n1.". child_pages = ".count($xml->page[$n1]->page);
//echo "<br>";
			if (count($xml->page[$n1]->page)>0)//следующая страница - дочерняя
			{
				//$num_all_pages=$num_all_pages+count($xml->page[$n1]->page);
				$data2 = $this->create_child_pages($xml->page[$n1],
						$fs_path, 
						$url_path, 
						$site, 
						$content_location,
						$save,
						$charset,
						$page_tpl,
						$return_prev_page_link,
						$return_next_page_link);
//echo "data2 =<pre>";
//print_r($data2);
//echo "</pre>";
				if (!empty($data2['errors']))
				{
					$data['errors'] .= $data2['errors'];
					$data['errors'] .= "<br>";
				}

				if (!empty($data2['messages']))
				{
					$data['messages'] .= $data2['messages'];
					$data['messages'] .= "<br>";
				}

			}

		}//------------------------ end for
//================================================================================
		return $data;
	}//---------------------- end func

	public function create_page($xml,
			$fs_path, 
			$url_path, 
			$num_page,
			$num_pages,
			$page,
			$save,
			$charset,
$current_page,
$prev_page_link,
$next_page_link)
	{
//echo "public create_page()";
//echo "<br>";

		$data['errors']="";
		$data['messages']="";
//$data['errors'] .= "<span class='error'>Test...</span>";
//$data['errors'] .= "<br>";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";
			$page = str_replace ('{NUM_PAGES}', $num_pages, $page); 
			$page = str_replace ('{CURRENT_PAGE}',$current_page, $page); 
			$page = str_replace ('{PREV_PAGE}',$prev_page_link, $page); 
			$page = str_replace ('{NEXT_PAGE}',$next_page_link, $page); 

			if (!empty($xml->page[$num_page]['chapter_title']))
			{
				$page = str_replace ('{PAGE_TITLE}',$xml->page[$num_page]['chapter_title'], $page); 
			}
			if (!empty($xml->page[$num_page]['title']))
			{
				$page = str_replace ('{PAGE_TITLE}',$xml->page[$num_page]['title'], $page); 
			}
			
			$page = str_replace ('{BODY}',$xml->page[$num_page]->body_value, $page); 
			if (!empty($xml->page[$num_page]->body_value))
			{
				$page = str_replace ('{PAGE_IMG_SMALL}',$xml->page[$num_page]->filename, $page); 
			}
			else
			{
				$page = str_replace ('{PAGE_IMG_MEDIUM}',$xml->page[$num_page]->filename, $page); 
				$page = str_replace ('{PAGE_IMG_LARGE}',$xml->page[$num_page]->filename, $page); 
			}
			//------------------------------------------
			if ($charset == "windows-1251")
			  {
				$page = iconv("UTF-8", "windows-1251",$page);
			  }
			//------------------------------------------

//-------------------------------------- write HTML
			if (!empty($page))
			{
				if ($save == 1)
				{
					if (!empty($xml->page[$num_page]['title']))
					{
						$filename = $xml->page[$num_page]['title'].".html";
					}
					else
					{
						$filename = $xml->page[$num_page]['nid'].".html";
					}


	$file = fopen ($fs_path."/".$filename,"w");
	if ( $file )
	  {
		$num_bytes = fwrite ($file, $page);
					//$num_bytes = file_put_contents ($fs_path."/".$filename, $page);
					if ($num_bytes > 0)
					{
$data['messages'] .= "<span class='ok'>Write </span>".$num_bytes." bytes  in ";
$data['messages'] .= "<a href='".$url_path."/".$filename."'>".$filename."</a>";
$data['messages'] .= "<br>";
					}
					else
					{
$data['errors'] .= getcwd();
$data['errors'] .= "<br>";
$data['errors'] .= "<span class='error'>Write error in </span>".$filename;
$data['errors'] .= "<br>";
					}
	  }
	fclose ($file); 

				}//------------------------ end if save on
			}//------------------------ end if empty page
//-------------------------------------- end write HTML
//================================================================================

		return $data;
	}//---------------------- end func


	public function create_child_pages($xml,
					$fs_path, 
					$url_path, 
					$site, 
					$content_location,
					$save,
					$charset,
					$page_tpl,
					$return_prev_page_link,
					$return_next_page_link)
	{
//echo "public create_child_pages()";
//echo "<br>";
		global $total_num_pages;

		$data['errors']="";
		$data['messages']="";
//$data['errors'] .= "<span class='error'>Test...</span>";
//$data['errors'] .= "<br>";
//$data['messages'] .= "<span class='ok'>Test...</span>";
//$data['messages'] .= "<br>";
		$num_pages=count($xml->page);
		//$num_pages=2;
//echo "<ul>";
		for ($n1=0; $n1<$num_pages; $n1++)
		{
			$page = $page_tpl;
//echo "<pre>";
//echo htmlspecialchars($page);
//echo "</pre>";
//echo "<hr>";

		//$total_num_pages++;
//echo $n1.". total_num_pages = ".$total_num_pages;
//echo "<br>";
//---------------------------------------- PAGER
		//$current_page=$total_num_pages;
		$current_page=$n1+1;
			
		$prev_page=$current_page-1;
		if ($prev_page>0)
		{
			if (!empty($xml->page[$prev_page-1]['title']))
			{
		$prev_page_link = "<a href='".$xml->page[$prev_page-1]['title'].".html'><|| previous page</a>";
			}
			else
			{
		$prev_page_link = "<a href='".$xml->page[$prev_page-1]['nid'].".html'><|| previous page</a>";
			}
		}
		else
		{
			//$prev_page_link = "";
			$prev_page_link = $return_prev_page_link;
		}
			
		$next_page=$current_page+1;
		if ($next_page<=$num_pages)
		{
				if (!empty($xml->page[$next_page-1]['title']))
				{
		$next_page_link = "<a href='".$xml->page[$next_page-1]['title'].".html'>next page ||></a>";
				}
				else
				{
		$next_page_link = "<a href='".$xml->page[$next_page-1]['nid'].".html'>next page ||></a>";
				}
		}
		else
		{
			//$next_page_link = "";
			$next_page_link = $return_next_page_link;
		}
//-----------------------------------------------
			$data2 = $this->create_page($xml,
						$fs_path, 
						$url_path, 
						$n1,
						$num_pages,
						$page,
						$save,
						$charset,
						$current_page,$prev_page_link,$next_page_link);
//echo "data2 =<pre>";
//print_r($data2);
//echo "</pre>";
			if (!empty($data2['errors']))
			{
				$data['errors'] .= $data2['errors'];
				$data['errors'] .= "<br>";
			}

			if (!empty($data2['messages']))
			{
				$data['messages'] .= $data2['messages'];
				$data['messages'] .= "<br>";
			}
		}//------------------------ end for
//echo "</ul>";

		return $data;
	}//---------------------- end func

}//--------------- end class
