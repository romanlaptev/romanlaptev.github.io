<?php 
//error_reporting(E_ALL);

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Export_mydb_model extends CI_Model
{
    //var $title   = '12345';
    //var $content = '';
    //var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
//echo "<ul>";
//echo "class <b>Export_mydb_model extends Model</b>";
//echo "</ul>";
    }

//------------------------------------------------------
// -- получить главную страницу (0) книги
//------------------------------------------------------
    function get_main_page()
    {
	$sql = "
SELECT
book.mlid,
book.nid,
-- menu_links.mlid,
menu_links.plid,
menu_links.weight,
node.nid,
node.title,
node_revisions.body
FROM book
LEFT JOIN menu_links ON menu_links.mlid=book.mlid
LEFT JOIN node ON node.nid=book.nid
LEFT JOIN node_revisions ON node_revisions.nid=book.nid
WHERE
book.mlid IN 
(SELECT menu_links.mlid FROM menu_links WHERE link_title LIKE 'записки' AND module='book')
";
//echo "sql = ".$sql;
//echo "<hr>";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func

//------------------------------------------------------
// -- получить отсортированные страницы (1) книги
//------------------------------------------------------
    function get_content()
    {
	$sql = "
-- получить отсортированные страницы (1) книги
SELECT
book.mlid,
book.nid,
-- menu_links.mlid,
menu_links.plid,
menu_links.weight,
node.nid,
node.title,
node_revisions.body
FROM book
LEFT JOIN menu_links ON menu_links.mlid=book.mlid
LEFT JOIN node ON node.nid=book.nid
LEFT JOIN node_revisions ON node_revisions.nid=book.nid
WHERE
book.mlid IN 
(SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid IN
(SELECT menu_links.mlid FROM menu_links WHERE link_title LIKE 'записки' AND module='book')
)
ORDER BY menu_links.plid ASC, menu_links.weight ASC, node.title ASC
";
//echo "sql = ".$sql;
//echo "<hr>";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func

//------------------------------------------------------
// -- получить все страницы (2) главы (1)
//------------------------------------------------------
    function get_child_pages_2($mlid)
    {
	$sql = "
SELECT
book.mlid,
book.nid,
-- menu_links.mlid,
menu_links.plid,
menu_links.weight,
node.nid,
node.title,
node_revisions.body
FROM book
LEFT JOIN menu_links ON menu_links.mlid=book.mlid
LEFT JOIN node ON node.nid=book.nid
LEFT JOIN node_revisions ON node_revisions.nid=book.nid
WHERE
book.mlid IN (SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid=".$mlid.")
ORDER BY menu_links.plid ASC, menu_links.weight ASC, node.title ASC
";
//echo "sql = ".$sql;
//echo "<hr>";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func

//------------------------------------------------------
// -- получить все дочернии страницы (3)
//------------------------------------------------------
    function get_child_pages_3($mlid)
    {
	$sql = "
-- получить все страницы (3)
SELECT
book.mlid,
book.nid,
-- menu_links.mlid,
menu_links.plid,
menu_links.weight,
node.nid,
node.title,
node_revisions.body
FROM book
LEFT JOIN menu_links ON menu_links.mlid=book.mlid
LEFT JOIN node ON node.nid=book.nid
LEFT JOIN node_revisions ON node_revisions.nid=book.nid
WHERE
book.mlid IN (SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid=".$mlid.")
ORDER BY menu_links.plid ASC, menu_links.weight ASC, node.title ASC
";
//echo "sql = ".$sql;
//echo "<hr>";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func


}//------------------------------ end class
?>
