<?php 
//error_reporting(E_ALL);

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Export_rods_model extends CI_Model
{
    //var $title   = '12345';
    //var $content = '';
    //var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
//echo "<ul>";
//echo "class <b>Export_rods_model extends Model</b>";
//echo "</ul>";
    }


//--------------------------
// получить заголовок книги
//--------------------------
    function get_title($field_book_title)
    {
/*
	$sql = "
SELECT menu_links.link_title 
FROM menu_links 
WHERE link_title LIKE '".$field_book_title."';
";
*/
	$sql = "
SELECT field_data_field_book_name.field_book_name_value FROM field_data_field_book_name 
WHERE field_data_field_book_name.entity_id IN 
	(SELECT book.nid FROM book WHERE book.mlid IN 
		(SELECT menu_links.mlid FROM menu_links WHERE 
menu_links.link_title='".$field_book_title."'));
";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func

//------------------------------------------------------
// получить menu_links.mlid страниц книги 1-го уровня (список глав)
//------------------------------------------------------
    function get_content($field_book_title)
    {
	$sql = "
SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid IN -- ВЛОЖЕННЫЙ ЗАПРОС
(SELECT menu_links.mlid FROM menu_links WHERE link_title LIKE '".$field_book_title."')
ORDER BY weight ASC;
";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func

//------------------------------------------------------
// получить страницы с изображениями для вложенной книги
//------------------------------------------------------
    function get_chapter($chapter_id)
    {
	$sql = "
-- получить страницы главы
SELECT 
book.mlid, 
book.nid, 
-- menu_links.mlid, 
menu_links.plid, 
node.nid, 
node.title, 
field_data_body.body_value, 
file_managed.filename, -- получить параметры прикрепленных файлов
-- file_managed.uri, 
-- file_managed.filemime, 
-- file_managed.filesize, 
-- file_managed.timestamp
field_data_field_content_files.field_content_files_value, -- копия имени файла 
field_data_field_description.field_description_value, -- метатег description
field_data_field_keywords.field_keywords_value, -- метатег keywords
field_data_field_img_title.field_img_title_value -- текст для изображений
FROM book 
LEFT JOIN menu_links ON menu_links.mlid=book.mlid 
LEFT JOIN node ON node.nid=book.nid
LEFT JOIN file_usage ON file_usage.id=node.nid -- fid прикрепленных файлы  
LEFT JOIN file_managed ON file_managed.fid=file_usage.fid
LEFT JOIN field_data_field_content_files ON field_data_field_content_files.entity_id=node.nid
LEFT JOIN field_data_body ON field_data_body.entity_id=node.nid -- основная часть
LEFT JOIN field_data_field_description ON field_data_field_description.entity_id=node.nid -- метатег description
LEFT JOIN field_data_field_keywords ON field_data_field_keywords.entity_id=node.nid -- метатег keywords
LEFT JOIN field_data_field_img_title ON field_data_field_img_title.entity_id=node.nid -- текст для изображений
WHERE 
book.mlid=".$chapter_id." OR
book.mlid IN
	(SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid=".$chapter_id.") 
ORDER BY menu_links.weight ASC
-- ORDER BY node.title ASC
";
//echo "sql = ".$sql;
//echo "<hr>";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func


}//------------------------------ end class
?>
