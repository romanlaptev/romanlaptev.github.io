<?php 
//error_reporting(E_ALL);

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Parser_lib_model extends CI_Model
{
    //var $title   = '12345';
    //var $content = '';
    //var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
//echo "<ul>";
//echo "class <b>Parser_lib_model extends Model</b>";
//echo "</ul>";
    }

//------------------------------------------------------
// получить страницы с изображениями для вложенной книги
//------------------------------------------------------
    function get_list_img_pages()
    {
	$sql = "
SELECT 
node.nid, 
node.title, 
-- node.status, 
field_data_body.body_value, 
file_managed.filename, 
-- file_managed.uri, 
file_managed.filemime, 
file_managed.filesize, 
-- file_managed.timestamp, 
-- menu_links.weight
field_data_field_book_img.field_book_img_alt,
field_data_field_book_img.field_book_img_title, 
url_alias.alias, 
page_title.page_title 
FROM node 
LEFT JOIN field_data_body ON field_data_body.entity_id=node.nid -- основная часть
LEFT JOIN file_usage ON file_usage.id=node.nid -- fid прикрепленных файлы  
LEFT JOIN file_managed ON file_managed.fid=file_usage.fid -- получить параметры прикрепленных файлов
LEFT JOIN field_data_field_book_img ON field_book_img_fid=file_usage.fid 
LEFT JOIN url_alias ON url_alias.source=CONCAT('node/',node.nid) -- url страницы
LEFT JOIN page_title ON page_title.id=node.nid -- заголовок страницы
-- LEFT JOIN book ON book.mlid=node.nid 
-- LEFT JOIN menu_links ON menu_links.mlid=book.mlid 
WHERE node.status=1 AND node.nid IN -- ВЛОЖЕННЫЙ ЗАПРОС
(SELECT book.nid FROM book WHERE book.mlid IN -- получить nid, соответствующий странице
	(SELECT menu_links.mlid FROM menu_links WHERE menu_links.plid IN -- ВЛОЖЕННЫЙ ЗАПРОС
		(SELECT menu_links.mlid FROM menu_links WHERE link_title LIKE 'img_pages' AND menu_links.plid IN -- ВЛОЖЕННЫЙ ЗАПРОС
			(SELECT menu_links.mlid FROM menu_links WHERE link_title LIKE 'Шедевры графики. Обри Бердслей')
))) ORDER BY node.title ASC;
";
	$query = $this->db->query($sql);
        return $query->result();
    }//---------------------------- end func


}//------------------------------ end class
?>
