<?
//echo "<pre>";
//print_r($_SERVER);
//print_r($_REQUEST);
//echo "</pre>";
date_default_timezone_set('Asia/Novosibirsk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Export DB</title>
</head>
<body>
<h2>Export mysql --> xml </h2>
<li><a href="index.php/export_db?fs_path=/mnt/disk2/temp&filename=export_gravura.xml">export database gravura</a></li>
	<div>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>" target=_blank>
	fs_path:
<input type="text" name="fs_path" value="<?php echo getcwd(); ?>" size="60"><br>
/mnt/disk2/temp<br>
<br>
	filename:
<input type="text" name="filename" value="export_gravura_<? echo date('d-m-Y_H-i');?>.xml" size="60"><br>
<br>
	url_path:
<input type="text" name="url_path" value="<?php echo $_SERVER['REQUEST_URI']?>" size="60"><br>
/mnt/disk2/temp<br>
<br>

	save:
<input type="checkbox" name="save" value="on">записать в файл<br>
<br>
<!--
	filter_body:
<input type="checkbox" name="filter_body" value="on">фильтровать текст страниц<br>
<br>
-->
	<input type="submit" value="export">
</form>
	</div>
<?
//echo "<pre>";
//print_r($this);
//print_r($books);
//print_r($notes);
//print_r($pages);
//print_r($pages[8][0]->node);
//echo "</pre>";
/*
	echo "<h2>Экспорт ".$books[0]->link_title."</h2>";
date_default_timezone_set('Asia/Novosibirsk');

	echo "<h2>".$books[0]->link_title."</h2>";
	echo "<ul>";
	$n1=0;
	$n2=0;

	// 2 уровень списка книг (тетради)
	foreach ($notes as $key => $item)
	{
		echo "<li>".$item->link_title."</li>";
		echo "<ul>";

		// 3 уровень списка книг (страницы)
		for ($n2=0; $n2<count($pages[$n1]); $n2++)
		{
			echo "<li>".$pages[$n1][$n2]->link_title."</li>";

			//параметры страницы тетради
			echo "<ul>";

			if (!empty($pages[$n1][$n2]->node[0]->nid))
			{
				echo "nid: ".$pages[$n1][$n2]->node[0]->nid;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->title))
			{
				echo "title: ".$pages[$n1][$n2]->node[0]->title;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->status))
			{
				echo "status: ".$pages[$n1][$n2]->node[0]->status;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->created))
			{
				echo "created: ".date('d-M-Y H:i:s', $pages[$n1][$n2]->node[0]->created);
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->changed))
			{
				echo "changed: ".date('d-M-Y H:i:s', $pages[$n1][$n2]->node[0]->changed);
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->body_value))
			{
				$body = htmlspecialchars ($pages[$n1][$n2]->node[0]->body_value);
				echo "body_value: ".$body;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_large_img_value))
			{
				echo "field_large_img_value: ".$pages[$n1][$n2]->node[0]->field_large_img_value;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_medium_img_value))
			{
				echo "field_medium_img_value: ".$pages[$n1][$n2]->node[0]->field_medium_img_value;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_original_img_value))
			{
				echo "field_original_img_value: ".$pages[$n1][$n2]->node[0]->field_original_img_value;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_preview_gallery_img_value))
			{
				echo "field_preview_gallery_img_value: ".$pages[$n1][$n2]->node[0]->field_preview_gallery_img_value;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_small_img_value))
			{
				echo "small_img: ".$pages[$n1][$n2]->node[0]->field_small_img_value;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->field_notebook_tid))
			{
				echo "tid, termin: ".$pages[$n1][$n2]->node[0]->field_notebook_tid;
				echo ", ".$pages[$n1][$n2]->node[0]->name;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->page_title))
			{
				echo "page_title: ".$pages[$n1][$n2]->node[0]->page_title;
				echo "<br>";
			}

			if (!empty($pages[$n1][$n2]->node[0]->alias))
			{
				echo "alias: ".$pages[$n1][$n2]->node[0]->alias;
				echo "<br>";
			}

			echo "</ul>";

		}
		echo "</ul>";
		$n1++;
	}
	echo "</ul>";
*/
?>

</body>
</html>
