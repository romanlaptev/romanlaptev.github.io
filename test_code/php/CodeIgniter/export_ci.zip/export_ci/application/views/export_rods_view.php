<?
//echo "<pre>";
//print_r($_SERVER);
//print_r($_REQUEST);
//print_r($errors);
//print_r($messages);
//echo "</pre>";
date_default_timezone_set('Asia/Novosibirsk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>export_rods, drupal book --> xml</title>
	<style>
legend
{
	color:blue;
	font-size:16px;
}
.section
{
	border:1px solid;
	margin:20px;
	padding:5px;
	/*width:870px;*/
}
.param
{
	color:darkblue;
}
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	color:green;
}
.warning
{
	color:#ffffff;
	background:darkred;
	font-style:italic;
}
#message
{
	border: 1px solid;
	min-height: 30px;
	padding:20px;
/*
	background:darkred;
	position:absolute;
	top:20px;
	right:20px;
    float: right;
    width: 250px;	
*/
}
#form
{
}
#log
{
	border: 1px solid;
	min-height: 100px;
	padding:20px;
}
	</style>
</head>
<body>
<?php 
	if (!empty ($errors))
	{
?>
<div id='errors' class='section'>
<fieldset>
	<legend><b>errors</b></legend>
<?
		echo $errors; 
?>
</fieldset>
</div>
<?
	}
?>

<?php 
	if (!empty ($messages))
	{
?>
<div class='section'>
<fieldset>
	<legend><b>messages</b></legend>
<?php 
		echo $messages; 
?>
</fieldset>
</div>
<?php 
	}
?>

	<div class='section'>
<h2>Экспорт drupal7 book --> xml файл</h2>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">

	<b>field_book_title:</b>
<input type="text" name="field_book_title" 
value="Родс Энтони. Пропаганда. Плакаты, карикатуры и кинофильмы Второй Мировой Войны 1939-1945" size="100"><br>
<br>

	<b>fs_path:</b>
<input type="text" name="fs_path" value="/mnt/POCKI-DRIVE/opt/www/pages/book_Rods" size="60"><br>
<?php echo getcwd(); ?><br>
/mnt/POCKI-DRIVE/opt/www/pages/book_Rods<br>
/mnt/disk2/temp<br>
<br>
	<b>filename:</b>
<input type="text" name="filename" value="export_book.xml" size="60"><br>
<br>

	<b>url_path:</b>
<input type="text" name="url_path" value="/pages/book_Rods" size="60"><br>
/pages/book_Rods<br>
/mnt/disk2/temp<br>
<br>
	<b>save:</b>
<input type="checkbox" name="save" value="on">записать в файл<br>
<br>

	<b>action:</b><input type="text" name="action" value="xml_export">
	<input type="submit" value="export">
</form>
	</div>


	<div class='section'>
<h2>Экспорт xml файл --> html страницы</h2>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>" target="_blank">

	<b>fs_path:</b>
<input type="text" name="fs_path" value="/pages/book_Rods/html" size="60"><br>
<?php echo getcwd(); ?><br>
/mnt/POCKI-DRIVE/opt/www<br>
/mnt/disk2/temp<br>
<br>

	<b>url_path:</b>
<input type="text" name="url_path" value="/pages/book_Rods/html" size="60"><br>
<?php echo $_SERVER['REQUEST_URI']?><br>
/mnt/disk2/temp<br>
<br>

	<b>xml_file:</b>
<input type="text" name="xml_file" value="/pages/book_Rods/export_book.xml" size="60"><br>
<?php echo getcwd(); ?><br>
/mnt/POCKI-DRIVE/opt/www<br>
/mnt/disk2/temp<br>
<br>

	<b>site:</b>
<input type="text" name="site" value="http://<?php echo $_SERVER['SERVER_NAME']?>" size="60"><br>
http://lib.wallst.ru<br>
http://blackcat.500mb.net<br>
<br>
	<b>content_location:</b>
<input type="text" name="content_location" value="/content/book_img" size="60"><br>
http://wizardgraphics.narod.ru<br>

	<b>css_location:</b>
<input type="text" name="css_location" value="/pages/book_Rods/html/css/style.css" size="60"><br>
/pages/book_Rods/html/css<br>
<br>
	<b>charset:</b>
<input type="text" name="charset" value="utf-8" size="20"><br>
utf-8<br>
windows-1251<br>
<br>

	<b>file_content_tpl:</b>
<input type="text" name="file_content_tpl" value="content_book_Rods.tpl.php" size="80"><br>
	<b>file_page_tpl:</b>
<input type="text" name="file_page_tpl" value="page_book_Rods.tpl.php" size="80"><br>
<?php echo getcwd(); ?>/tpl/<br>
/mnt/transcend/0_sites/export/tpl/<br>
/mnt/POCKI-DRIVE/opt/www/sites/lib.wallst.ru/book_Rods/tpl/<br>
<br>
<br>

	save:
<input type="checkbox" name="save" value="on">сохранять страницы в файл<br>
<br>


	<b>action:</b><input type="text" name="action" value="html_export">
	<input type="submit" value="export">
</form>
	</div>


</body>
</html>
