<?
echo "<pre>";
//print_r($_SERVER);
print_r($_REQUEST);
//print_r($errors);
echo "</pre>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Parser lib: Drupal book export in HTML</title>
	<style>
legend
{
	color:green;
	font-size:16px;
}
.section
{
	border:1px solid;
	margin:20px;
	padding:5px;
	width:870px;
}
.param
{
	color:darkblue;
}
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	color:green;
}
.warning
{
	color:#ffffff;
	background:darkred;
	font-style:italic;
}
#message
{
	border: 1px solid;
	min-height: 30px;
	padding:20px;
/*
	background:darkred;
	position:absolute;
	top:20px;
	right:20px;
    float: right;
    width: 250px;	
*/
}
#form
{
}
#log
{
	border: 1px solid;
	min-height: 100px;
	padding:20px;
}
	</style>
</head>
<body>
<h2>Parser lib: Drupal book export in HTML</h2>

<?php 
	if (!empty ($errors))
	{
?>
<div id='errors' class='section'>
<fieldset>
	<legend><b>errors</b></legend>
<?
		echo $errors; 
?>
</fieldset>
</div>
<?
	}
?>

<?php 
	if (!empty ($messages))
	{
?>
<div class='section'>
<fieldset>
	<legend><b>messages</b></legend>
<?php 
		echo $messages; 
?>
</fieldset>
</div>
<?php 
	}
?>

	<div class='section'>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>" target=_blank>
	fs_path:
<input type="text" name="fs_path" value="" size="60"><br>
<?php echo getcwd(); ?><br>
/mnt/disk2/temp<br>
/mnt/POCKI-DRIVE/opt/www/pages/book_Beardsley<br>
<br>
	url_path:
<input type="text" name="url_path" value="" size="60"><br>
<?php echo $_SERVER['REQUEST_URI']?><br>
/mnt/disk2/temp<br>
/pages/book_Beardsley<br>
<br>
	site:
<input type="text" name="site" value="<?php echo $_SERVER['SERVER_NAME']?>" size="60"><br>
blackcat.far.ru<br>
<br>
	charset:
<input type="text" name="charset" value="utf-8" size="20"><br>
utf-8<br>
windows-1251<br>
<br>

	save:
<input type="checkbox" name="save" value="on">сохранять страницы в файл<br>
<br>

<!--
	<div>
		<fieldset>
			<legend><b>Расположение изображений страниц</b></legend>
	<b>thumbnail_img</b>
<input type="text" name="thumbnail_img" value="" size="60"><br>
/content/book_Beardsley/thumbnail</br>

	<b>small_img</b>
<input type="text" name="small_img" value="" size="60"><br>
/content/book_Beardsley/small</br>

	<b>medium_img</b>
<input type="text" name="medium_img" value="" size="60"><br>
/content/book_Beardsley/medium</br>

	<b>original_img</b>
<input type="text" name="original_img" value="" size="60"><br>
/content/book_Beardsley/original</br>

		</fieldset>
	</div>
-->

	<input type="submit" value="export">
</form>
	</div>


</body>
</html>
