<?
//echo "<pre>";
//print_r($_SERVER);
//print_r($_REQUEST);
//print_r($errors);
//print_r($messages);
//echo "</pre>";
date_default_timezone_set('Asia/Novosibirsk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>export_mydb, drupal book --> xml</title>
	<style>
legend
{
	color:green;
	font-size:16px;
}
.section
{
	border:1px solid;
	margin:20px;
	padding:5px;
	width:870px;
}
.param
{
	color:darkblue;
}
.error
{
	font-weight:bold;
	color:red;
}
.ok
{
	color:green;
}
.warning
{
	color:#ffffff;
	background:darkred;
	font-style:italic;
}
#message
{
	border: 1px solid;
	min-height: 30px;
	padding:20px;
/*
	background:darkred;
	position:absolute;
	top:20px;
	right:20px;
    float: right;
    width: 250px;	
*/
}
#form
{
}
#log
{
	border: 1px solid;
	min-height: 100px;
	padding:20px;
}
	</style>
</head>
<body>
<h2>export_mydb, drupal book --> xml</h2>

<?php 
	if (!empty ($errors))
	{
?>
<div id='errors' class='section'>
<fieldset>
	<legend><b>errors</b></legend>
<?
		echo $errors; 
?>
</fieldset>
</div>
<?
	}
?>

<?php 
	if (!empty ($messages))
	{
?>
<div class='section'>
<fieldset>
	<legend><b>messages</b></legend>
<?php 
		echo $messages; 
?>
</fieldset>
</div>
<?php 
	}
?>

	<div class='section'>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
	fs_path:
<input type="text" name="fs_path" value="/mnt/POCKI-DRIVE/opt/www/pages/xml" size="60"><br>
<?php echo getcwd(); ?><br>
/mnt/POCKI-DRIVE/opt/www/pages/xml<br>
/mnt/disk2/temp<br>
<br>
	filename:
<input type="text" name="filename" value="export_mydb_notes.xml" size="60"><br>
<br>

	url_path:
<input type="text" name="url_path" value="/pages/xml" size="60"><br>
/pages/xml<br>
/mnt/disk2/temp<br>
<br>
	save:
<input type="checkbox" name="save" value="on">записать в файл<br>
<br>

	<input type="submit" value="export">
</form>
	</div>


</body>
</html>
