<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">

<head profile="http://www.w3.org/1999/xhtml/vocab">
<!--<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
<meta http-equiv="content-type" content="text/html; charset={CHARSET}"/>
<!--
<meta name="keywords" content="{KEYWORDS}" />
<meta name="description" content="{DESCRIPTION}"/>
-->
<title>Шедевры графики. Обри Бердслей / Graphic masterpiece. Aubrey Beardsley</title>

<style type="text/css" media="all">
@import url("{SITE}/pages/book_Beardsley/css/system.theme.css");
@import url("{SITE}/pages/book_Beardsley/css/layout.css");
@import url("{SITE}/pages/book_Beardsley/css/style.css");
body
{
	background:#e6eaec;
}
</style>
<!-- ======================================= -->
	<link rel="stylesheet" href="{SITE}/pages/js/pirobox/pirobox.css" type="text/css" media="screen" />
	<script type="text/javascript" src="{SITE}/pages/js/pirobox/jquery.min.js"></script>
	<script type="text/javascript" src="{SITE}/pages/js/pirobox/pirobox_ansi.js"></script>
	<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery().piroBox({
			my_speed: 300, //animation speed
			bg_alpha: 0.1, //background opacity
			slideShow : true, // true == slideshow on, false == slideshow off
			slideSpeed : 6, //slideshow duration in seconds(3 to 6 Recommended)
			close_all : '.piro_close,.piro_overlay'// add class .piro_overlay(with comma)if you want overlay click close piroBox

	});
});
	</script>
	<script language="JavaScript" src="{SITE}/pages/js/access.js.php"></script>
<!-- ======================================= -->
<script language="JavaScript">
function load_page()
{
	var num = 0;
	var a = '';
	num = document.forms.form_pager.page.selectedIndex;
	a = document.forms.form_pager.page[num].value;
	window.location.href=a;
}
</script>
</head>

<body>

<div class="section"> 

	<div class="view-view-img-pages">

		<div class="item-list" style="float:right">
		{PAGER}
		</div>  
		<div style="clear:both"></div>

		<div class="view-content">
<h2 style="text-align:center;">Шедевры графики. Обри Бердслей.</h2>
<div style="text-align:center;">
Составление, примечания, концепция Ирины Пименовой. М.: Эксмо, 2006. - 216 с.
</div>

			<table>
			<tbody>
				<tr>
					<td>
						<div class="col-1">
							<div class="views-field-title" style="text-align:left;">        
<span class="field-content">{TITLE1}</span>  
							</div>  

							<div class="views-field-field-book-img">        
								<div class="field-content">
<a href="{SITE}/content/book_Beardsley/medium/{FILENAME1}" title="{ALT1}" class="pirobox">
<img src="{SITE}/content/book_Beardsley/small/{FILENAME1}" width="500" height="600" alt="{ALT1}" title="" />
<span style="float:right;">увеличить</span>
</a>
								</div>
							</div>  

							<div class="views-field-field-book-img-1">        
<div class="field-content">{ALT1}</div>  
							</div>          
						</div>          
					</td>
					<td>
						<div class="col-2">
							<div class="views-field-title" style="text-align:right;">        
<span class="field-content">{TITLE2}</span>  
							</div>  
							<div class="views-field-field-book-img">        
								<div class="field-content">
<a href="{SITE}/content/book_Beardsley/medium/{FILENAME2}" title="{ALT2}" class="pirobox">
<img src="{SITE}/content/book_Beardsley/small/{FILENAME2}" width="500" height="600" alt="{ALT2}" title="" />
<span style="float:right;">увеличить</span>
</a>
								</div>  
							</div>  
							<div class="views-field-field-book-img-1">        
<div class="field-content">{ALT2}</div>  
							</div>          
						</div>          
					</td>
				</tr>
			</tbody>
			</table>
		</div>


</div> <!-- /.section -->

<div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter19504897 = new Ya.Metrika({id:19504897,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/19504897" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</div>

</body>
</html>

