<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">

<head profile="http://www.w3.org/1999/xhtml/vocab">
<meta http-equiv="content-type" content="text/html; charset={CHARSET}"/>

<meta name="keywords" content="{KEYWORDS}" />
<meta name="description" content="{DESCRIPTION}"/>

<!--
<meta name="keywords" content="Пропаганда Плакаты карикатуры кинофильмы Второй мировой войны читать онлайн" />
<meta name="description" content="Энтони Родс | Пропаганда. Плакаты, карикатуры и кинофильмы Второй мировой войны |  читать онлайн"/>
-->

<!-- <title>{TITLE}</title> -->
<title>{DESCRIPTION}</title>

	<link rel="stylesheet" href="{CSS_LOCATION}" type="text/css" media="screen" />
<!-- ######################################################### -->
	<link rel="stylesheet" type="text/css" href="{SITE}/pages/js/highslide/highslide.css" />
	<script type="text/javascript" src="{SITE}/pages/js/highslide/highslide.js"></script>
	
<script type="text/javascript">
//http://highslide.com/ref/hs.expand
		hs.graphicsDir = '{SITE}/pages/js/highslide/graphics/';
		hs.wrapperClassName = 'wide-border';
		hs.showCredits = false;
		//hs.align = 'center';
		//hs.transitions = ['expand', 'crossfade'];
		// Add the simple close button
		hs.registerOverlay({
			html: '<div class="closebutton" onclick="return hs.close(this)" title="Close"></div>',
			position: 'top right',
			fade: 2 // fading the semi-transparent overlay looks bad in IE
		});
</script>
<!-- ######################################################### -->

<script>
function createRequestObject() 
{
	var request = false;
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari, Opera ...
		request = new XMLHttpRequest();
	} 

	if(!request)
	{ // IE
		request = new ActiveXObject("Microsoft.XMLHTTP");
	}

	if(!request)
	{
		request=new ActiveXObject('Msxml2.XMLHTTP');
	}

	return request;
}

function access()
{
	var request = createRequestObject();
	//url = "http://it-works.16mb.com/php/access.php";
	url = "/php/access.php";

	if (!request) return false;
//alert ('function access()');
	
	request.onreadystatechange  = function() 
	{ 
//свойство .readyState.
// 0 – инициализация запроса;
// 1 – формирование запроса;
// 2 – формирование запроса окончено;
// 3 – взаимодействие с сервером;
// 4 – взаимодействие завершено (ответ получен).

//alert('readyState = ' + request.readyState);
		//var state = document.getElementById('state');
		//state.innerHTML = request.readyState;
		
		if(request.readyState == 4) 
		{
//alert('request.status = ' + request.status);
			//var status = document.getElementById('status');
			//status.innerHTML = request.status;

			//var str_res = request.responseText;
//alert (str_res);
			//var result = document.getElementById('result');
			//result.innerHTML=str_res;
		}
	};
	request.open('POST', url, true);
	if (request.setRequestHeader) 
	{
		request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	}
	var str = 'id=1';
	request.send(str);
	
	return true;
}//----------------------------------- end func

	//access();

</script>
<noscript>
	<b>javascript not support</b>
	<!--<meta http-equiv="refresh" content="0;URL=map.html">-->
</noscript>
</head>


<body>
<div id="wrapper">
	<div id="header">
		<h1 id="header-title">{TITLE}</h1>
		<div class="line"></div>
	</div>

	<div id="container">
		<div id="left"></div>
	
		<div id="center">
		
			<div id="navigation">
<a class="content-link" href="{SITE}{URL}/index.html">содержание</a>
<span id="navigation-elements">

<div class="list-pages">
	<span id="prev-page">{PREV_PAGE}</span> | <span id="next-page">{NEXT_PAGE}</span>
</div>

<div class="form-num-page">
<form>
page <input type="text" name="page_num" size="3" value="{CURRENT_PAGE}" id="current-page">
	<input type="hidden" name="content" value="view_page">
	<input type="submit" value=">>"> из <span id="num-pages">{NUM_PAGES}</span>
</form>
</div>

<!--
	<span id="resize">
		<select name="select_size">
			<option value="1">50%</option>
			<option value="2">70%</option>
			<option value="3">85%</option>
			<option value="4">100%</option>
			<option value="5">125%</option>
			<option value="6">150%</option>
			<option value="7">175%</option>
			<option value="8">200%</option>
			<option value="9">page width</option>
		</select>
	</span>
-->
</span>
			</div>

<div class='pages'>
	<h2 id="page-title">{PAGE_TITLE}</h2>

<div id='book-pages'>
	<div id="page-even">
		<span id="page-even-title"></span>
		<div id="page-even-content">
{BODY}
		</div>
	</div>
	<div id='page-odd'>
		<span id="page-odd-title"></span>
		<div id="page-odd-content">

<a href="{CONTENT_LOCATION}/styles/large/{PAGE_IMG_LARGE}">
<img src="{CONTENT_LOCATION}/styles/thumbnail/{PAGE_IMG_THUMBNAIL}"></a>

			<div id="resize-links">
увеличить: 
<!--
<a href="{CONTENT_LOCATION}/styles/thumbnail/{PAGE_IMG_THUMBNAIL}">preview size</a>| 
<a href="{CONTENT_LOCATION}/styles/small/{PAGE_IMG_SMALL}">small size</a>| 
-->
<a href="{CONTENT_LOCATION}/styles/medium/{PAGE_IMG_MEDIUM}">medium size</a>|
<a href="{CONTENT_LOCATION}/styles/large/{PAGE_IMG_LARGE}">large size</a>| 
<a href="{CONTENT_LOCATION}/{PAGE_IMG}">original size</a>
				<div>
					{IMG_TITLE}
				</div>
			</div>

		</div>
	</div><!-- end page-odd -->
</div><!-- end book-pages -->

	<div id='book-img'>
		<div id="book-img-content">
			{IMG_TITLE}
			<span id="book-img-title">
увеличить: <br>
<!--
<a href="{CONTENT_LOCATION}/styles/thumbnail/{PAGE_IMG_THUMBNAIL}">preview size</a>| 
<a href="{CONTENT_LOCATION}/styles/small/{PAGE_IMG_SMALL}">small size</a>| 
-->
<a href="{CONTENT_LOCATION}/styles/medium/{PAGE_IMG_MEDIUM}">medium size</a>| 
<a href="{CONTENT_LOCATION}/styles/large/{PAGE_IMG_LARGE}">large size</a>| 
<a href="{CONTENT_LOCATION}/{PAGE_IMG}">original size</a>
			</span>
		</div>

<a href="{CONTENT_LOCATION}/styles/large/{PAGE_IMG_LARGE}">
	<img src="{CONTENT_LOCATION}/styles/medium/{PAGE_IMG_MEDIUM}">
</a>

	</div><!-- end book-img -->
</div>

<div style='clear:both;'></div>
<!--
<div align='center'>
	<div class='pager'>
	</div>
</div>
-->
		</div>
		<div id="right"></div>
	</div>
	<div style="clear:both;"></div>

	<div id="footer">
		<div class="line"></div>
	</div>
</div>		<!-- end wrapper -->

</body>
</html>

