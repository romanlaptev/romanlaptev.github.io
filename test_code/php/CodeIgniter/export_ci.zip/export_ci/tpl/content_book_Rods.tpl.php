<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">

<head profile="http://www.w3.org/1999/xhtml/vocab">
<meta http-equiv="content-type" content="text/html; charset={CHARSET}"/>
<!--
<meta name="keywords" content="{KEYWORDS}" />
<meta name="description" content="{DESCRIPTION}"/>
-->
<meta name="keywords" content="Пропаганда Плакаты карикатуры кинофильмы Второй мировой войны читать онлайн" />
<meta name="description" content="Энтони Родс | Пропаганда. Плакаты, карикатуры и кинофильмы Второй мировой войны |  читать онлайн"/>

<title>{TITLE}</title>
	<link rel="stylesheet" href="{CSS_LOCATION}" type="text/css" media="screen" />
<!-- ######################################################### -->
	<link rel="stylesheet" type="text/css" href="{SITE}/pages/js/highslide/highslide.css" />
	<script type="text/javascript" src="{SITE}/pages/js/highslide/highslide.js"></script>
	
<script type="text/javascript">
//http://highslide.com/ref/hs.expand
		hs.graphicsDir = '{SITE}/pages/js/highslide/graphics/';
		hs.wrapperClassName = 'wide-border';
		hs.showCredits = false;
		//hs.align = 'center';
		//hs.transitions = ['expand', 'crossfade'];
		// Add the simple close button
		hs.registerOverlay({
			html: '<div class="closebutton" onclick="return hs.close(this)" title="Close"></div>',
			position: 'top right',
			fade: 2 // fading the semi-transparent overlay looks bad in IE
		});
</script>
<!-- ######################################################### -->

<script>
function createRequestObject() 
{
	var request = false;
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari, Opera ...
		request = new XMLHttpRequest();
	} 

	if(!request)
	{ // IE
		request = new ActiveXObject("Microsoft.XMLHTTP");
	}

	if(!request)
	{
		request=new ActiveXObject('Msxml2.XMLHTTP');
	}

	return request;
}

function access()
{
	var request = createRequestObject();
	//url = "http://it-works.16mb.com/php/access.php";
	url = "/php/access.php";

	if (!request) return false;
//alert ('function access()');
	
	request.onreadystatechange  = function() 
	{ 
//свойство .readyState.
// 0 – инициализация запроса;
// 1 – формирование запроса;
// 2 – формирование запроса окончено;
// 3 – взаимодействие с сервером;
// 4 – взаимодействие завершено (ответ получен).

//alert('readyState = ' + request.readyState);
		//var state = document.getElementById('state');
		//state.innerHTML = request.readyState;
		
		if(request.readyState == 4) 
		{
//alert('request.status = ' + request.status);
			//var status = document.getElementById('status');
			//status.innerHTML = request.status;

			//var str_res = request.responseText;
//alert (str_res);
			//var result = document.getElementById('result');
			//result.innerHTML=str_res;
		}
	};
	request.open('POST', url, true);
	if (request.setRequestHeader) 
	{
		request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	}
	var str = 'id=1';
	request.send(str);
	
	return true;
}//----------------------------------- end func

	//access();

</script>
<noscript>
	<b>javascript not support</b>
	<!--<meta http-equiv="refresh" content="0;URL=map.html">-->
</noscript>
</head>


<body>
<div id="wrapper">
	<div id="header">
		<h1 id="header-title">{TITLE}</h1>
		<div class="line"></div>
	</div>

	<div id="container">
		<div id="left"></div>
	
		<div id="center">
<!--		
			<div id="navigation">
			</div>
-->
<div class='pages'>
	<h2 id="page-title"></h2>
	<div id="content-page-even">
		<span id="page-even-title"></span>
		<div id="page-even-content">
<img src="{CONTENT_LOCATION}/styles/small/{PAGE_IMG}">
		</div>
	</div>
	<div id="content-page-odd">
		<span id="page-odd-title"></span>
		<div id="page-odd-content">
{CONTENT}
<hr>
<p>
Книга написана известным специалистом в области пропаганды времен Второй мировой войны, Энтони Родсом.
В ней рассматриваются практически все виды пропаганды, которую вели основные государства - 
участники самого грандиозного военного конфликта в истории человечества: плакаты, кинофильмы, 
газетные полосы с карикатурами, создававшие у населения своей страны образ врага, 
и "психологические способы" ведения боевых действий, предназначенные для оказания 
непосредственного воздействия на войска и гражданское население противника. 
</p>

<span id="num-pages">{NUM_PAGES}</span>

		</div>
	</div>
</div>

<div style='clear:both;'></div>
<!--
<div align='center'>
	<div class='pager'>
	</div>
</div>
-->
		</div>
		<div id="right"></div>
	</div>
	<div style="clear:both;"></div>

	<div id="footer">
		<div class="line"></div>
	</div>
</div>		<!-- end wrapper -->

</body>
</html>

